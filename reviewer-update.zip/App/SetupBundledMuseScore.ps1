param([string]$RoamingRoot=$env:APPDATA, [string]$LocalRoot=$env:LOCALAPPDATA)
$ErrorActionPreference='Stop'
# Keep other extensions and preferences when the reviewer already uses this nightly build.
$utf8=New-Object Text.UTF8Encoding($false)
function Write-ReviewConfig([string]$Path,[string]$Text) {
    [void][IO.Directory]::CreateDirectory((Split-Path -Parent $Path))
    $temporary=$Path+'.psalmist-'+[guid]::NewGuid()+'.tmp'
    try {
        [IO.File]::WriteAllText($temporary,$Text,$utf8)
        if (Test-Path -LiteralPath $Path) {
            $backup=$Path+'.before-psalmist.bak'
            if (-not (Test-Path -LiteralPath $backup)) { [IO.File]::Copy($Path,$backup) }
            [IO.File]::Replace($temporary,$Path,[NullString]::Value)
        } else { [IO.File]::Move($temporary,$Path) }
    } finally { if (Test-Path -LiteralPath $temporary) { Remove-Item -LiteralPath $temporary } }
}
$config=Join-Path $LocalRoot 'MuseScore/MuseScoreStudio5Development/extensions/config.json'
$entries=@()
if (Test-Path -LiteralPath $config) {
    $text=[IO.File]::ReadAllText($config)
    if (-not $text.TrimStart().StartsWith('[')) { throw 'Existing MuseScore extension settings are damaged; restore them before launching.' }
    $entries=ConvertFrom-Json -InputObject $text
}
$uri='extension://plugin/v1/psalmistplaybackreview/psalmistplaybackreview.qml'
$entries=@($entries | Where-Object { $_.uri -ne $uri })+@([pscustomobject]@{uri=$uri;enabled=$true})
Write-ReviewConfig $config (ConvertTo-Json -InputObject $entries -Depth 20)
$ini=Join-Path $RoamingRoot 'MuseScore/MuseScoreStudio5Development.ini'
$lines=New-Object 'Collections.Generic.List[string]'
if (Test-Path -LiteralPath $ini) { $lines.AddRange([string[]][IO.File]::ReadAllLines($ini)) }
$start=$lines.IndexOf('[application]')
if ($start -lt 0) { $lines.Add('[application]'); $start=$lines.Count-1 }
$end=$start+1
while ($end -lt $lines.Count -and $lines[$end] -notmatch '^\[') { $end++ }
$values=@{hasCompletedFirstLaunchSetup='true';welcomeDialogShowOnStartup='false';welcomeDialogLastShownVersion='5.0.0'}
foreach ($key in $values.Keys) {
    $found=$false
    for ($i=$start+1;$i -lt $end;$i++) {
        if ($lines[$i] -match ('^'+[regex]::Escape($key)+'=')) { $lines[$i]=$key+'='+$values[$key];$found=$true;break }
    }
    if (-not $found) { $lines.Insert($end,$key+'='+$values[$key]);$end++ }
}
Write-ReviewConfig $ini ([string]::Join("`r`n",$lines)+"`r`n")
