@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0RepairMixerNames.ps1" %*
pause
