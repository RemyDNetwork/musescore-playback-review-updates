param([string]$DeploymentUrl,[string]$SyncKey)
$ErrorActionPreference='Stop'
try {
  if (-not $DeploymentUrl -or -not $SyncKey) {
    Add-Type -AssemblyName System.Windows.Forms
    Add-Type -AssemblyName System.Drawing
    [Windows.Forms.Application]::EnableVisualStyles()
    $form=New-Object Windows.Forms.Form
    $form.Text='Psalmist - organiser sync setup';$form.ClientSize=New-Object Drawing.Size(580,300)
    $form.StartPosition='CenterScreen';$form.FormBorderStyle='FixedDialog';$form.MaximizeBox=$false
    $form.Font=New-Object Drawing.Font('Segoe UI',10)
    $intro=New-Object Windows.Forms.Label;$intro.SetBounds(20,16,540,54)
    $intro.Text='After deploying the Google script, enter its URL and key once. This connects every copy of this kit. Then copy the whole folder to the reviewers.'
    $urlLabel=New-Object Windows.Forms.Label;$urlLabel.Text='Deployment URL ending in /exec';$urlLabel.SetBounds(20,80,530,24)
    $urlBox=New-Object Windows.Forms.TextBox;$urlBox.SetBounds(20,108,540,28)
    $keyLabel=New-Object Windows.Forms.Label;$keyLabel.Text='Sync key from setupSharedReviews execution log';$keyLabel.SetBounds(20,150,540,24)
    $keyBox=New-Object Windows.Forms.TextBox;$keyBox.SetBounds(20,178,540,28);$keyBox.UseSystemPasswordChar=$true
    $save=New-Object Windows.Forms.Button;$save.Text='Connect this kit';$save.SetBounds(360,242,200,36);$save.DialogResult=[Windows.Forms.DialogResult]::OK
    $form.Controls.AddRange(@($intro,$urlLabel,$urlBox,$keyLabel,$keyBox,$save));$form.AcceptButton=$save
    if ($form.ShowDialog() -ne [Windows.Forms.DialogResult]::OK) { $form.Dispose();exit }
    $DeploymentUrl=$urlBox.Text.Trim();$SyncKey=$keyBox.Text.Trim();$form.Dispose()
  }
  if ($DeploymentUrl -cnotmatch '^https://script\.google\.com/macros/s/[A-Za-z0-9_-]+/exec$' -or $SyncKey -cnotmatch '^[A-Za-z0-9-]{32,200}$') { throw 'Use the deployed Google Apps Script /exec URL and the organiser sync key.' }
  $path=Join-Path $PSScriptRoot 'shared-sync.json';$temp=$path+'.tmp'
  [IO.File]::WriteAllText($temp,(@{url=$DeploymentUrl;key=$SyncKey}|ConvertTo-Json -Compress),(New-Object Text.UTF8Encoding($false)))
  if ([IO.File]::Exists($path)) { [IO.File]::Replace($temp,$path,$path+'.bak') } else { [IO.File]::Move($temp,$path) }
  'Connected this kit. Copy the entire Psalmist Reviewer folder to reviewers. They only enter their names and open START HERE.'
} catch { Write-Error $_.Exception.Message;exit 1 }
