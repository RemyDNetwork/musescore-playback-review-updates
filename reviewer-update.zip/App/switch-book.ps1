param([Parameter(Mandatory=$true)][string]$RequestPath)
$ErrorActionPreference='Stop'
Add-Type -AssemblyName System.IO.Compression.FileSystem
Add-Type -AssemblyName System.IO.Compression
$utf8=New-Object Text.UTF8Encoding($false)
function Read-Book([string]$Path) {
    $stream=[IO.File]::Open($Path,'Open','Read',([IO.FileShare]::ReadWrite -bor [IO.FileShare]::Delete))
    try {
        $zip=New-Object IO.Compression.ZipArchive($stream,[IO.Compression.ZipArchiveMode]::Read)
        try {
            $entries=@($zip.Entries|Where-Object {$_.FullName.EndsWith('.mscx')})
            if($entries.Count -ne 1 -or $entries[0].Length -gt 134217728){throw 'Invalid review score archive.'}
            $settings=New-Object Xml.XmlReaderSettings
            $settings.DtdProcessing=[Xml.DtdProcessing]::Prohibit;$settings.XmlResolver=$null;$settings.MaxCharactersInDocument=134217728
            $entryStream=$entries[0].Open();$reader=[Xml.XmlReader]::Create($entryStream,$settings)
            $xml=New-Object Xml.XmlDocument;$xml.XmlResolver=$null
            try {$xml.Load($reader)}finally{$reader.Dispose();$entryStream.Dispose()}
        }finally{$zip.Dispose()}
    }finally{$stream.Dispose()}
    $score=$xml.SelectSingleNode('/museScore/Score')
    $map=$score.SelectSingleNode("metaTag[@name='psalmist-playback-review']").InnerText|ConvertFrom-Json
    $count=$score.SelectNodes('Staff[1]/Measure').Count
    if($map.version -ne 1 -or $map.measures -ne $count -or -not $map.songs.Count){throw 'Review map does not match the score.'}
    $ids=@{};$end=0
    foreach($song in $map.songs){
        if(-not $song.id -or $ids.ContainsKey([string]$song.id) -or $song.start -ne $end+1 -or $song.end -lt $song.start -or $song.end -gt $count){throw 'Invalid song boundaries in review book.'}
        $ids[[string]$song.id]=$true;$end=[int]$song.end
    }
    if($end -ne $count){throw 'Review map does not cover the book.'}
    $templates=@($score.SelectNodes('Staff[1]/Measure[1]//SystemText') | ForEach-Object {$_.z})
    if($map.swing_ratio -ne 100 -or '9001' -notin $templates -or '9100' -notin $templates -or '9200' -notin $templates){throw 'Adjustable feel templates are missing from the selected book.'}
    foreach($song in $map.songs){
        $measure=$score.SelectNodes('Staff[1]/Measure')[[int]$song.start-1]
        if(-not $measure.SelectSingleNode('.//Tempo') -or -not $measure.SelectSingleNode('.//SystemText[swing]')){throw 'Tempo or feel controls are missing from a song.'}
    }
    return @{xml=$xml;score=$score;map=$map}
}
try {
    $request=[IO.File]::ReadAllText($RequestPath,$utf8)|ConvertFrom-Json
    if($request.token -notmatch '^\d+-\d+$' -or $request.mode -notin 'check','checkpoint' -or [int]$request.version -notin 4,5){throw 'Invalid book switch request.'}
    $current=[IO.Path]::GetFullPath([string]$request.score_path)
    if([IO.Path]::GetExtension($current) -ne '.mscz' -or -not [IO.File]::Exists($current)){throw 'The current review score is missing.'}
    $folder=[IO.Path]::GetDirectoryName($current)
    $file=[string]$request.target_file
    if($file -cnotmatch '^(Hymns|Choruses)-\d{2}-review\.mscz$|^Sunday-School-Choruses-review\.mscz$'){throw 'Choose a review book from the list.'}
    $catalog=[IO.File]::ReadAllText((Join-Path $folder 'sections.json'),$utf8)|ConvertFrom-Json
    $rows=@($catalog|Where-Object {$_.file -ceq $file})
    if($rows.Count -ne 1){throw 'The selected section is missing or duplicated in sections.json.'}
    $row=$rows[0];$target=Join-Path $folder $file
    if($target -eq $current){throw 'That book is already open.'}
    $next=Read-Book $target
    if($next.map.source_sha256 -cne $row.source_sha256 -or $next.map.songs.Count -ne $row.songs -or ($row.first -and $next.map.songs[0].id -cne $row.first) -or ($row.last -and $next.map.songs[-1].id -cne $row.last)){throw 'Selected book differs from its catalogue entry.'}
    if([int]$request.version -eq 4 -and [double]$next.xml.DocumentElement.GetAttribute('version') -ge 5){throw 'This book requires MuseScore 5. Use the included MuseScore 5 app.'}
    if($request.mode -eq 'checkpoint') {
        $saved=$null
        for($attempt=0;$attempt -lt 240;$attempt++) {
            try {
                $saved=Read-Book $current
                if($saved.score.SelectSingleNode("metaTag[@name='psalmist-book-switch-token']").InnerText -ceq $request.token){break}
                $saved=$null
            }catch{$saved=$null}
            Start-Sleep -Milliseconds 500
        }
        if(-not $saved){throw 'Book save was not verified. The current book will stay open; retry switching.'}
        if($saved.map.source_sha256 -cne $request.source_sha256){throw 'Saved book identity changed.'}
        foreach($field in @(@('psalmist-review-decisions','decisions_json'),@('psalmist-shared-revisions','revisions_json'))) {
            $tag=$saved.score.SelectSingleNode("metaTag[@name='$($field[0])']")
            $actual=if($tag){$tag.InnerText}else{''}
            if($actual -cne [string]$request.($field[1])){throw 'Saved review answers changed. The current book will stay open.'}
        }
    }
    $result=@{ok=$true;token=$request.token;target_path=$target;target_source_sha256=$next.map.source_sha256;target_first=$next.map.songs[0].id;target_last=$next.map.songs[-1].id}
}catch{$result=@{ok=$false;token=$request.token;error=$_.Exception.Message}}
$resultPath=$RequestPath+'.result.json';$temporary=$resultPath+'.tmp'
[IO.File]::WriteAllText($temporary,($result|ConvertTo-Json -Compress),$utf8)
[IO.File]::Move($temporary,$resultPath)
if(-not $result.ok){exit 1}
