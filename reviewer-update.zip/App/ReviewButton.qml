import QtQuick
import QtQuick.Controls as Controls

Controls.Button {
    id: control
    property bool primary: false
    property bool heading: false
    implicitHeight: heading ? 24 : 28
    implicitWidth: Math.max(48, label.implicitWidth + 16)
    leftPadding: 6; rightPadding: 6; topPadding: 2; bottomPadding: 2
    activeFocusOnTab: !heading
    Accessible.role: heading ? Accessible.StaticText : Accessible.Button
    hoverEnabled: true
    contentItem: Text {
        id: label
        text: control.text; font.pixelSize: 13; font.family: "Segoe UI"
        font.bold: control.heading
        color: control.enabled ? (control.primary ? "#171c22" : "#f2ede3") : "#697480"
        horizontalAlignment: control.heading ? Text.AlignLeft : Text.AlignHCenter; verticalAlignment: Text.AlignVCenter
        elide: Text.ElideRight
    }
    background: Rectangle {
        visible: !control.heading
        radius: 5
        color: control.primary ? (control.down ? "#ab9368" : control.hovered ? "#e5cfa7" : "#d8bd8e") :
               control.down ? "#323d49" : control.hovered ? "#303943" : "#252d36"
        border.color: control.activeFocus ? "#d8bd8e" : "#3a4550"
        Behavior on color { ColorAnimation { duration: 90 } }
    }
}
