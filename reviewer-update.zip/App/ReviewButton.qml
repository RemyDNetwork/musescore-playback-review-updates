import QtQuick
import QtQuick.Controls as Controls

Controls.Button {
    id: control
    property bool primary: false
    implicitHeight: 36
    implicitWidth: Math.max(72, label.implicitWidth + 28)
    hoverEnabled: true
    contentItem: Text {
        id: label
        text: control.text; font.pixelSize: 13; font.family: "Segoe UI"
        color: control.enabled ? (control.primary ? "#171c22" : "#f2ede3") : "#697480"
        horizontalAlignment: Text.AlignHCenter; verticalAlignment: Text.AlignVCenter
        elide: Text.ElideRight
    }
    background: Rectangle {
        radius: 8
        color: control.primary ? (control.down ? "#ab9368" : control.hovered ? "#e5cfa7" : "#d8bd8e") :
               control.down ? "#323d49" : control.hovered ? "#303943" : "#252d36"
        border.color: control.activeFocus ? "#d8bd8e" : "#3a4550"
        Behavior on color { ColorAnimation { duration: 90 } }
    }
}
