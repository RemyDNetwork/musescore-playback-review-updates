param([string]$Destination, [Parameter(ValueFromRemainingArguments=$true)][string[]]$Paths)
$ErrorActionPreference='Stop'
Add-Type -AssemblyName System.IO.Compression.FileSystem
$utf8=New-Object Text.UTF8Encoding($false)
if (-not $Paths) { throw 'Close the book in MuseScore, then drag it onto RepairMixerNames.cmd.' }
if ($Destination -and $Paths.Count -ne 1) { throw 'Destination requires exactly one book.' }
foreach ($path in $Paths) {
    $source=[IO.Path]::GetFullPath($path)
    if ([IO.Path]::GetExtension($source) -ne '.mscz') { throw 'Select .mscz books.' }
    $target=if ($Destination) { [IO.Path]::GetFullPath($Destination) } else { Join-Path ([IO.Path]::GetDirectoryName($source)) ([IO.Path]::GetFileNameWithoutExtension($source)+'-named.mscz') }
    if ([IO.File]::Exists($target)) { throw "Already exists: $target. Existing files are never overwritten." }
    $archive=[IO.Compression.ZipFile]::OpenRead($source)
    try {
        $xmlEntries=@($archive.Entries | Where-Object { $_.FullName.EndsWith('.mscx') })
        if ($xmlEntries.Count -ne 1) { throw 'Expected one score XML entry.' }
        $reader=New-Object IO.StreamReader($xmlEntries[0].Open(),$utf8)
        try { $text=$reader.ReadToEnd() } finally { $reader.Dispose() }
        $parts=[regex]::Matches($text,'(?s)<Part\b[^>]*>.*?</Part>')
        if (-not $parts.Count) { throw 'No instrument parts found.' }
        $missing=0; $named=0
        foreach ($part in $parts) {
            $doc=New-Object Xml.XmlDocument; $doc.XmlResolver=$null; $doc.LoadXml($part.Value)
            $long=$doc.SelectSingleNode('/Part/Instrument/InstrumentLabel/longName | /Part/Instrument/longName')
            if ($null -ne $long -and $long.InnerText.Trim()) { $named++; continue }
            $name=$doc.SelectSingleNode('/Part/trackName')
            if ($null -eq $name -or -not $name.InnerText.Trim()) { $name=$doc.SelectSingleNode('/Part/Instrument/trackName') }
            if ($null -eq $name -or -not $name.InnerText.Trim()) { throw 'A blank part has no stored name; output refused.' }
            $instrument=[regex]::Match($part.Value,'(?s)<Instrument\b[^>]*>.*?</Instrument>')
            if (-not $instrument.Success) { throw 'Instrument definition missing.' }
            $label='<longName>'+[Security.SecurityElement]::Escape($name.InnerText)+'</longName>'
            $fixed=if ($null -ne $long) { [regex]::Replace($instrument.Value,'(?s)<longName(?:\s[^>]*)?>.*?</longName>|<longName\s*/>',[Text.RegularExpressions.MatchEvaluator]{param($match) $label}) } elseif ($null -ne $doc.SelectSingleNode('/Part/Instrument/InstrumentLabel')) {
                if ($instrument.Value -match '<InstrumentLabel\s*/>') { [regex]::Replace($instrument.Value,'<InstrumentLabel\s*/>',[Text.RegularExpressions.MatchEvaluator]{param($match) '<InstrumentLabel>'+$label+'</InstrumentLabel>'}) }
                else { [regex]::Replace($instrument.Value,'(<InstrumentLabel\b[^>]*>)',[Text.RegularExpressions.MatchEvaluator]{param($match) $match.Groups[1].Value+$label}) }
            } else { [regex]::Replace($instrument.Value,'^(<Instrument\b[^>]*>)',[Text.RegularExpressions.MatchEvaluator]{param($match) $match.Groups[1].Value+$label}) }
            $text=$text.Replace($part.Value,$part.Value.Replace($instrument.Value,$fixed)); $missing++
        }
        # Mixed visible/blank labels need individual engraving decisions, not a global hide.
        if ($missing -and $named) { throw 'Mixed printed instrument labels; automatic repair refused.' }
        $style=$archive.GetEntry('score_style.mss'); $styleText=$null
        if ($missing) {
            if ($null -eq $style) { throw 'External score style missing; output refused.' }
            $reader=New-Object IO.StreamReader($style.Open(),$utf8)
            try { $styleText=$reader.ReadToEnd() } finally { $reader.Dispose() }
            foreach ($tag in 'firstSystemInstNameVisibility','subsSystemInstNameVisibility') {
                if ($styleText -match "<$tag>.*?</$tag>") { $styleText=[regex]::Replace($styleText,"<$tag>.*?</$tag>","<$tag>2</$tag>") }
                else { $styleText=$styleText.Replace('</Style>',"<$tag>2</$tag></Style>") }
            }
        }
        $stream=[IO.File]::Open($target,[IO.FileMode]::CreateNew)
        $output=New-Object IO.Compression.ZipArchive($stream,[IO.Compression.ZipArchiveMode]::Create,$false)
        try {
            foreach ($entry in $archive.Entries) {
                $dest=$output.CreateEntry($entry.FullName); $outStream=$dest.Open()
                try {
                    $replacement=if ($entry.FullName -eq $xmlEntries[0].FullName) { $text } elseif ($missing -and $entry.FullName -eq 'score_style.mss') { $styleText } else { $null }
                    if ($null -ne $replacement) { $bytes=$utf8.GetBytes($replacement); $outStream.Write($bytes,0,$bytes.Length) }
                    else { $inputStream=$entry.Open(); try { $inputStream.CopyTo($outStream) } finally { $inputStream.Dispose() } }
                } finally { $outStream.Dispose() }
            }
        } finally { $output.Dispose(); $stream.Dispose() }
        Write-Output "Created $target ($missing mixer names restored). Original book and CSVs unchanged."
    } finally { $archive.Dispose() }
}
