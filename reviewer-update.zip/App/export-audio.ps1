param([Parameter(Mandatory=$true)][string]$RequestPath, [switch]$PrepareOnly)
$ErrorActionPreference='Stop'
Add-Type -AssemblyName System.IO.Compression.FileSystem
Add-Type -AssemblyName System.IO.Compression
Add-Type -Path (Join-Path $PSScriptRoot 'ExportScore.cs') -ReferencedAssemblies 'System.Xml.dll','System.dll'
$utf8=New-Object Text.UTF8Encoding($false)
$work=$null;$renderer=$null;$outputTemp=$null
function Set-Text($node,$name,$value) {
    $child=$node.SelectSingleNode($name)
    if($null -eq $child){$child=$node.OwnerDocument.CreateElement($name);[void]$node.AppendChild($child)}
    $child.InnerText=[string]$value
}
function Number($value,$low,$high) {
    $n=[double]::Parse([string]$value,[Globalization.CultureInfo]::InvariantCulture)
    if([double]::IsNaN($n) -or [double]::IsInfinity($n) -or $n -lt $low -or $n -gt $high){throw 'Invalid export playback value.'}
    return $n
}
try {
    $request=[IO.File]::ReadAllText($RequestPath,$utf8)|ConvertFrom-Json
    if([string]$request.token -notmatch '^\d+-\d+$' -or $request.mode -notin 'part','full'){throw 'Invalid export request.'}
    $scorePath=[IO.Path]::GetFullPath([string]$request.score_path)
    if([IO.Path]::GetExtension($scorePath) -ne '.mscz'){throw 'Export requires a local review book.'}
    $stream=[IO.File]::Open($scorePath,[IO.FileMode]::Open,[IO.FileAccess]::Read,([IO.FileShare]::ReadWrite -bor [IO.FileShare]::Delete))
    try{$zip=New-Object IO.Compression.ZipArchive($stream,[IO.Compression.ZipArchiveMode]::Read)}catch{$stream.Dispose();throw}
    try {
        $entry=@($zip.Entries|Where-Object {$_.FullName.EndsWith('.mscx')})
        if($entry.Count -ne 1 -or $entry[0].Length -gt 1GB){throw 'Invalid score archive.'}
        $settings=New-Object Xml.XmlReaderSettings;$settings.DtdProcessing=[Xml.DtdProcessing]::Prohibit;$settings.XmlResolver=$null
        $reader=[Xml.XmlReader]::Create($entry[0].Open(),$settings)
        $map=$null
        try {
            while(-not $reader.EOF) {
                if($reader.NodeType -eq [Xml.XmlNodeType]::Element -and $reader.Name -eq 'metaTag' -and $reader.GetAttribute('name') -eq 'psalmist-playback-review') {$map=$reader.ReadElementContentAsString()|ConvertFrom-Json;break}
                if($reader.NodeType -eq [Xml.XmlNodeType]::Element -and $reader.Depth -eq 2 -and $reader.Name -in 'Staff','Part','Style','Score'){$reader.Skip()}else{[void]$reader.Read()}
            }
        }finally{$reader.Dispose()}
        if(-not $map -or $map.source_sha256 -cne $request.book_source_sha256){throw 'Export book identity changed. Reopen the panel.'}
        $song=@($map.songs|Where-Object {$_.id -ceq $request.song_id})
        if($song.Count -ne 1){throw 'Unknown export song.'};$song=$song[0]
        $reader=[Xml.XmlReader]::Create($entry[0].Open(),$settings)
        try{$xml=[PsalmistAudioCrop]::Read($reader,([int]$song.start-1),([int]$song.end-1))}finally{$reader.Dispose()}
    }finally{$zip.Dispose()}
    $score=$xml.SelectSingleNode('/museScore/Score')
    $map=$score.SelectSingleNode("metaTag[@name='psalmist-playback-review']").InnerText|ConvertFrom-Json
    if($map.source_sha256 -cne $request.book_source_sha256){throw 'Export book identity changed. Reopen the panel.'}
    $song=@($map.songs|Where-Object {$_.id -ceq $request.song_id})
    if($song.Count -ne 1){throw 'Unknown export song.'};$song=$song[0]
    $start=0;$end=[int]$song.end-[int]$song.start
    $staves=@($score.SelectNodes('Staff'));$parts=@($score.SelectNodes('Part'))
    if($start -lt 0 -or $end -lt $start -or $end -ge $staves[0].SelectNodes('Measure').Count){throw 'Invalid song range.'}
    $passes=1;$gapBars=0
    if($request.mode -eq 'full') {
        $passes=0
        $frame=$staves[0].SelectNodes('Measure')[$start].PreviousSibling
        while($frame -and $frame.Name -ne 'Measure') {
            foreach($caption in $frame.SelectNodes('.//text')) {
                if($caption.InnerText -match '(?i)\b([1-9][0-9]?)\s+verses?\b'){$passes=[int]$matches[1];break}
            }
            if($passes -gt 0){break}
            $frame=$frame.PreviousSibling
        }
        if($null -ne $request.verse_count) {
            $count=Number $request.verse_count 1 32
            if($count -ne [Math]::Floor($count)){throw 'Enter a whole number of verses.'}
            if($passes -gt 0 -and $passes -ne $count){throw 'Verse count changed in the saved header. Reopen the panel and export again.'}
            $passes=[int]$count
        }
        if(-not $passes){throw 'The score has no verse count. Enter the number of verses in MP3 Full.'}
        if($null -ne $request.verse_break_seconds){throw 'Export settings changed to bars. Close the panel and reopen it from the updated kit.'}
        if($null -ne $request.verse_break_bars){$gapBars=Number $request.verse_break_bars 0 16}
        if($gapBars -ne [Math]::Floor($gapBars)){throw 'Enter a whole number of break bars.'}
    }
    if($passes -gt 32){throw 'Verse count exceeds 32; check the score header.'}
    $ratio=Number $request.swing_ratio 0 100
    if($request.feel -notin 'straight','swing' -or $ratio -ne [Math]::Floor($ratio)){throw 'Invalid export feel.'}
    for($si=0;$si -lt $staves.Count;$si++) {
        $staff=$staves[$si];$bars=@($staff.SelectNodes('Measure'));$first=$bars[$start]
        # Cropping must retain inherited key, meter and clef, including transposing staves.
        foreach($tag in 'KeySig','TimeSig','Clef') {
            if($first.SelectSingleNode('.//'+$tag)){continue}
            $last=$null
            for($mi=0;$mi -lt $start;$mi++){foreach($node in $bars[$mi].SelectNodes('.//'+$tag)){$last=$node}}
            if($last){[void]$first.SelectSingleNode('voice').PrependChild($last.CloneNode($true))}
        }
        for($mi=$start;$mi -le $end;$mi++) {
            $bar=$mi-$start+1;$measure=$bars[$mi]
            $voices=@($measure.SelectNodes('voice'))
            for($vi=0;$vi -lt $voices.Count;$vi++) {
                $track=$si*4+$vi
                $ts=@($request.tempos|Where-Object {$_.bar -eq $bar -and $_.track -eq $track})
                $nodes=@($voices[$vi].SelectNodes('Tempo'))
                if($ts.Count -ne $nodes.Count){throw "Tempo map changed at bar $bar. Save the review and retry export."}
                for($i=0;$i -lt $nodes.Count;$i++) {
                    $bpm=Number $ts[$i].quarter_bpm 20 600
                    Set-Text $nodes[$i] 'tempo' (($bpm/60).ToString('R',[Globalization.CultureInfo]::InvariantCulture))
                    Set-Text $nodes[$i] 'followText' '0'
                }
                $hs=@($request.holds|Where-Object {$_.bar -eq $bar -and $_.tracks -contains $track})
                $nodes=@($voices[$vi].SelectNodes('Fermata'))
                if($hs.Count -ne $nodes.Count){throw "Fermata map changed at bar $bar. Save the review and retry export."}
                for($i=0;$i -lt $nodes.Count;$i++) {
                    $pct=Number $hs[$i].percent 100 1000
                    Set-Text $nodes[$i] 'timeStretch' (($pct/100).ToString('R',[Globalization.CultureInfo]::InvariantCulture))
                }
            }
        }
        foreach($node in @($staff.ChildNodes)){if($node.Name -ne 'Measure' -or [array]::IndexOf($bars,$node) -lt $start -or [array]::IndexOf($bars,$node) -gt $end){[void]$staff.RemoveChild($node)}}
        # Review playback deliberately uses a single linear pass, without notation jumps/repeats.
        foreach($node in @($staff.SelectNodes('.//startRepeat|.//endRepeat|.//Jump|.//Marker|.//Spanner[@type="Volta"]|.//SystemText[swing]'))){[void]$node.ParentNode.RemoveChild($node)}
    }
    $voice=$staves[0].SelectSingleNode('Measure/voice')
    $feel=$xml.CreateElement('SystemText');[void]$voice.PrependChild($feel)
    Set-Text $feel 'text' $(if($request.feel -eq 'swing'){'Swing'}else{'Straight'})
    $swing=$xml.CreateElement('swing');$swing.SetAttribute('unit',$(if($request.feel -eq 'swing'){'eighth'}else{'zero'}));$swing.SetAttribute('ratio',[string]$ratio);[void]$feel.AppendChild($swing)
    foreach($node in @($score.SelectNodes('Excerpt|Score|metaTag[starts-with(@name,"psalmist-")]'))){[void]$score.RemoveChild($node)}
    # Filter global 5.x spanners to this song and give every repeated pass independent IDs/ties.
    [PsalmistAudioCrop]::Repeat($xml,$passes,[int]$gapBars)
    $channels=@($request.channels)
    $primary=@($channels|Where-Object {-not $_.secondary})
    if($primary.Count -ne $parts.Count){throw 'Mixer is incomplete. Wait for it to load before exporting.'}
    $audio=@{activeSoundProfile='MuseScore Basic';master=@{balance=0;fxChain=@{};volumeDb=(Number $request.master_db -120 12)};aux=@();tracks=@()}
    $anySolo=@($channels|Where-Object {$_.solo}).Count -gt 0
    foreach($ch in $channels) {
        $index=[int]$ch.part_index
        if($index -lt 0 -or $index -ge $parts.Count -or $ch.sound -notmatch '^SoundFonts\\MS Basic\\([0-9]+)\\([0-9]+)$'){throw 'Export supports the prepared MS Basic instruments only.'}
        $bank=[int]$matches[1];$program=[int]$matches[2]
        if($bank -gt 16383 -or $program -gt 127){throw 'Invalid instrument preset.'}
        $part=$parts[$index];$inst=$part.SelectSingleNode('Instrument')
        $native=if($ch.secondary){$inst.SelectSingleNode('Channel[@name="harmony"]')}else{$inst.SelectSingleNode('Channel[not(@name) or @name="normal"]')}
        if(-not $native){throw 'Instrument routing changed. Reopen the panel.'}
        $pg=$native.SelectSingleNode('program');if(-not $pg){$pg=$xml.CreateElement('program');[void]$native.AppendChild($pg)};$pg.SetAttribute('value',[string]$program)
        foreach($ctrl in @(0,32)) {
            $node=$native.SelectSingleNode('controller[@ctrl="'+$ctrl+'"]');if(-not $node){$node=$xml.CreateElement('controller');$node.SetAttribute('ctrl',[string]$ctrl);[void]$native.AppendChild($node)}
            $node.SetAttribute('value',[string]$(if($ctrl -eq 0){[Math]::Floor($bank/128)}else{$bank%128}))
        }
        $db=Number $ch.db -120 12
        # CLI export can ignore audition Solo; bake its effective silence into this copy's track levels.
        if($ch.mute -or ($anySolo -and -not $ch.solo)){$db=-120}
        $audio.tracks+=@{partId=$part.GetAttribute('id');instrumentId=$(if($ch.secondary){'chord_symbols'}else{$inst.GetAttribute('id')});
            'in'=@{resourceMeta=@{id=([string]$ch.sound).Substring(11);type='fluid_soundfont';vendor='Fluid';hasNativeEditorSupport=$false;attributes=@{soundFontName='MS Basic';playbackSetupData='last.last.last';presetBank=[string]$bank;presetProgram=[string]$program}};unitConfiguration=@{}};
            'out'=@{volumeDb=$db;balance=0;fxChain=@{}};soloMuteState=@{mute=[bool]$ch.mute;solo=[bool]$ch.solo}}
    }
    $work=Join-Path ([IO.Path]::GetDirectoryName($RequestPath)) ('audio-work-'+$request.token)
    [void][IO.Directory]::CreateDirectory($work)
    $preparedScore=Join-Path $work 'song.mscz'
    $zip=[IO.Compression.ZipFile]::Open($preparedScore,[IO.Compression.ZipArchiveMode]::Create)
    try {
        foreach($entryData in @(@{name='song.mscx';text=$xml.OuterXml},@{name='audiosettings.json';text=($audio|ConvertTo-Json -Depth 20 -Compress)})) {
            $entry=$zip.CreateEntry($entryData.name);$writer=New-Object IO.StreamWriter($entry.Open(),$utf8)
            try{$writer.Write($entryData.text)}finally{$writer.Dispose()}
        }
    }finally{$zip.Dispose()}
    if($PrepareOnly){$result=@{ok=$true;token=$request.token;passes=$passes;verse_break_bars=$gapBars;prepared_path=$preparedScore}}
    else {
        $runtime=[IO.File]::ReadAllText((Join-Path $PSScriptRoot 'runtime.json'))|ConvertFrom-Json
        $exe=[string]$runtime.musescore_path
        if(-not [IO.File]::Exists($exe) -or [IO.Path]::GetFileName($exe) -notin 'MuseScore4.exe','MuseScoreStudio5.exe','MuseScore5.exe'){throw 'Renderer missing. Restart through START HERE.'}
        $folder=Join-Path ([IO.Path]::GetDirectoryName($scorePath)) 'Exports';[void][IO.Directory]::CreateDirectory($folder)
        $safe=([string]$song.id+' - '+[string]$song.title) -replace '[<>:"/\\|?*\x00-\x1f]','_';$safe=$safe.Trim().TrimEnd('.')
        if($safe.Length -gt 100){$safe=$safe.Substring(0,100)}
        $output=Join-Path $folder ($safe+' - '+$request.mode+' - '+$request.token+'.mp3')
        $outputTemp=Join-Path $work 'render.mp3'
        $psi=New-Object Diagnostics.ProcessStartInfo;$psi.FileName=$exe;$psi.Arguments='-b 192 -o "'+$outputTemp+'" "'+$preparedScore+'"'
        $psi.UseShellExecute=$false;$psi.CreateNoWindow=$true;$psi.WindowStyle=[Diagnostics.ProcessWindowStyle]::Hidden
        $psi.RedirectStandardOutput=$true;$psi.RedirectStandardError=$true
        $renderer=New-Object Diagnostics.Process;$renderer.StartInfo=$psi;[void]$renderer.Start()
        $stdout=$renderer.StandardOutput.ReadToEndAsync();$stderr=$renderer.StandardError.ReadToEndAsync();$deadline=(Get-Date).AddMinutes(15)
        while(-not $renderer.WaitForExit(200)) {
            if([IO.File]::Exists($RequestPath+'.cancel')){throw 'MP3 export cancelled. Your score and reviews are unchanged.'}
            if((Get-Date) -gt $deadline){throw 'MP3 rendering timed out. Your score and reviews are unchanged.'}
        }
        if([IO.File]::Exists($RequestPath+'.cancel')){throw 'MP3 export cancelled.'}
        if($renderer.ExitCode -ne 0 -or -not [IO.File]::Exists($outputTemp) -or (Get-Item -LiteralPath $outputTemp).Length -lt 1000){throw 'MuseScore could not render this song. Your score and reviews are unchanged.'}
        [IO.File]::Move($outputTemp,$output)
        $result=@{ok=$true;token=$request.token;passes=$passes;verse_break_bars=$gapBars;mp3_path=$output}
    }
}catch{$result=@{ok=$false;token=$request.token;error=$_.Exception.Message}}
finally {
    if($renderer){if(-not $renderer.HasExited){$renderer.Kill();$renderer.WaitForExit()};$renderer.Dispose()}
    if($work -and -not $PrepareOnly -and [IO.Directory]::Exists($work)){
        $expected=Join-Path ([IO.Path]::GetDirectoryName([IO.Path]::GetFullPath($RequestPath))) ('audio-work-'+$request.token)
        if([IO.Path]::GetFullPath($work) -ceq $expected){Remove-Item -LiteralPath $work -Recurse -Force}
    }
}
$resultPath=$RequestPath+'.result.json';[IO.File]::WriteAllText($resultPath+'.tmp',($result|ConvertTo-Json -Compress),$utf8)
[IO.File]::Move($resultPath+'.tmp',$resultPath)
if(-not $result.ok){exit 1}

