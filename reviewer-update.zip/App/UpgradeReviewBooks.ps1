param([Parameter(ValueFromRemainingArguments=$true)][string[]]$Paths)
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.IO.Compression.FileSystem
$utf8 = New-Object Text.UTF8Encoding($false)
if (-not $Paths) { throw 'Drag existing review .mscz files onto UpgradeReviewBooks.cmd. Close them in MuseScore first.' }
foreach ($path in $Paths) {
    $source = [IO.Path]::GetFullPath($path)
    if ([IO.Path]::GetExtension($source) -ne '.mscz') { throw 'Select .mscz review books.' }
    $destination = Join-Path ([IO.Path]::GetDirectoryName($source)) ([IO.Path]::GetFileNameWithoutExtension($source) + '-v04.mscz')
    if ([IO.File]::Exists($destination)) { throw "Already exists: $destination. Existing files are never overwritten." }
    $archive = [IO.Compression.ZipFile]::OpenRead($source)
    try {
        $entries = @($archive.Entries | Where-Object { $_.FullName.EndsWith('.mscx') })
        if ($entries.Count -ne 1) { throw 'Expected one score XML entry.' }
        $reader = New-Object IO.StreamReader($entries[0].Open(), $utf8)
        try { $xmlText = $reader.ReadToEnd() } finally { $reader.Dispose() }
        $settings = New-Object Xml.XmlReaderSettings
        $settings.DtdProcessing = [Xml.DtdProcessing]::Prohibit
        $settings.XmlResolver = $null
        $reader = [Xml.XmlReader]::Create((New-Object IO.StringReader($xmlText)), $settings)
        $doc = New-Object Xml.XmlDocument
        $doc.PreserveWhitespace = $true; $doc.XmlResolver = $null
        try { $doc.Load($reader) } finally { $reader.Dispose() }
        # Clone normalizes explicit empty tags; compare equivalent DOM serializations.
        $before = $doc.CloneNode($true).OuterXml
        $mapTag = $doc.SelectSingleNode("/museScore/Score/metaTag[@name='psalmist-playback-review']")
        if ($null -eq $mapTag) { throw 'This is not a prepared review book.' }
        $mapBefore = $mapTag.InnerText
        $originalMap = $mapTag.CloneNode($true)
        $map = $mapBefore | ConvertFrom-Json
        $voice = $doc.SelectSingleNode('/museScore/Score/Staff/Measure/voice')
        if ($null -ne $voice.SelectSingleNode("SystemText[z >= 9100 and z <= 9200]")) { throw 'This book already supports adjustable swing.' }
        for ($ratio = 0; $ratio -le 100; $ratio++) {
            $template = $doc.CreateElement('SystemText')
            foreach ($pair in @(@('text',''),@('visible','0'),@('z',[string](9100+$ratio)))) {
                $child = $doc.CreateElement($pair[0]); $child.InnerText = $pair[1]
                [void]$template.AppendChild($child)
            }
            $swing = $doc.CreateElement('swing'); $swing.SetAttribute('unit','eighth'); $swing.SetAttribute('ratio',[string]$ratio)
            [void]$template.AppendChild($swing); [void]$voice.AppendChild($template)
        }
        $measures = @($doc.SelectSingleNode('/museScore/Score/Staff').SelectNodes('Measure'))
        foreach ($song in $map.songs) {
            $swing = $measures[[int]$song.start-1].SelectSingleNode(".//SystemText[text='Straight' or text='Swing']/swing")
            if ($null -eq $swing) { throw "Native feel missing: $($song.id)" }
            $song | Add-Member -NotePropertyName native_swing_ratio -NotePropertyValue ([int]$swing.GetAttribute('ratio')) -Force
        }
        $mapTag.InnerText = $map | ConvertTo-Json -Depth 20 -Compress
        # Verify the upgrade changes only the review map and inactive templates.
        $check = $doc.CloneNode($true)
        foreach ($item in @($check.SelectNodes('/museScore/Score/Staff/Measure/voice/SystemText[z >= 9100 and z <= 9200]'))) { [void]$item.ParentNode.RemoveChild($item) }
        $checkMap = $check.SelectSingleNode("/museScore/Score/metaTag[@name='psalmist-playback-review']")
        [void]$checkMap.ParentNode.ReplaceChild($check.ImportNode($originalMap,$true),$checkMap)
        if ($check.OuterXml -cne $before) { throw 'Upgrade changed notation; output refused.' }
        $stream = [IO.File]::Open($destination, [IO.FileMode]::CreateNew)
        $output = New-Object IO.Compression.ZipArchive($stream, [IO.Compression.ZipArchiveMode]::Create, $false)
        try {
            foreach ($entry in $archive.Entries) {
                $target = $output.CreateEntry($entry.FullName); $targetStream = $target.Open()
                try {
                    if ($entry.FullName -eq $entries[0].FullName) { $data = $utf8.GetBytes($doc.OuterXml); $targetStream.Write($data,0,$data.Length) }
                    else { $inputStream = $entry.Open(); try { $inputStream.CopyTo($targetStream) } finally { $inputStream.Dispose() } }
                } finally { $targetStream.Dispose() }
            }
        } finally { $output.Dispose(); $stream.Dispose() }
        Write-Output "Created $destination. Original book and reviewer CSVs are unchanged."
    } finally { $archive.Dispose() }
}
