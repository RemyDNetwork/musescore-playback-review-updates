param([ValidateSet('Hymns','Choruses','Sunday-School-Choruses')][string]$Book,
      [ValidateSet('4','5')][string]$Version, [string]$MuseScorePath,
      [string]$PluginDir, [switch]$InstallOnly, [string]$Section)
$ErrorActionPreference='Stop'
$kitRoot=Split-Path -Parent $PSScriptRoot
$bundledExe=Join-Path $kitRoot 'MuseScore5/bin/MuseScoreStudio5.exe'
$bundled=Test-Path -LiteralPath $bundledExe -PathType Leaf
if ($bundled -and -not $Version) { $Version='5' }
$interactive=-not $Book -or -not $Version
try {
    $sectionsPath=Join-Path $kitRoot 'Books/sections.json'
    $choices=if (Test-Path -LiteralPath $sectionsPath) { @(Get-Content -LiteralPath $sectionsPath -Raw -Encoding UTF8 | ConvertFrom-Json) } else {
        @('Hymns','Choruses','Sunday-School-Choruses') | ForEach-Object { [pscustomobject]@{collection=$_;file="$_-review.mscz";label=$_} }
    }
    if (-not $choices.Count -or @($choices.file | Select-Object -Unique).Count -ne $choices.Count) { throw 'Review section list is empty or contains duplicate files.' }
    foreach ($choice in $choices) {
        if ($choice.collection -notin @('Hymns','Choruses','Sunday-School-Choruses') -or $choice.file -notmatch ('^'+[regex]::Escape([string]$choice.collection)+'(-\d{2})?-review\.mscz$') -or [string]::IsNullOrWhiteSpace($choice.label)) { throw 'Invalid review section list.' }
    }
    if ($interactive) {
        Add-Type -AssemblyName System.Windows.Forms
        Add-Type -AssemblyName System.Drawing
        [Windows.Forms.Application]::EnableVisualStyles()
        $form=New-Object Windows.Forms.Form
        $form.Text='Psalmist Reviewer'; $form.ClientSize=New-Object Drawing.Size(480,310)
        $form.StartPosition='CenterScreen'; $form.FormBorderStyle='FixedDialog'; $form.MaximizeBox=$false
        $form.Font=New-Object Drawing.Font('Segoe UI',10)
        $heading=New-Object Windows.Forms.Label
        $heading.Text='Choose your review book'; $heading.SetBounds(24,18,430,28)
        $books=New-Object Windows.Forms.ComboBox
        $books.DropDownStyle='DropDownList'; $books.SetBounds(24,52,430,28)
        [void]$books.Items.AddRange([object[]]@($choices | ForEach-Object { $_.label }))
        $books.MaxDropDownItems=18; $books.IntegralHeight=$false; $books.DropDownHeight=420
        $versionLabel=New-Object Windows.Forms.Label
        $versionLabel.Text='Open with'; $versionLabel.SetBounds(24,96,100,25)
        $versions=New-Object Windows.Forms.ComboBox
        $versions.DropDownStyle='DropDownList'; $versions.SetBounds(128,92,326,28)
        [void]$versions.Items.AddRange(@('MuseScore 5','MuseScore 4.7.5')); $versions.SelectedIndex=1
        if ($bundled) { $versions.SelectedIndex=0; $versions.Enabled=$false; $versionLabel.Text='Included app' }
        $books.add_SelectedIndexChanged({
            if ($choices[$books.SelectedIndex].collection -eq 'Choruses') { $versions.SelectedIndex=0; $versions.Enabled=$false }
            else { $versions.Enabled=-not $bundled }
        })
        $books.SelectedIndex=0
        $help=New-Object Windows.Forms.Label
        $help.Text="Close MuseScore before starting.`r`nFirst time: enable Psalmist Playback Review in Plugins or Extensions, then restart through START HERE.`r`nThe book may take several minutes to load."
        if ($bundled) { $help.Text="MuseScore 5 is included. No installation or sign-in needed.`r`nClose MuseScore before starting. Once the book opens, choose Extensions > Psalmist Playback Review.`r`nHymns and Choruses are split into sections of up to 50 songs." }
        $help.SetBounds(24,138,430,94)
        $launch=New-Object Windows.Forms.Button
        $launch.Text='Open review book'; $launch.SetBounds(250,256,204,34)
        $launch.DialogResult=[Windows.Forms.DialogResult]::OK; $form.AcceptButton=$launch
        $form.Controls.AddRange(@($heading,$books,$versionLabel,$versions,$help,$launch))
        if ($form.ShowDialog() -ne [Windows.Forms.DialogResult]::OK) { $form.Dispose(); exit 0 }
        $Book=$choices[$books.SelectedIndex].collection
        $Section=$choices[$books.SelectedIndex].file
        $Version=@('5','4')[$versions.SelectedIndex]
        $form.Dispose()
    }
    if ($Book -eq 'Choruses' -and $Version -ne '5') { throw 'The Chorus book requires MuseScore 5. Choose version 5.' }
    $selected=@($choices | Where-Object { $_.collection -eq $Book -and (-not $Section -or $_.file -eq $Section) })
    if (-not $selected.Count) { throw 'Review section was not found. Choose a section from START HERE.' }
    $score=Join-Path $kitRoot ('Books/'+$selected[0].file)
    if (-not (Test-Path -LiteralPath $score -PathType Leaf)) { throw 'Books are missing. Extract or copy the WHOLE Psalmist Reviewer folder before starting.' }
    $exeNames=if ($Version -eq '5') { @('MuseScoreStudio5.exe','MuseScore5.exe') } else { @('MuseScore4.exe') }
    $useBundled=$bundled -and $Version -eq '5' -and -not $MuseScorePath
    if ($useBundled) { $MuseScorePath=$bundledExe }
    if (-not $MuseScorePath) {
        $candidates=@(Get-ChildItem -Path (Join-Path $env:ProgramFiles 'MuseScore*/bin/*.exe') -ErrorAction SilentlyContinue |
            Where-Object { $_.Name -in $exeNames } | Select-Object -ExpandProperty FullName)
        if ($candidates.Count) { $MuseScorePath=$candidates[0] }
    }
    if (-not $MuseScorePath -and $interactive) {
        $picker=New-Object Windows.Forms.OpenFileDialog
        $picker.Title="Locate your installed MuseScore $Version program (not a score file)"
        $picker.Filter='MuseScore program (*.exe)|*.exe'; $picker.CheckFileExists=$true
        if ($picker.ShowDialog() -eq [Windows.Forms.DialogResult]::OK) { $MuseScorePath=$picker.FileName }
        $picker.Dispose()
    }
    if (-not $MuseScorePath -or [IO.Path]::GetFileName($MuseScorePath) -notin $exeNames) { throw "MuseScore $Version was not found. Install the supported MuseScore version, or choose its program in the file picker." }
    & (Join-Path $PSScriptRoot 'StartReview.ps1') -Version $Version -MuseScorePath $MuseScorePath -PluginDir $PluginDir -ScorePath $score -Bundled:$useBundled -InstallOnly:$InstallOnly
} catch {
    if ($interactive) { [void][Windows.Forms.MessageBox]::Show($_.Exception.Message,'Psalmist Reviewer - could not start','OK','Error') }
    else { Write-Error $_.Exception.Message }
    exit 1
}
