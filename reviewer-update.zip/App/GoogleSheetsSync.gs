// Paste into the Apps Script project bound to the organiser's Google Sheet.
const REVIEW_FIELDS = ['id','title','reviewer','bpm','beat_unit','quarter_bpm','feel','swing_ratio','fermatas_json','status','reviewed_at','book_source_sha256','grace_notes_missing','score_has_issues','issue_notes','tempos_json'];
const SHEET_FIELDS = ['revision','mutation_id'].concat(REVIEW_FIELDS);

function setupSharedReviews() {
  const props = PropertiesService.getScriptProperties();
  const book = SpreadsheetApp.getActiveSpreadsheet();
  if (!book) throw new Error('Open this script from your Google Sheet: Extensions > Apps Script.');
  props.setProperty('SPREADSHEET_ID', book.getId());
  if (!props.getProperty('SYNC_KEY')) props.setProperty('SYNC_KEY', Utilities.getUuid()+Utilities.getUuid());
  const sheet = book.getSheetByName('SharedReviews') || book.insertSheet('SharedReviews');
  if (sheet.getLastRow() === 0) {
    sheet.getRange(1,1,1,SHEET_FIELDS.length).setValues([SHEET_FIELDS]);
    sheet.setFrozenRows(1);
    sheet.getRange(1,1,1,SHEET_FIELDS.length).setFontWeight('bold').setBackground('#d8bd8e');
  }
  console.log('Sync key (share only with reviewers): '+props.getProperty('SYNC_KEY'));
}

function validReview(row, hash, reviewer) {
  if (!row || typeof row !== 'object' || Array.isArray(row)) throw new Error('Invalid review.');
  const clean = {};
  REVIEW_FIELDS.forEach(function(field) {
    const value = row[field] == null ? '' : String(row[field]);
    if (value.length > (['issue_notes','fermatas_json','tempos_json'].includes(field) ? 30000 : 500)) throw new Error('Review text is too long.');
    clean[field] = value;
  });
  if (!/^[a-f0-9]{64}$/.test(hash) || clean.book_source_sha256 !== hash || clean.reviewer !== reviewer || !reviewer.trim() || reviewer.length > 120 || !/^[\w.-]{1,80}$/.test(clean.id)) throw new Error('Book, reviewer or song does not match.');
  if (clean.status !== 'confirmed' || !['straight','swing'].includes(clean.feel) || !['quarter','dotted_quarter','half'].includes(clean.beat_unit)) throw new Error('Invalid review settings.');
  if (!(Number(clean.bpm)>=20 && Number(clean.bpm)<=300 && Number(clean.quarter_bpm)>=20 && Number(clean.quarter_bpm)<=600) || !/^\d{1,3}$/.test(clean.swing_ratio) || Number(clean.swing_ratio)>100) throw new Error('Invalid tempo or swing.');
  if (!/^\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d\.\d{3}Z$/.test(clean.reviewed_at) || !Number.isFinite(Date.parse(clean.reviewed_at))) throw new Error('Invalid review time.');
  ['grace_notes_missing','score_has_issues'].forEach(function(field) { if (!['yes','no'].includes(clean[field])) throw new Error('Invalid answer.'); });
  const holds = JSON.parse(clean.fermatas_json);
  if (!Array.isArray(holds) || holds.length>1000 || holds.some(function(h) { return !h || typeof h.percent!=='number' || !Number.isFinite(h.percent) || h.percent<100 || h.percent>1000 || !Number.isInteger(h.bar) || h.bar<1 || !Number.isInteger(h.tick_offset) || h.tick_offset<0 || !Array.isArray(h.tracks) || !h.tracks.length || h.tracks.some(function(t) {return !Number.isInteger(t) || t<0;}); })) throw new Error('Invalid fermata lengths.');
  const tempos=JSON.parse(clean.tempos_json);
  if (!Array.isArray(tempos) || !tempos.length || tempos.length>1000 || tempos.some(function(t) {return !t || !Number.isInteger(t.tick_offset) || t.tick_offset<0 || !Number.isInteger(t.track) || t.track<0 || !Number.isInteger(t.bar) || t.bar<1 || !Number.isFinite(t.quarter_bpm) || t.quarter_bpm<20 || t.quarter_bpm>600;})) throw new Error('Invalid tempo details.');
  const factor={quarter:1,dotted_quarter:1.5,half:2}[clean.beat_unit];
  if(Math.abs(Number(clean.quarter_bpm)-Number(clean.bpm)*factor)>0.001 || !tempos.some(function(t){return t.tick_offset===0 && Math.abs(t.quarter_bpm-Number(clean.quarter_bpm))<0.001;})) throw new Error('Opening tempo does not match the review.');
  return clean;
}

function mergeReviews(existing, incoming, device, hash, reviewer) {
  if (!/^[a-f0-9-]{36}$/.test(device) || !Array.isArray(incoming) || incoming.length>2000) throw new Error('Invalid sync request.');
  const rows=existing.slice(), positions=new Map(), accepted=[], conflicts=[];
  function key(r) { return JSON.stringify([r.book_source_sha256,r.id]); }
  rows.forEach(function(row,index) {
    validReview(row,row.book_source_sha256,row.reviewer);
    if(!Number.isSafeInteger(Number(row.revision)) || Number(row.revision)<1 || Number(row.revision)>=Number.MAX_SAFE_INTEGER) throw new Error('Shared revision is damaged. Ask the organiser to restore SharedReviews.');
    const k=key(row); if(positions.has(k)) throw new Error('Duplicate shared song rows. Ask the organiser to repair SharedReviews.'); positions.set(k,index);
  });
  // Validate the complete batch before changing any shared row.
  const checked=incoming.map(function(raw) {
    const row=validReview(raw,hash,reviewer);
    if (!Number.isSafeInteger(Number(raw.base_revision)) || Number(raw.base_revision)<0 || typeof raw.mutation_id!=='string' || raw.mutation_id.length>500 || !raw.mutation_id.startsWith(device+'/')) throw new Error('Invalid revision or edit identity.');
    return {row:row,base:Number(raw.base_revision),mutation:raw.mutation_id};
  });
  const seen=new Set();
  checked.forEach(function(edit) {
    const row=edit.row, k=key(row), index=positions.get(k), current=index===undefined ? null : rows[index];
    if(seen.has(k)) throw new Error('Duplicate song in upload.'); seen.add(k);
    if (current && current.mutation_id===edit.mutation) {
      if (REVIEW_FIELDS.some(function(field) { return String(current[field] || '')!==row[field]; })) throw new Error('The same edit identity contains different answers. Save the answer again.');
      accepted.push(edit.mutation); return;
    }
    if (edit.base!==(current ? Number(current.revision) : 0)) {
      conflicts.push({id:row.id,local:row,shared:current,mutation_id:edit.mutation,revision:current ? Number(current.revision) : 0}); return;
    }
    const updated=Object.assign({revision:String((current ? Number(current.revision) : 0)+1),mutation_id:edit.mutation},row);
    if(index===undefined) {positions.set(k,rows.length);rows.push(updated);} else rows[index]=updated;
    accepted.push(edit.mutation);
  });
  if(rows.length>20000) throw new Error('Shared sheet limit reached (20,000 songs). Archive old books.');
  return {rows:rows,accepted:accepted,conflicts:conflicts,uploaded:rows.filter(function(row,index) {return row!==existing[index];}).length};
}
function doPost(e) {
  let lock;
  try {
    if (!e || !e.postData || e.postData.contents.length>4000000) throw new Error('Request too large or missing.');
    const request=JSON.parse(e.postData.contents), props=PropertiesService.getScriptProperties();
    const secret=props.getProperty('SYNC_KEY');
    if (!secret || request.key !== secret) throw new Error('Sync key was not accepted.');
    if (request.version !== 2 || !/^[a-f0-9]{64}$/.test(request.book_source_sha256) || typeof request.reviewer!=='string' || !request.reviewer.trim() || request.reviewer.length>120) throw new Error('Invalid sync request.');
    lock=LockService.getScriptLock();
    if (!lock.tryLock(20000)) throw new Error('Another reviewer is syncing. Try again shortly.');
    const sheet=SpreadsheetApp.openById(props.getProperty('SPREADSHEET_ID')).getSheetByName('SharedReviews');
    if (!sheet) throw new Error('Run setupSharedReviews first.');
    const data=sheet.getDataRange().getDisplayValues();
    if (JSON.stringify(data[0]) !== JSON.stringify(SHEET_FIELDS)) throw new Error('Reviews column headings changed. Ask the organiser to restore them.');
    const existing=data.slice(1).filter(function(values) { return values.some(Boolean); }).map(function(values) { const row={}; SHEET_FIELDS.forEach(function(field,i) { row[field]=values[i]; }); return row; });
    const merged=mergeReviews(existing,request.rows,request.device_id,request.book_source_sha256,request.reviewer);
    if (merged.uploaded) {
      const values=merged.rows.map(function(row) { return SHEET_FIELDS.map(function(field) {
        const value=String(row[field] || '');
        // Keep reviewer text literal, including spreadsheet formula prefixes.
        return /^[=+\-@'\t\r\n]/.test(value) ? "'"+value : value;
      }); });
      if (sheet.getMaxRows()<values.length+1) sheet.insertRowsAfter(sheet.getMaxRows(),values.length+1-sheet.getMaxRows());
      const range=sheet.getRange(2,1,values.length,SHEET_FIELDS.length);
      range.setNumberFormat('@'); range.setValues(values); SpreadsheetApp.flush();
    }
    const shared=merged.rows.filter(function(row) { return row.book_source_sha256===request.book_source_sha256; });
    return syncResponse({ok:true,version:2,book_source_sha256:request.book_source_sha256,uploaded:merged.uploaded,accepted:merged.accepted,conflicts:merged.conflicts,rows:shared,synced_at:new Date().toISOString()});
  } catch(error) { return syncResponse({ok:false,error:String(error.message || error)}); }
  finally { if(lock && lock.hasLock()) lock.releaseLock(); }
}

function syncResponse(value) {
  return ContentService.createTextOutput(JSON.stringify(value)).setMimeType(ContentService.MimeType.JSON);
}
