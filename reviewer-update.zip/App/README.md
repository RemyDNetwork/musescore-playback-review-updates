# Psalmist Playback Review — Windows

Version 0.13.0 for Windows. Targets the Books from `2026-10-15-named-playback`.
The compact panel defaults to 400 logical pixels wide and supports resizing down to 360.
Smaller buttons and two-row listening channels leave more room for the score.
Tempo, feel, bulk fermatas, review questions and MP3 exports are visible without opening sections.
Individual fermatas and Listening & instruments expand when needed; their long lists scroll.
The main content scrolls as one area, with Save score + CSV fixed at the bottom.
M / S are Mute / Solo; hover for the full channel-specific labels.
Reviewed / Not reviewed appears beside progress for the selected song. Unsaved edits are labelled separately; locally saved answers count even before upload.
Fermata holds includes Apply to all in song (100–1000%); other songs are unchanged.
Sync now / Cancel sync and shared status are directly below Reviewer name.
Use Settings beside Sync now for connection details and overlapping edits.
Short windows gain a scrollbar so expanded settings cannot hide the Save button.
START HERE checks for signed application updates before launching MuseScore.
The startup folder check accepts Windows cloud placeholders (including cloud-managed Desktop/Documents), while still rejecting junctions, symbolic links and unknown reparse types.
To repair an older kit reporting "Update folders must not be links", close MuseScore and replace only its root UpdateReview.ps1 with the file from this kit. Keep your existing Books and review files. This bootstrap fix cannot be installed by the older automatic updater.
Updates preserve Books, CSVs, MP3 exports, sync connections and personal settings.
Offline startup keeps the installed version. Source stays in the private GitHub
repository; the public download feed contains only application updates and requires
no reviewer sign-in. Existing older kits need this new kit once to gain the updater.
The automatic updater does not replace the bundled MuseScore runtime or bootstrap;
those changes require a new full kit. Maintainers: see `RELEASING.md`.
The portable USB kit includes the tested MuseScore 5 nightly and MS Basic soundfont.
It needs no installer, administrator access, Muse Hub, sign-in or additional sound download.
This is a standalone application bundle, not a zero-footprint portable profile: MuseScore
preferences and the review plugin are written to the reviewer's Windows user folders.
The included build remains an unstable prerelease; keep this tested build with the kit.
GUI-tested with MuseScore 4.7.5 and MuseScore 5.0.0
nightly `261008031-main-b30691a`. Future MuseScore builds may need a plugin update.
The package includes 837 hymn settings, 838 chorus settings and 78 Sunday School settings.
Hymns and Choruses each have 17 review sections of at most 50 songs. Choose a
section in START HERE; the plugin layout and controls are unchanged. Sunday School
remains one file. All sections retain original song IDs and shared book fingerprints,
so existing shared answers apply to the matching songs without a new Sheet setup.
Reviewer CSVs stay together in Books and can contain answers from every section.
Use the book dropdown above the song list and press **Switch** to change collection
or section without restarting the panel. Unconfirmed edits ask Save / Discard / Cancel.
The panel verifies the target and the current book's save before closing the old book;
saved decisions remain intact, and each book remembers its selected song. Keep the
same reviewer name and Books folder, including `sections.json`. The bundled 5 supports
all collections; 4.7.5 supports these Hymn and Sunday School books, while Choruses
require 5. A failed target check or save keeps the current book open. Sync in any Hymn section includes your saved answers from all Hymn
sections; Chorus sections work the same way. Hymns and Choruses sync separately,
so open each collection to send its pending offline answers. Returning to an
earlier section retains its saved decisions; shared answers apply when synced.
Keep your previous kit and reviewed books. For offline answers not yet synced,
copy your Review-*.csv files into the new Books folder before opening a section;
never overwrite a newer CSV. Sync uploads those saved answers, then applies shared
answers to the open section. Existing full books still work with this plugin.
Song searches require a unique match. For alternate tunes with the same title,
use the full ID (for example H010-T1 or H010-T2) or choose the exact dropdown row.
Cancel restores the currently loaded song label; reselecting that song preserves
unconfirmed edits and playback. The dropdown uses the native ComboBox delegate model
for keyboard highlighting and activation, with a visible draggable scrollbar.
The section manifest rejects duplicate/mismatched files.

The supplied Chorus book is format 5.00: open it with MuseScore 5. Hymns and Sunday School
are format 4.70. Preparation preserves each format and every tie. This plugin cannot make
MuseScore 4.7.5 read newer notation; forced conversion loses ties. Keep separate review
copies when using different major versions, since a MuseScore 5 save may upgrade the format.

## Start

1. Copy the complete **Psalmist Reviewer** folder from the USB to Documents. Give each reviewer their own copy.
2. Close MuseScore, then double-click **START HERE.cmd** and choose a book.
   It installs the plugin, starts the hidden local CSV helper and opens the selected book.
   The kit uses its included MuseScore 5 automatically. Reviewers need no Python, Node.js or administrator installation.
3. The bundled launcher enables the review extension and skips first-run welcome screens.
   For an advanced installed-version launch, enable **Psalmist Playback Review** through **Plugins → Manage plugins** in 4.7.5,
   or **Extensions → Manage extensions** in 5.
   If it is newly installed, restart MuseScore and run the launcher again.
4. In the opened book, choose **Plugins → Psalmist Playback Review**
   in 4.7.5 or **Extensions → Psalmist Playback Review** in 5.
5. Enter your name in the labelled **Reviewer name** section at the top. It is included with
   every saved decision and determines your CSV filename. The last saved name is remembered;
   check/change it when another reviewer uses the computer. Listen, adjust tempo/feel/holds,
   and press **Save score + CSV**.
   Wait for the success message before moving on.
6. Return the complete reviewer folder with your modified books and `Review-your-name.csv` in Books. Books in the same
   folder share one CSV for that reviewer. Each reviewer returns their own CSV.

The launcher can ask you to locate a portable/nightly MuseScore executable. Advanced users can run `App/LaunchReview.ps1` with `-Book Hymns -Version 5` and
`-MuseScorePath "C:\path\to\MuseScoreStudio5.exe"`. With a custom Plugins folder, also pass
`-PluginDir "C:\path\to\Plugins\PsalmistPlaybackReview"`. Close and restart that version
before testing an updated plugin; QML components are cached within a process.

Open this package's prepared named-playback books to review the new collection. Hidden playback
parts are preserved: visible notation edits do not automatically update their copied notes.
Reviews from older collections use different source identities and are not automatically transferred.
Older reviewed books and CSVs
are retained as records; do not overwrite them with the fresh, unreviewed package books.
To keep existing reviews, close the old books in MuseScore and drag their `.mscz` files onto
`App/UpgradeReviewBooks.cmd`. It creates `-v04.mscz` copies beside them, adds the inactive swing
templates and preserves notation, saved playback values and original files. Open those copies
with the new plugin; the existing reviewer CSVs stay beside them and continue to work.

The helper runs for eight hours; run the launcher again for a longer session.
The launcher preserves other extensions/preferences and keeps a before-psalmist backup
when updating existing configuration. Close MuseScore 5 before starting the bundled build.
Keep `MuseScore5` and `ThirdParty` intact when redistributing; the latter includes the matching
MuseScore/framework/dependency source archives and license/build references.

## Controls

- Every listening row has an **Instrument** button. The searchable picker uses the bundled
  **MS Basic** soundfont; **Grand Piano** is the default. Main changes all instrument/chord
  channels, Treble/Bass change their routed active channels, and each named part/Chords row
  changes only its own mixer channel. A shared two-clef part still has one instrument channel.
  Mixed groups show **Mixed instruments**. Scroll the mixer section to reach all rows.
  **Default — Grand Piano** in the preset list resets every actual instrument channel,
  including Chords, extra accompaniment and hidden rows, while retaining levels, mutes and solos.
  Choices carry across song navigation and are listening aids: they are excluded from CSV and
  review metadata. Save restores original instrument resources, waits for native acknowledgement,
  saves, then reapplies the listening choices. Closing restores the original sounds. **Reset
  listening mix** restores 100%/unmuted controls and the default piano. Use the panel's Save;
  MuseScore's own Save can persist temporary listening sounds. Instrument audition is limited to
  prepared MS Basic channels; third-party synth/plugin presets are preserved and not replaced.
  Pending changes show **Switching listening instrument…** until the native resource confirms.
  A read-only resource query recovers missed notifications, including restoration before Save;
  it does not resend sound changes or restart playback.

- Main, Treble clef and Bass clef each have a live volume slider and Mute checkbox. Individual instrument/voice channels also have Solo; multiple solos can be combined, and Mute still silences a soloed channel. Native Solo states are restored before saving and closing.
  Expand **Additional settings → Listening volume & instruments** at the bottom. Its visible right-hand scrollbar reaches every primary/secondary instrument channel supplied by
  MuseScore's mixer, using its names: Soprano, Alto, Tenor, Bass, Chords and other parts when present.
  A channel can be silent in a particular song; it is still available as in the combined book's mixer.
  These are listening controls relative to the opening mixer levels; 100% keeps the original level.
  They carry across navigation, restore the opening mix when the panel closes, and are excluded
  from saved review decisions and the panel's Save score + CSV. Missing clef channels are disabled.
  Clef and individual channel levels combine. A shared two-clef part uses its individual channel
  and Main, since independent clef volumes cannot be applied to one audio channel.
  The resizable window opens narrow (560 logical pixels) by default. Tempo & feel, Fermata holds, Score review, Google Sheets sync and Listening volume & instruments expand/collapse by clicking their arrow headers. Tempo and Score review open initially; the other sections start collapsed. Expanded sections reflow on resize and have a contrasting scrollbar when long. The whole form scrolls separately, while Status and Save remain visible. Drag an edge to resize, or use Maximize.
  **Reset listening mix** returns sliders to 100%, clears the plugin Mute/Solo checkboxes and selects Grand Piano; opening native Solo settings are restored when plugin solos clear.
  Use the panel's Save button during review; MuseScore's own Save can persist its current mixer levels.

- The confirmed count uses this reviewer's CSV for the current book. **Next unreviewed** skips
  confirmed songs, wraps around at the end, and retains the Save/Discard/Cancel prompt for changes.

- Previous/Next and the song menu navigate the collection. You can type a song ID in the
  menu and click **Go**, for example `H405`, `C838`, `SS075` or `H010-T1`.
  Unconfirmed navigation offers Save, Discard or Cancel.
  Open the song dropdown and scroll with the mouse wheel, drag its scrollbar, or use the keyboard.
- Play/Pause/Resume, Stop and Restart control the selected song. **−1 bar | Play/Pause/Resume | +1 bar** appear together. The bar buttons move within song boundaries while preserving playing/paused state. Previous song / Next song are on a separate row. The position display shows the current song bar and beat.
- **Loop song** repeatedly plays the selected hymn/chorus, rather than the entire combined book. Turn it off to finish the current pass; Stop cancels playback immediately. It is a listening preference and is not saved to the CSV. There can be a small restart gap.
- **Metronome** follows MuseScore's native metronome; its opening state is restored when the review panel closes.
- The tempo slider changes playback at the current musical position. MuseScore must briefly
  pause and rebuild playback; the plugin waits for its seek to complete before resuming.
  The slider debounce is 25 ms and timing checks run every 10 ms. Large combined books take longer to rebuild than a single song. Rapid slider changes settle
  on the latest value. Changing tempo while paused keeps it paused.
- Tempo uses the existing beat unit. Adjusting it writes native tempo markings and the printed
  metadata header immediately, only within the selected setting. Save confirms those changes. Existing later
  tempo changes retain their proportions: a 120→100 passage becomes 60→50 when the main
  tempo is set to 60. The CSV records every native tempo marking in `tempos_json`.
- Straight disables swing. Swing ratio is adjustable from 0 to 100%, initially **67%**.
  This is MuseScore's native timing ratio: 50% means even eighths; approximately 67% gives
  triplet swing; 100% delays the offbeat to the next beat. Values below 50% give reverse swing.
  Feel and its printed header change immediately. The ratio is retained when Straight is selected.
  Queued ratio edits are grouped over 40 ms to avoid rebuilding for intermediate values.
  Changing the ratio in Straight records the chosen value without rebuilding playback.
  Save and Play apply the latest ratio before continuing. Feel changes add no plugin pause or
  seek, but MuseScore rebuilds events for the combined book and may briefly interrupt audio.
- Answer **Are there any notes that should be grace notes in this score?** and **Are there any issues with
  this score?** with Yes/No, and enter free-text notes. Both answers default to No. These are
  review observations; they do not insert/remove notes or change grace-note playback. They are
  saved per setting in both CSV and score metadata and reload when returning to that setting.
  Include additional tempo or feel changes within the score in the issue notes. The existing
  `grace_notes_missing` storage field is retained for compatibility; the form uses the new wording.
- Fermatas at the same musical tick are grouped across staves. Different ticks are independent.
  Click a hold to locate it in the score. 100% means written duration; 200% doubles it.
- Printed metadata headers update with tempo and feel. Save verifies the persisted native
  tempo, feel and fermata values before updating CSV. Replacing a CSV keeps a `.bak` copy.
  Other songs and extra CSV columns are preserved.

## Scope and limits

Only prepared review books work. Original collection files are preserved. Do not insert/delete
measures while reviewing: song boundaries use measure ranges.

There is one base tempo and feel per setting. Existing tempo changes are preserved proportionally;
creating independent new refrain tempo/feel overrides is not implemented. These three source
collections have no additional native Straight/Swing changes inside a setting.

The plugin uses MuseScore's internal playback model. A future MuseScore release may need an update.
The local Windows helper verifies saved native controls before writing the reviewer CSV.
Each version has its own plugin folder and watcher; reviewers use the same controls.
Use the launcher for that version. Both use a separate resizable review window so the extension dialog host does not block native playback and saving.

The audition stop checks bar position every 50 ms and may briefly enter the next song.
Listen through final MP3s before distribution.

Closing the panel with unconfirmed changes offers Save, Discard or Cancel. Closing during a save
is blocked until verification finishes. Close the panel before switching to another open book;
if the active book changes, the panel disables its old score controls. Save writes the whole active
review copy, including any other MuseScore edits. If score saving succeeds but CSV saving fails,
the score stays saved, CSV stays unchanged, and the panel reports the error. Correct it and retry.
An interrupted helper releases its Windows file lock automatically; the next save can retry.
Empty `.csv.lock` files are normal and can remain beside the CSV. Damaged reviewer-name preferences
fall back to an empty name so the review window can still open.

## Developer checks

From the project root:

```
node plugins/psalmist-review/test-review.cjs
node plugins/psalmist-review/test-controls.cjs
node plugins/psalmist-review/test-instruments.cjs
node plugins/psalmist-review/test-instrument-stress.cjs
node plugins/psalmist-review/test-stress.cjs
.venv/Scripts/python.exe plugins/psalmist-review/test-save.py
.venv/Scripts/python.exe plugins/psalmist-review/test-fullbooks.py
.venv/Scripts/python.exe plugins/psalmist-review/test-tempo.py
.venv/Scripts/python.exe plugins/psalmist-review/test-gui-saves.py
.venv/Scripts/python.exe plugins/psalmist-review/test-volume-save.py
.venv/Scripts/python.exe plugins/psalmist-review/test-upgrade.py
```

The checks cover CSV round trips/replacement, identity conflicts, extra columns, native tempo/feel/
fermata verification, Windows PowerShell array handling, Qt newline normalization, and preservation
of CSV on verification failure. Full-book checks cover the first/last setting in all three books and
all five hymns with additional tempos (H088, H267, H405, H469, H740).

Preparation uses `scripts/prepare_playback_review.py --collections <source-folder> --only Hymns Sunday-School-Choruses --output <new-folder>`.
For this collection, use its `Books` subfolder as the source; omit `--only` to prepare all three books.
It verifies notation equality before/after adding review metadata and inactive feel templates,
checks archive integrity, and refuses to overwrite review copies.

Optional developer diagnostics: place `enable-checks.txt` in the installed plugin folder to record
`tempo-checks.json`, `feel-checks.json` and `playback-checks.json`. Feel diagnostics measure
native edit/commit time, not the audible gap. Omit this flag for reviewers. GUI test results are
recorded in the accompanying `TESTING.md`; a complete musical review of every song is not implied.
`mixer-checks.json` records opening and current channel levels when the same diagnostic flag is set.


Mixer-name repair (0.9.2): the shipped books include native instrument long names,
with printed labels hidden through score style instead of deleting those names.
MuseScore 5 derives mixer labels from long names, so older 4.x books could open
with blank mixer strips despite retaining trackName. For an already reviewed
book, close it and drag the .mscz onto App/RepairMixerNames.cmd. It creates a
-named.mscz copy beside the original, preserving review metadata and CSVs. Open
that copy through the usual helper/launcher workflow; keep its CSV beside it.
Mixed visible/blank printed labels are refused for manual review. Never replace
your reviewed books with fresh books from the kit.


Listening layout (0.9.3): default order is Main, available Chords channels,
Soprano, Alto, Tenor, Bass, remaining instrument channels, then aggregate
Treble/Bass controls. Missing voices are omitted; repeated part names remain
separate channels. Manage tracks opens Show checkboxes and Up/Down buttons.
Restore default order & show all resets the layout without changing the sound.
Hiding affects controls only: hidden mute/solo/volume settings remain active,
and hidden channels still receive instrument updates. The listening summary
shows the active solo count; Manage tracks labels active Solo/Muted rows.
Layout preferences are stored per source book in listening-layouts.json in
the local plugin folder. They persist across sessions in that MuseScore
profile, and are excluded from the USB distribution, scores and CSVs.
Audio listening choices are temporary; they are not restored as saved review
decisions on the next session.

Native stress refinements (0.9.3): Solo/Mute restoration is completed before
volume restoration, then Save waits for stable original mixer values and
instrument acknowledgements. This avoids Solo callbacks restoring stale
listening levels. Tempo-seek acknowledgement uses a 20ms time tolerance,
instead of a fixed normalized-position tolerance that was too tight on short
scores in 5. Both fixes have native and model regression checks.

Shared Google Sheets reviews (0.10.0) use ONE answer per source book/song.
The last reviewer's name and a server revision are retained. Shared progress,
Next unreviewed, tempo/feel/swing, all fermatas, questions and issue notes apply
across reviewers. Downloaded answers are applied to the local score and its
metadata in a preflighted native transaction, followed by a verified save with
original mixer levels/Solo/instruments. Additional tempo markings are retained.
Notation and listening controls are excluded from cloud review data.

The organiser follows GOOGLE SHEETS SETUP.txt, deploys the Apps Script once,
then runs CONFIGURE SHARED SYNC.cmd in the extracted kit. This creates only
App/shared-sync.json (URL/key, no personal identity). Copy that configured WHOLE
folder to each reviewer. START HERE imports the connection automatically and
creates an independent local identity; reviewers need no Google account,
URL, key entry or separate sync setup. When updating the kit, copy the same
App/shared-sync.json into the new kit. Never copy reviewed Books over fresh
or another reviewer's files, and keep local books/CSVs as backups.

Sync runs after a successful local Save, after entering a reviewer name, and
every 60 seconds while idle. It waits for unsaved edits and playback to stop;
Sync now is also available. Network requests leave review and playback controls usable.
Downloaded answers wait for local edits to be saved and playback to stop.
Cancel sync is always visible above Save while syncing; closing the panel also
cancels the request. Cancel pauses automatic retries until Sync now is clicked.
An upload already accepted by Google cannot be undone by cancellation; its
stable edit identity makes the next retry safe. Local score saves still briefly
lock controls during verified disk writes. Sync uses a frozen saved CSV snapshot,
independent of later edits. A newer local Save cancels the older network
request, clears deferred downloads and rechecks the newer answer after saving,
so an older download cannot replace a newly saved local answer.
START HERE runs separate save/sync workers and a helper heartbeat. Missing or
expired helpers are reported immediately instead of waiting for a network timeout.
Offline work is saved normally and joins the shared set after reconnecting.
Previously applied shared answers and progress remain in the local score for
offline use. Local reviewer CSVs are retained as the saved edit backup/outbox;
other reviewers' CSVs are not required or rewritten.

Each saved edit carries its base shared revision. The server serialises writers
and accepts that revision only if it still matches. Retries use a stable edit
identity, avoiding duplicate uploads after a lost response. Stale/offline edits
become conflicts even if their computer clock is in the future. Resolve edits
shows both full answers: Use shared answer discards the pending upload while
retaining its local CSV backup, applies the shared settings and saves the score;
Keep my answer deliberately submits against the displayed revision. A further
concurrent edit causes another conflict, never an automatic overwrite.

The connection/identity (sheets-sync.json), shared-v2-<book-hash>.json cache and
acknowledged outbox state live in the installed plugin folder. Only the kit's
organiser-created shared-sync.json is distributed. Its holders can read and
submit the group's names, answers and notes, so distribute the kit privately.
A Google Apps Script deployment and private Sheet need no paid hosting or
billing account; Google quotas/policies still apply. Do not edit SharedReviews
headings, revisions or rows directly. Deleting/resetting rows breaks revision
continuity; restore the Sheet or coordinate new fresh books instead.

The new service uses protocol 2 and a separate SharedReviews tab. Updating a
0.9.4 deployment preserves its former Reviews tab but does not automatically
pick a winner among its comparison rows. Old local CSVs can seed the shared set;
conflicting alternatives must be resolved explicitly. Keep the first shared
copy that has been agreed and let subsequent reviewers pull it.

Limits: 2,000 answers / 4 MB per upload; 20,000 shared songs total. Failed network
calls preserve local files and the previous good cache. Native batch imports
validate song/tempo/fermata maps before editing, reject unsupported/mismatched
answers, request rollback on native edit exceptions, and keep a failed score
save pending for retry. Close waits for its save verification. No Google
account/deployment credentials are included. Real Google uploads and round-trip
sync passed between two isolated reviewer profiles on one Windows PC, including
concurrent writers, conflict choices, lost accepted responses, cancellation,
worker crashes, offline/restart recovery and literal Unicode notes. Two separate
physical computers were not tested. Native panels in MuseScore 4.7.5 and the bundled 5 nightly also passed a real
Google round trip: 4 uploaded, 5 downloaded and revised it, and 4 downloaded
the revision. Both saved scores retained identical answers, Unicode notes,
metadata, tempo/feel and fermatas, with music and original audio preserved.
Resetting the Windows control session resolved the earlier helper failure.
Local connection testing: fill `plugins/psalmist-review/.env` with
`PSALMIST_SYNC_URL` (Apps Script /exec deployment URL) and `PSALMIST_SYNC_KEY`
(the organiser key from setupSharedReviews). No Google password, OAuth token or
spreadsheet credentials are needed. Run `powershell.exe -NoProfile
-ExecutionPolicy Bypass -File plugins/psalmist-review/test-sync-live.ps1`. This
fetches each book using an empty outbox and never uploads test reviews. The .env
is ignored and excluded from USB builds. It does not configure a distributed
kit; copy the existing organiser App/shared-sync.json or use CONFIGURE SHARED SYNC.

Write-enabled live integration tests: `test-sync-live-profiles.ps1` uses the
local .env and TWO isolated temporary profiles against the actual Google
deployment. Run it only when real test writes are intended. Each run uses a
new test-book fingerprint and clearly marked QA TEST ONLY answers, leaving real
book results untouched. Test rows remain in SharedReviews under those isolated
fingerprints. It also kills only owned test workers and tests retry after a
response is lost AFTER Google acceptance. No test credentials, reviewer data
or private fixtures are included in the USB kit. The Windows process fault
test can additionally run `test-sync-watcher.ps1 -Cycles 24`.


MP3 exports and presets (0.10.0)
-------------------------------
Expand Additional settings > MP3 export. Part exports the selected song once;
Full repeats the selected song once per verse listed in its header. If the
header has no count, a dialog asks for 1–32 verses; Cancel starts no export.
The entered count applies to this export only and does not change shared reviews.
Set Break between verses (Full) to 0–16 whole bars; default 1 bar.
Break bars use the song's opening time signature and reviewed opening tempo,
including dotted-quarter or half-note beat units. A pickup still gets a full
bar of break. For songs with tempo or meter changes, the break returns to the
opening timing ready for the next verse. For example, one bar of 4/4 at 120
quarter-note BPM lasts 2 seconds; one bar of 3/4 at the same tempo lasts 1.5.
This adds a break between passes only, after the final measure and its holds.
Existing written rests and instrument decay also affect the audible space.
Part always plays once and ignores the break. Each pass includes the song's
written chorus/refrain section.
Notation repeats, voltas and D.C./D.S. jumps are disabled for these linear
exports, matching the review panel's once-through playback. Full repeats the
whole mapped song; it does not interpret verse-specific alternative passages.
The current panel tempo, feel, swing, holds, instruments, combined volume,
mute and solo are captured at export time, including unconfirmed settings.
This does not save or confirm a review or change shared answers. The existing
saved book supplies the notes; use fresh prepared books and avoid ordinary
notation edits while the panel is open. The exporter validates playback maps
and leaves the source book unchanged. Only prepared MS Basic sounds are used.
Files have unique names in Books/Exports. Rendering happens in a separate
hidden MuseScore process, so review controls remain available. Cancel MP3
export or closing the panel cancels its owned renderer; completed files remain.
Exports contain music, not reviewer names, notes, connection settings or sync
metadata. No extra audio converter or download is needed by reviewers.

The Listening volume & instruments section includes Grand Orchestra, Warm
Strings, Bright & Joyful, Majestic Brass and Gentle & Reflective. Apply preset
sets the named Soprano/Alto/Tenor/Bass/Chords channels that exist; other channels
and all levels, mutes and solos remain as you set them. Presets use the shipped
MS Basic sound list and do not add instruments or change notation.

Click BPM to select its value, or drag to select a portion, then type a new
value. The editable song selector similarly accepts replacing its text with a
song ID, full title or a unique part of a title, then Enter/Go. Ambiguous title
searches require more text. This finds songs; it does not rename their titles.
Existing sync protocol, book fingerprints, song IDs, connection/device identity,
revision cache and saved review outboxes are retained through plugin updates.


Playback-start recovery (0.10.6): Play selects the opening native tempo element
and uses MuseScore's play-from-selection command, which targets its exact score
tick. It no longer waits for an exact rounded bar/beat report. Loading waits for
the current listening instruments, and the panel confirms actual playback before
showing Playing. A missed start/resume gets one bounded retry; failures release
the controls so Play can retry in the same panel. Stop cancels queued work and
also stops a late native prepare-to-play completion. While stopped, the panel
owns that transport until its Play/Resume is used; use the panel controls.
Tempo resume uses the same acknowledgement. A missing duration notification can
be recovered from the rebuilt timeline; if timing cannot be retained within eight
seconds, playback recovers from the song start with a visible message. Paused
playback stays stopped in that fallback. Reviews, CSV/sync identities and export
settings are unchanged.
