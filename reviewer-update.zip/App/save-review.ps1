param([Parameter(Mandatory=$true)][string]$RequestPath)
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.IO.Compression.FileSystem
Add-Type -AssemblyName System.IO.Compression
$utf8 = New-Object System.Text.UTF8Encoding($false)
$resultPath = $RequestPath + '.result.json'
$lock = $null
$lockPath = $null
$temporary = $null
try {
    $request = [IO.File]::ReadAllText($RequestPath, $utf8) | ConvertFrom-Json
    $scorePath = [IO.Path]::GetFullPath([string]$request.score_path)
    if ([IO.Path]::GetExtension($scorePath) -ne '.mscz') { throw 'Save a local .mscz review copy first.' }
    for ($attempt = 0; $attempt -lt 240; $attempt++) {
        try {
            # MuseScore replaces the file during save; verification must not block that rename.
            $stream = [IO.File]::Open($scorePath, [IO.FileMode]::Open, [IO.FileAccess]::Read,
                ([IO.FileShare]::ReadWrite -bor [IO.FileShare]::Delete))
            try { $zip = New-Object IO.Compression.ZipArchive($stream, [IO.Compression.ZipArchiveMode]::Read) }
            catch { $stream.Dispose(); throw }
            try {
                $entries = @($zip.Entries | Where-Object { $_.FullName.EndsWith('.mscx') })
                if ($entries.Count -ne 1) { throw 'Expected one score XML entry.' }
                $reader = New-Object IO.StreamReader($entries[0].Open(), $utf8)
                try { $xmlText = $reader.ReadToEnd() } finally { $reader.Dispose() }
            } finally { $zip.Dispose() }
            if ($xmlText.Contains('>' + [string]$request.token + '</metaTag>')) { break }
        } catch { if ($attempt -eq 239) { throw } }
        Start-Sleep -Milliseconds 500
    }
    $settings = New-Object Xml.XmlReaderSettings
    $settings.DtdProcessing = [Xml.DtdProcessing]::Prohibit
    $settings.XmlResolver = $null
    $reader = [Xml.XmlReader]::Create((New-Object IO.StringReader($xmlText)), $settings)
    $xml = New-Object Xml.XmlDocument
    $xml.XmlResolver = $null
    try { $xml.Load($reader) } finally { $reader.Dispose() }
    $book = $xml.SelectSingleNode('/museScore/Score')
    $map = $book.SelectSingleNode("metaTag[@name='psalmist-playback-review']").InnerText | ConvertFrom-Json
    $verifyDecisions=@(if ($request.mode -eq 'shared') { $request.decisions } else { $request.decision })
    if ($verifyDecisions.Count -lt 1 -or $verifyDecisions.Count -gt 2000) { throw 'No valid review decisions to verify.' }
    # A shared pull may contain the whole book: parse maps and index staves once.
    $staves=@($book.SelectNodes('Staff'));$staffMeasureIndex=@{};$songIndex=@{}
    for ($si=0;$si -lt $staves.Count;$si++) { $staffMeasureIndex[$si]=@($staves[$si].SelectNodes('Measure')) }
    foreach ($entry in $map.songs) {
        if ($songIndex.ContainsKey([string]$entry.id)) { throw 'Duplicate song ID in review map.' }
        $songIndex[[string]$entry.id]=$entry
    }
    $answersTag=$book.SelectSingleNode("metaTag[@name='psalmist-review-decisions']")
    $answerMap=if ($null -ne $answersTag) { $answersTag.InnerText | ConvertFrom-Json } else { $null }
    $revisions=if ($request.mode -eq 'shared') { $book.SelectSingleNode("metaTag[@name='psalmist-shared-revisions']").InnerText|ConvertFrom-Json } else { $null }
    foreach ($decision in $verifyDecisions) {
    if ($map.source_sha256 -ne $decision.book_source_sha256) { throw 'Saved score belongs to a different review book.' }
    if ($request.mode -eq 'shared') {
        if ([int]$revisions.($decision.id) -ne [int]$decision.revision -or [int]$decision.revision -lt 1) { throw 'Saved shared revision differs.' }
    }
    $token = $book.SelectSingleNode("metaTag[@name='psalmist-playback-save-token']")
    if ($null -eq $token -or $token.InnerText -ne $request.token) { throw 'MuseScore has not saved this decision yet. Retry Save.' }
    if (-not $songIndex.ContainsKey([string]$decision.id)) { throw 'Unknown song ID.' }
    $song = @($songIndex[[string]$decision.id])
    $measures = $staffMeasureIndex[0]
    $measure = $measures[[int]$song[0].start - 1]
    $tempo = $measure.SelectSingleNode('.//Tempo/tempo')
    $quarterBpm = [double]$decision.quarter_bpm
    if ([double]::IsNaN($quarterBpm) -or [double]::IsInfinity($quarterBpm) -or $quarterBpm -lt 20 -or $quarterBpm -gt 600) { throw 'Invalid quarter-note tempo.' }
    if ($null -eq $tempo -or [Math]::Abs(([double]::Parse($tempo.InnerText, [Globalization.CultureInfo]::InvariantCulture) * 60) - $quarterBpm) -gt 0.01) { throw 'Saved native tempo does not match the decision.' }
    $feel = $measure.SelectSingleNode(".//SystemText[text='Straight' or text='Swing']/swing")
    $unit = if ($decision.feel -eq 'swing') { 'eighth' } else { '' }
    $actualUnit = if ($null -ne $feel) { $feel.GetAttribute('unit') } else { '?' }
    if ($unit -eq '' -and $actualUnit -eq 'zero') { $actualUnit = '' }
    $ratio = [double]$decision.swing_ratio
    if ([double]::IsNaN($ratio) -or [double]::IsInfinity($ratio) -or $ratio -lt 0 -or $ratio -gt 100 -or $ratio -ne [Math]::Floor($ratio)) { throw 'Swing ratio must be an integer from 0 to 100.' }
    if ($null -eq $feel -or $actualUnit -ne $unit -or ($unit -ne '' -and [int]$feel.GetAttribute('ratio') -ne [int]$decision.swing_ratio)) { throw 'Saved native feel does not match the decision.' }
    if ($null -ne $decision.grace_notes_missing) {
        foreach ($field in 'grace_notes_missing','score_has_issues') {
            if ($decision.$field -notin 'yes','no') { throw "Answer Yes or No for $field." }
        }
        if ($null -eq $answersTag) { throw 'Saved review answers are missing.' }
        $answers = $answerMap.($decision.id)
        foreach ($field in 'grace_notes_missing','score_has_issues','issue_notes','swing_ratio') {
            if ([string]$answers.$field -cne [string]$decision.$field) { throw "Saved review answer differs: $field." }
        }
    }
    # Verify the persisted native fermata values on every staff and bar.
    $fermatas = ConvertFrom-Json -InputObject $decision.fermatas_json
    $tempos = if ($decision.tempos_json) { ConvertFrom-Json -InputObject $decision.tempos_json } else { $null }
    for ($si = 0; $si -lt $staves.Count; $si++) {
        $staffMeasures = $staffMeasureIndex[$si]
        for ($mi = [int]$song[0].start - 1; $mi -lt [int]$song[0].end; $mi++) {
            $bar = $mi - [int]$song[0].start + 2
            if ($null -ne $tempos) {
                $expectedTempos = @($tempos | Where-Object { $_.bar -eq $bar -and [Math]::Floor([int]$_.track / 4) -eq $si } | ForEach-Object { [Math]::Round([double]$_.quarter_bpm, 3) } | Sort-Object)
                $actualTempos = @($staffMeasures[$mi].SelectNodes('.//Tempo/tempo') | ForEach-Object { [Math]::Round([double]::Parse($_.InnerText, [Globalization.CultureInfo]::InvariantCulture)*60, 3) } | Sort-Object)
                if (($actualTempos -join ',') -ne ($expectedTempos -join ',')) { throw "Saved tempo markings differ at staff $($si+1), song bar $bar." }
            }
            $expected = @($fermatas | Where-Object { $_.bar -eq $bar } | ForEach-Object {
                $f = $_
                @($f.tracks | Where-Object { [Math]::Floor([int]$_ / 4) -eq $si } | ForEach-Object { [double]$f.percent })
            } | Sort-Object)
            $actual = @($staffMeasures[$mi].SelectNodes('.//Fermata') | ForEach-Object {
                $value = $_.SelectSingleNode('timeStretch')
                if ($null -eq $value) {
                    $subtype = $_.SelectSingleNode('subtype').InnerText
                    if ($subtype -match 'VeryShort') { 125 }
                    elseif ($subtype -match 'VeryLong') { 400 }
                    elseif ($subtype -match 'Short') { 150 }
                    elseif ($subtype -match 'Long') { 300 }
                    else { 200 }
                } else { [Math]::Round([double]::Parse($value.InnerText, [Globalization.CultureInfo]::InvariantCulture) * 100, 6) }
            } | Sort-Object)
            if (($actual -join ',') -ne ($expected -join ',')) { throw "Saved fermatas differ at staff $($si+1), song bar $bar." }
        }
    }
    }
    $csvPath=$null
    if ($request.mode -ne 'shared') {
    $name = [string]$request.csv_name
    if ($name -notmatch '^Review-[a-zA-Z0-9_-]+\.csv$') { throw 'Invalid reviewer CSV name.' }
    $csvPath = Join-Path ([IO.Path]::GetDirectoryName($scorePath)) $name
    $lockPath = $csvPath + '.lock'
    # OS-held lock survives contention but releases automatically after a crash.
    $lock = [IO.File]::Open($lockPath, [IO.FileMode]::OpenOrCreate, [IO.FileAccess]::ReadWrite, [IO.FileShare]::None)
    $existing = if ([IO.File]::Exists($csvPath)) { [IO.File]::ReadAllText($csvPath, $utf8) } else { '' }
    # FileIO reads text with Qt newline normalization on Windows.
    if ($existing.Replace("`r`n", "`n").TrimEnd("`n") -cne ([string]$request.csv_before).Replace("`r`n", "`n").TrimEnd("`n")) { throw 'The CSV changed since it was loaded. Reopen the panel before saving.' }
    $temporary = $csvPath + '.' + [Guid]::NewGuid().ToString('N') + '.tmp'
    [IO.File]::WriteAllText($temporary, [string]$request.csv_after, $utf8)
    if ([IO.File]::Exists($csvPath)) { [IO.File]::Replace($temporary, $csvPath, $csvPath + '.bak') }
    else { [IO.File]::Move($temporary, $csvPath) }
    if ([IO.File]::ReadAllText($csvPath, $utf8) -cne [string]$request.csv_after) { throw 'CSV verification failed.' }
    }
    $result = @{ ok=$true; token=$request.token; csv_path=$csvPath; score_path=$scorePath }
} catch {
    $result = @{ ok=$false; error=$_.Exception.Message }
} finally {
    if ($null -ne $lock) { $lock.Dispose() }
    if ($null -ne $temporary -and [IO.File]::Exists($temporary)) { [IO.File]::Delete($temporary) }
}
$resultTemp = $resultPath + '.tmp'
[IO.File]::WriteAllText($resultTemp, ($result | ConvertTo-Json -Compress), $utf8)
if ([IO.File]::Exists($resultPath)) { [IO.File]::Replace($resultTemp, $resultPath, $resultPath+'.bak'); [IO.File]::Delete($resultPath+'.bak') }
else { [IO.File]::Move($resultTemp, $resultPath) }
if (-not $result.ok) { exit 1 }
