param([switch]$Watch, [ValidateSet('4','5')][string]$Version = '4',
      [string]$MuseScorePath, [string]$PluginDir, [string]$ScorePath, [switch]$Bundled, [switch]$InstallOnly)
$ErrorActionPreference = 'Stop'
if (-not $Watch) {
    if ($Bundled -and (Get-Process MuseScoreStudio5 -ErrorAction SilentlyContinue)) { throw 'Close MuseScore 5, then run START HERE again.' }
    if ($ScorePath -and (-not (Test-Path -LiteralPath $ScorePath -PathType Leaf) -or [IO.Path]::GetExtension($ScorePath) -ne '.mscz')) { throw 'The selected review book is missing or is not a .mscz file.' }
    if (-not $MuseScorePath) {
        $exeNames = if ($Version -eq '5') { 'MuseScoreStudio5.exe','MuseScore5.exe' } else { 'MuseScore4.exe' }
        $MuseScorePath = @(Get-ChildItem -Path (Join-Path $env:ProgramFiles 'MuseScore*/bin/*.exe') -ErrorAction SilentlyContinue |
            Where-Object { $_.Name -in $exeNames } | Select-Object -ExpandProperty FullName -First 1)[0]
    }
    if (-not $MuseScorePath -or -not (Test-Path -LiteralPath $MuseScorePath -PathType Leaf)) { throw "MuseScore $Version was not found. Pass -MuseScorePath with its executable path." }
    if (-not $PluginDir) {
        $appName = if ($Version -eq '5') { 'MuseScoreStudio5' } else { 'MuseScore4' }
        if ($Version -eq '5' -and ($Bundled -or $MuseScorePath -match 'Nightly')) { $appName += 'Development' }
        $PluginDir = Join-Path ([Environment]::GetFolderPath('MyDocuments')) "$appName/Plugins/PsalmistPlaybackReview"
    }
    New-Item -ItemType Directory -Force -Path $pluginDir | Out-Null
    $installedWatcher=Join-Path $PluginDir 'StartReview.ps1'
    if ((Test-Path -LiteralPath $installedWatcher) -and (Get-FileHash -LiteralPath $installedWatcher).Hash -ne (Get-FileHash -LiteralPath $PSCommandPath).Hash) {
        # An older watcher otherwise keeps its original code and blocks the replacement lock.
        $watcherArgument='-File "'+[IO.Path]::GetFullPath($installedWatcher)+'" -Watch -PluginDir "'+[IO.Path]::GetFullPath($PluginDir)+'"'
        Get-CimInstance Win32_Process -Filter "Name='powershell.exe'" | Where-Object { $_.ProcessId -ne $PID -and $_.CommandLine -and $_.CommandLine.Contains($watcherArgument) } | ForEach-Object { Stop-Process -Id $_.ProcessId -ErrorAction SilentlyContinue }
    }
    foreach ($name in 'PsalmistPlaybackReview.qml','ReviewButton.qml','ReviewSlider.qml','ReviewSection.qml','review.js','save-review.ps1','sync-reviews.ps1','export-audio.ps1','ExportScore.cs','switch-book.ps1','StartReview.ps1') {
        $source = Join-Path $PSScriptRoot $name
        $target = Join-Path $pluginDir $name
        if ([IO.Path]::GetFullPath($source) -ne [IO.Path]::GetFullPath($target)) { Copy-Item -LiteralPath $source -Destination $target -Force }
        if ($Version -eq '5' -and $name -eq 'PsalmistPlaybackReview.qml') {
            $qml = [IO.File]::ReadAllText($target).Replace('pluginType: "dialog"', 'pluginType: ""')
            [IO.File]::WriteAllText($target, $qml)
        }
    }
    [IO.File]::WriteAllText((Join-Path $PluginDir 'runtime.json'),(@{musescore_path=[IO.Path]::GetFullPath($MuseScorePath)}|ConvertTo-Json -Compress),(New-Object Text.UTF8Encoding($false)))
    $sharedConfig=Join-Path $PSScriptRoot 'shared-sync.json'
    if (Test-Path -LiteralPath $sharedConfig) {
        $connection=[IO.File]::ReadAllText($sharedConfig) | ConvertFrom-Json
        if ([string]$connection.url -cnotmatch '^https://script\.google\.com/macros/s/[A-Za-z0-9_-]+/exec$' -or [string]$connection.key -cnotmatch '^[A-Za-z0-9-]{32,200}$') { throw 'The organiser sync connection is damaged. Ask for a fresh kit.' }
        $localConfig=Join-Path $PluginDir 'sheets-sync.json';$identity=''
        if (Test-Path -LiteralPath $localConfig) {
            $previous=[IO.File]::ReadAllText($localConfig)|ConvertFrom-Json
            $identity=[string]$previous.device_id
        }
        if (-not $identity) { $identity=[Guid]::NewGuid().ToString() }
        $temporary=$localConfig+'.tmp'
        [IO.File]::WriteAllText($temporary,(@{url=$connection.url;key=$connection.key;device_id=$identity}|ConvertTo-Json -Compress),(New-Object Text.UTF8Encoding($false)))
        if (Test-Path -LiteralPath $localConfig) { [IO.File]::Replace($temporary,$localConfig,$localConfig+'.bak') }
        else { [IO.File]::Move($temporary,$localConfig) }
    }
    if ($Bundled) { & (Join-Path $PSScriptRoot 'SetupBundledMuseScore.ps1') }
    if ($InstallOnly) { Write-Output "Installed in $PluginDir"; exit }
    $watcher = Join-Path $pluginDir 'StartReview.ps1'
    Start-Process powershell.exe -WindowStyle Hidden -ArgumentList @('-NoProfile','-ExecutionPolicy','Bypass','-File',('"'+$watcher+'"'),'-Watch','-PluginDir',('"'+$PluginDir+'"'))
    # MuseScore is interactive; only the CSV helper runs hidden.
    if ($ScorePath) { Start-Process $MuseScorePath -ArgumentList ('"'+[IO.Path]::GetFullPath($ScorePath)+'"') }
    else { Start-Process $MuseScorePath }
    exit
}
if (-not $PluginDir) { throw 'The watcher requires -PluginDir.' }
# ponytail: one private request folder; a lock prevents duplicate session watchers.
$lock = $null
try {
    try { $lock = [IO.File]::Open((Join-Path $pluginDir 'watcher.lock'), 'OpenOrCreate', 'ReadWrite', 'None') }
    catch [IO.IOException] { exit }
    $until = (Get-Date).AddHours(8)
    $sessionStarted = (Get-Date).AddSeconds(-10)
    $handled = @{}
    $tasks = @{}
    $utf8=New-Object Text.UTF8Encoding($false)
    $heartbeat=Join-Path $PluginDir 'watcher-heartbeat.json'
    if(Test-Path -LiteralPath (Join-Path $PluginDir 'watcher-error.txt')){Remove-Item -LiteralPath (Join-Path $PluginDir 'watcher-error.txt')}
    while ((Get-Date) -lt $until) {
        $beat=@{pid=$PID;updated=[DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds()} | ConvertTo-Json -Compress
        [IO.File]::WriteAllText($heartbeat+'.tmp',$beat,$utf8)
        if ([IO.File]::Exists($heartbeat)) { [IO.File]::Replace($heartbeat+'.tmp',$heartbeat,$heartbeat+'.bak');[IO.File]::Delete($heartbeat+'.bak') }
        else { [IO.File]::Move($heartbeat+'.tmp',$heartbeat) }
        foreach ($kind in 'sync','save','export','book') {
            if ($tasks.ContainsKey($kind)) {
                $task=$tasks[$kind]
                $cancelled=$kind -in 'sync','export','book' -and [IO.File]::Exists($task.path+'.cancel')
                if($kind -eq 'export' -and $cancelled -and -not $task.ContainsKey('cancelStarted')){$task.cancelStarted=Get-Date}
                $expired=((Get-Date)-$task.started).TotalSeconds -gt $(if($kind -eq 'sync'){70}elseif($kind -eq 'export'){960}else{160})
                if (($cancelled -and ($kind -ne 'export' -or ((Get-Date)-$task.cancelStarted).TotalSeconds -gt 2)) -or $expired) {
                    if (-not $task.process.HasExited) {
                        if($kind -eq 'export') { & taskkill.exe /PID $task.process.Id /T /F 2>&1 | Out-Null }
                        else {$task.process.Kill()}
                        $task.process.WaitForExit()
                    }
                }
                if ($task.process.HasExited) {
                    if ([IO.File]::Exists($task.path) -and -not [IO.File]::Exists($task.path+'.result.json')) {
                        $request=$null
                        try { $request=[IO.File]::ReadAllText($task.path) | ConvertFrom-Json }
                        catch [IO.FileNotFoundException] {} # The panel may consume it between the existence check and read.
                        if($null -ne $request) {
                            $errorText=if($cancelled){'Operation cancelled. Local reviews are safe.'}elseif($expired){'Review helper timed out. Retry the operation; local reviews are safe.'}else{'Review helper stopped unexpectedly. Restart through START HERE, then retry.'}
                            $result=@{ok=$false;token=$request.token;error=$errorText}|ConvertTo-Json -Compress
                            [IO.File]::WriteAllText($task.path+'.result.json.tmp',$result,$utf8)
                            [IO.File]::Move($task.path+'.result.json.tmp',$task.path+'.result.json')
                        }
                    }
                    $task.process.Dispose();$tasks.Remove($kind)
                }
            }
            if ($tasks.ContainsKey($kind)) { continue }
            foreach ($file in Get-ChildItem -LiteralPath $pluginDir -Filter ($kind+'-*.json') | Sort-Object LastWriteTime) {
                if ($file.Name -like '*.result.json' -or $handled.ContainsKey($file.FullName) -or [IO.File]::Exists($file.FullName+'.result.json') -or [IO.File]::Exists($file.FullName+'.cancel') -or $file.LastWriteTime -lt $sessionStarted) { continue }
                # Native Save is asynchronous; sync requests only need to finish writing.
                if (((Get-Date)-$file.LastWriteTime).TotalMilliseconds -lt $(if($kind -eq 'save'){2000}else{500})) { continue }
                $helper=Join-Path $pluginDir ($kind+'-reviews.ps1')
                if ($kind -eq 'save') { $helper=Join-Path $pluginDir 'save-review.ps1' }
                if ($kind -eq 'export') { $helper=Join-Path $pluginDir 'export-audio.ps1' }
                if ($kind -eq 'book') { $helper=Join-Path $pluginDir 'switch-book.ps1' }
                $child=Start-Process powershell.exe -WindowStyle Hidden -PassThru -ArgumentList @('-NoProfile','-ExecutionPolicy','Bypass','-File',('"'+$helper+'"'),'-RequestPath',('"'+$file.FullName+'"'))
                $tasks[$kind]=@{process=$child;path=$file.FullName;started=Get-Date}
                $handled[$file.FullName]=$true
                break
            }
        }
        Start-Sleep -Milliseconds 500
    }
} catch {
    [IO.File]::WriteAllText((Join-Path $pluginDir 'watcher-error.txt'), $_.Exception.Message)
} finally {
    if ($tasks) { foreach($kind in @($tasks.Keys)) { $task=$tasks[$kind];if(-not $task.process.HasExited){if($kind -eq 'export'){& taskkill.exe /PID $task.process.Id /T /F 2>&1 | Out-Null}else{$task.process.Kill()}};$task.process.Dispose() } }
    if ($null -ne $lock) { $lock.Dispose() }
}
