param([Parameter(Mandatory=$true)][string]$RequestPath)
$ErrorActionPreference='Stop'
$utf8=New-Object Text.UTF8Encoding($false)
$resultPath=$RequestPath+'.result.json'
$temporary=$null
try {
    $request=[IO.File]::ReadAllText($RequestPath,$utf8) | ConvertFrom-Json
    if ([IO.File]::Exists($RequestPath+'.cancel')) { throw 'Sync cancelled. Local reviews are safe.' }
    $folder=[IO.Path]::GetDirectoryName([IO.Path]::GetFullPath($RequestPath))
    $configPath=Join-Path $folder 'sheets-sync.json'
    $config=[IO.File]::ReadAllText($configPath,$utf8) | ConvertFrom-Json
    if ([string]$config.url -cnotmatch '^https://script\.google\.com/macros/s/[A-Za-z0-9_-]+/exec$') { throw 'Enter the Google Apps Script deployment URL ending in /exec.' }
    if ([string]$config.key -notmatch '^[a-zA-Z0-9-]{32,200}$') { throw 'Enter the organiser''s sync key.' }
    if ([string]$request.book_source_sha256 -notmatch '^[a-f0-9]{64}$') { throw 'Invalid book fingerprint.' }
    if ([string]::IsNullOrWhiteSpace($request.reviewer) -or $request.reviewer.Length -gt 120) { throw 'Enter your reviewer name (up to 120 characters).' }
    if (-not $config.device_id) {
        $config | Add-Member NoteProperty device_id ([Guid]::NewGuid().ToString()) -Force
        [IO.File]::WriteAllText($configPath,($config | ConvertTo-Json -Compress),$utf8)
    }
    $cache=Join-Path $folder ('shared-v2-'+$request.book_source_sha256+'.json')
    $ack=@{}
    if ([IO.File]::Exists($cache)) {
        $previous=[IO.File]::ReadAllText($cache,$utf8) | ConvertFrom-Json
        if ($previous.version -ne 2 -or $previous.book_source_sha256 -cne $request.book_source_sha256) { throw 'Shared cache belongs to another protocol or book.' }
        if ($previous.acknowledged) { foreach ($property in $previous.acknowledged.PSObject.Properties) { $ack[$property.Name]=[string]$property.Value } }
    }
    $rows=@()
    if ($null -ne $request.csv_text) {
        if ($request.csv_text.Length -gt 4000000) { throw 'Oversized review CSV.' }
        if ($request.csv_text) { $rows=@($request.csv_text | ConvertFrom-Csv | Where-Object { $_.book_source_sha256 -ceq $request.book_source_sha256 -and $_.reviewer -ceq $request.reviewer -and $_.status -ceq 'confirmed' }) }
    } elseif ($request.csv_path -and [IO.File]::Exists($request.csv_path)) {
        if ([IO.Path]::GetExtension($request.csv_path) -ne '.csv' -or (Get-Item -LiteralPath $request.csv_path).Length -gt 4000000) { throw 'Invalid or oversized review CSV.' }
        $rows=@(Import-Csv -LiteralPath $request.csv_path -Encoding UTF8 | Where-Object { $_.book_source_sha256 -ceq $request.book_source_sha256 -and $_.reviewer -ceq $request.reviewer -and $_.status -ceq 'confirmed' })
    }
    if ($rows.Count -gt 2000) { throw 'Too many local answers for one sync.' }
    $upload=@();$slots=@{}
    foreach ($row in $rows) {
        $mutation=$config.device_id+'/'+$request.reviewer+'/'+$row.id+'/'+$row.reviewed_at
        $slot=$request.reviewer+'/'+$row.id
        if ($slots.ContainsKey($slot)) { throw 'Duplicate local song answers. Repair the CSV before syncing.' }
        $slots[$slot]=$mutation
        if ($ack[$slot] -ceq $mutation) { continue }
        $resolution=@($request.resolutions | Where-Object { $_.id -ceq $row.id -and $_.mutation_id -ceq $mutation })
        if ($resolution.Count -gt 1) { throw 'Duplicate conflict choice.' }
        if ($resolution.Count -eq 1 -and $resolution[0].choice -ceq 'shared') { $ack[$slot]=$mutation;continue }
        $base=if ($row.sync_base_revision) { [int]$row.sync_base_revision } else { 0 }
        if ($resolution.Count -eq 1) {
            if ($resolution[0].choice -cne 'mine' -or [int]$resolution[0].revision -lt 0) { throw 'Invalid conflict choice.' }
            $base=[int]$resolution[0].revision
        }
        $row | Add-Member NoteProperty base_revision $base -Force
        $row | Add-Member NoteProperty mutation_id $mutation -Force
        $upload+=,$row
    }
    $payload=@{version=2;key=$config.key;device_id=$config.device_id;book_source_sha256=$request.book_source_sha256;reviewer=$request.reviewer;rows=$upload} | ConvertTo-Json -Depth 15 -Compress
    [Net.ServicePointManager]::SecurityProtocol=[Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12
    # Google ContentService redirects the response to script.googleusercontent.com.
    $response=Invoke-RestMethod -Method Post -Uri $config.url -ContentType 'application/json; charset=utf-8' -Body $utf8.GetBytes($payload) -TimeoutSec 60 -MaximumRedirection 5
    if ([IO.File]::Exists($RequestPath+'.cancel')) { throw 'Sync cancelled. An upload already received by Google may still complete. Retry sync to check safely.' }
    if ($response.ok -ne $true) { throw $(if ($response.error) { [string]$response.error } else { 'Google did not return a sync result. Check the deployment access settings.' }) }
    if ($response.version -ne 2 -or $response.book_source_sha256 -cne $request.book_source_sha256 -or $null -eq $response.rows -or @($response.rows).Count -gt 20000 -or $null -eq $response.conflicts -or $null -eq $response.accepted) { throw 'Shared results did not match this book. Ask the organiser to update the Google Apps Script deployment.' }
    foreach ($row in @($response.rows)) {
        if ($row.book_source_sha256 -cne $request.book_source_sha256 -or $row.status -cne 'confirmed' -or -not $row.id -or -not $row.reviewer -or [int]$row.revision -lt 1) { throw 'Invalid shared review returned by Google.' }
    }
    foreach ($entry in $slots.GetEnumerator()) { if (@($response.accepted) -ccontains $entry.Value) { $ack[$entry.Key]=$entry.Value } }
    $response | Add-Member NoteProperty acknowledged ([pscustomobject]$ack) -Force
    $temporary=$cache+'.'+[Guid]::NewGuid().ToString('N')+'.tmp'
    $json=$response | ConvertTo-Json -Depth 20 -Compress
    [IO.File]::WriteAllText($temporary,$json,$utf8)
    if ([IO.File]::Exists($cache)) { [IO.File]::Replace($temporary,$cache,$cache+'.bak') }
    else { [IO.File]::Move($temporary,$cache) }
    $result=@{ok=$true;token=$request.token;cache_path=$cache;uploaded=$response.uploaded;conflicts=@($response.conflicts).Count;count=@($response.rows).Count}
} catch {
    # Do not echo URL/key or network exception details into the GUI/log.
    $safe=$_.Exception.Message
    if ($safe -match 'https?://|remote server|underlying connection|timed out|name could not be resolved|No such host') { $safe='Could not reach Google Sheets. Check your internet and deployment settings, then retry. Local reviews are unchanged.' }
    $result=@{ok=$false;token=$request.token;error=$safe}
} finally {
    if ($temporary -and [IO.File]::Exists($temporary)) { [IO.File]::Delete($temporary) }
}
$resultTemporary=$resultPath+'.tmp'
[IO.File]::WriteAllText($resultTemporary,($result | ConvertTo-Json -Depth 5 -Compress),$utf8)
if ([IO.File]::Exists($resultPath)) { [IO.File]::Replace($resultTemporary,$resultPath,$resultPath+'.bak');[IO.File]::Delete($resultPath+'.bak') }
else { [IO.File]::Move($resultTemporary,$resultPath) }
