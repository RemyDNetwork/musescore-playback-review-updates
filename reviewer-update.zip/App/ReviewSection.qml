import QtQuick
import QtQuick.Controls
import QtQuick.Layouts

ColumnLayout {
    id: section
    implicitWidth: 0
    Layout.minimumWidth: 0
    property string title: ""
    property bool expanded: true
    property real maximumContentHeight: 360
    default property alias contents: content.data
    spacing: 8

    ReviewButton {
        Layout.fillWidth: true
        text: (section.expanded ? "\u25BE  " : "\u25B8  ") + section.title
        Accessible.name: section.title + (section.expanded ? ", expanded" : ", collapsed")
        onClicked: section.expanded = !section.expanded
    }
    Flickable {
        id: viewport
        visible: section.expanded
        Layout.fillWidth: true
        Layout.minimumWidth: 0
        Layout.preferredHeight: Math.min(content.implicitHeight, section.maximumContentHeight)
        clip: true
        contentWidth: width
        contentHeight: content.implicitHeight
        interactive: contentHeight > height
        boundsBehavior: Flickable.StopAtBounds
        onWidthChanged: contentX = 0
        onContentHeightChanged: contentY = Math.max(0, Math.min(contentY, contentHeight-height))
        ScrollBar.vertical: ScrollBar {
            orientation:Qt.Vertical; parent: viewport; x: viewport.width-width; y: 0; height: viewport.height
            policy: size < 1 ? ScrollBar.AlwaysOn : ScrollBar.AlwaysOff
            width: 14
            contentItem: Rectangle { implicitWidth: 12; radius: 6; color: parent.pressed ? "#e5cfa7" : "#9faebb" }
            background: Rectangle { radius: 6; color: "#303943" }
        }
        ColumnLayout {
            id: content
            implicitWidth: 0
            width: Math.max(0, viewport.width - 22)
            spacing: 10
        }
    }
}
