@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0UpgradeReviewBooks.ps1" %*
pause
