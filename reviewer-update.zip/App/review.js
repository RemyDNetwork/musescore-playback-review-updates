var columns = ["id", "title", "reviewer", "bpm", "beat_unit", "quarter_bpm", "feel", "swing_ratio", "fermatas_json", "status", "reviewed_at", "book_source_sha256"];

// Qt supplies logical screen coordinates: do not multiply by display scaling.
function compactWindowGeometry(screen, current, reset) {
    var maxWidth=Math.max(280,Math.floor(screen.width)-32);
    var maxHeight=Math.max(240,Math.floor(screen.height)-96);
    var minWidth=Math.min(360,maxWidth), minHeight=Math.min(520,maxHeight);
    var width=reset ? Math.min(400,maxWidth) : Math.max(minWidth,Math.min(current.width,maxWidth));
    var height=reset ? Math.min(900,maxHeight) : Math.max(minHeight,Math.min(current.height,maxHeight));
    var left=screen.x+16, top=screen.y+32;
    return {width:width,height:height,minimumWidth:minWidth,minimumHeight:minHeight,
        x:reset ? Math.round(screen.x+(screen.width-width)/2) : Math.max(left,Math.min(current.x,left+maxWidth-width)),
        y:reset ? Math.round(top+(maxHeight-height)/2) : Math.max(top,Math.min(current.y,top+maxHeight-height))};
}

function bookCatalog(rows) {
    if(!Array.isArray(rows) || !rows.length || rows.length>1000) throw new Error("Invalid book list.");
    var seen={};
    rows.forEach(function(row) {
        if(!row || !/^(?:(?:Hymns|Choruses)-[0-9]{2}-review|Sunday-School-Choruses-review)\.mscz$/.test(row.file) || seen[row.file] || !row.label || !/^[a-f0-9]{64}$/.test(row.source_sha256) || !Number.isInteger(row.songs) || row.songs<1 || row.songs>2000 || (row.file!=="Sunday-School-Choruses-review.mscz" && (!row.first || !row.last)) || !/^[45]\.[0-9]+$/.test(row.score_format)) throw new Error("Invalid or duplicate review section.");
        seen[row.file]=true;
    });
    return rows;
}

function verseCount(texts) {
    for(var i=0;i<texts.length;i++) {
        var text=String(texts[i]).replace(/<[^>]*>/g,"").replace(/&nbsp;|&#160;/gi," ");
        var match=text.match(/\b([1-9][0-9]?)\s+verses?\b/i);
        if(match) {
            var count=Number(match[1]);
            if(count>32) throw new Error("Verse count exceeds 32; check the score header.");
            return count;
        }
    }
    return 0;
}

var instrumentPresets = [
    {name:"Grand Orchestra", programs:[40,60,42,43,48]},
    {name:"Warm Strings", programs:[40,41,42,43,0]},
    {name:"Bright & Joyful", programs:[73,71,60,70,0]},
    {name:"Majestic Brass", programs:[56,60,57,58,19]},
    {name:"Gentle & Reflective", programs:[68,71,42,43,46]},
    {name:"Default — Grand Piano", programs:[0,0,0,0,0], all:true}
];
function presetAssignments(labels, options, index) {
    if(!Number.isInteger(index) || !instrumentPresets[index]) throw new Error("Choose an instrument preset.");
    var result=[], voices=["soprano","alto","tenor","bass","chords"];
    labels.forEach(function(label, group) {
        if(group<3) return;
        var name=String(label).trim().toLowerCase(), voice=voices.indexOf(name);
        var chorusVoice=name.match(/^(?:(?:1st|2nd)\s+)?chorus\s+(soprano|alto|tenor|bass)$/);
        if(chorusVoice) voice=voices.indexOf(chorusVoice[1]);
        if(/^chords(?:[. :]|$)/.test(name)) voice=4;
        if(instrumentPresets[index].all) voice=0;
        if(voice<0) return;
        var program=instrumentPresets[index].programs[voice];
        var sound=options.filter(function(o) {return o.id === "SoundFonts\\MS Basic\\0\\"+program;})[0];
        if(!sound) throw new Error("A preset sound is unavailable. Wait for instruments to load.");
        result.push({group:group,id:sound.id});
    });
    if(!result.length) throw new Error("This score has no separate Soprano, Alto, Tenor, Bass or Chords channels.");
    return result;
}
function songMatch(songs, text) {
    var query=String(text).trim().toLowerCase();
    if(!query) return -1;
    var exact=songs.findIndex(function(s) {return s.id.toLowerCase()===query || (s.id+" — "+s.title).toLowerCase()===query;});
    if(exact>=0) return exact;
    var titles=[],matches=[];
    songs.forEach(function(s,i){
        if(s.title.toLowerCase()===query) titles.push(i);
        if((s.id+" "+s.title).toLowerCase().indexOf(query)>=0) matches.push(i);
    });
    if(titles.length) return titles.length===1 ? titles[0] : -1;
    return matches.length===1 ? matches[0] : -1;
}

function sharedProgress(rows, songs, current) {
    var ids={}; rows.forEach(function(row) { ids[row.id]=true });
    var done=songs.filter(function(song) { return ids[song.id] }).length, next=-1;
    for(var n=1;n<=songs.length;n++) { var index=(current+n)%songs.length;if(!ids[songs[index].id]) {next=index;break;} }
    return {done:done,next:next,reviewed:!!(songs[current] && ids[songs[current].id])};
}

function sharedAnswerSummary(row) {
    if(!row) return "Not reviewed.";
    function markings(json,kind) {
        try {
            var values=JSON.parse(json || "[]").filter(function(item){return kind==="holds" || item.tick_offset>0;}).map(function(item){return "bar "+item.bar+": "+(Math.round(Number(kind==="holds" ? item.percent : item.quarter_bpm)*100)/100)+(kind==="holds" ? "%" : " quarter-note BPM");});
            return values.filter(function(value,index){return values.indexOf(value)===index;}).join("; ") || "None";
        } catch(error) {return "Details unavailable";}
    }
    return row.reviewer+" · "+new Date(row.reviewed_at).toLocaleString()+"\n"+row.bpm+" BPM ("+String(row.beat_unit).replace(/_/g," ")+") · "+row.feel+" · swing "+row.swing_ratio+"%\n"+
        "Notes should be grace notes: "+row.grace_notes_missing+" · Issues: "+row.score_has_issues+"\n"+(row.issue_notes || "No issue notes.")+"\nHolds: "+markings(row.fermatas_json,"holds")+"\nAdditional tempo changes: "+markings(row.tempos_json,"tempos");
}

function validateSharedDecision(row, song, hash) {
    if(!row || row.id!==song.id || row.book_source_sha256!==hash || row.status!=="confirmed" || !String(row.reviewer || "").trim()) throw new Error("Shared answer identity does not match this score.");
    var revision=Number(row.revision), bpm=validNumber(row.bpm,20,300,"Shared tempo"), ratio=validNumber(row.swing_ratio,0,100,"Shared swing");
    if(!Number.isSafeInteger(revision) || revision<1 || !Number.isInteger(ratio) || row.beat_unit!==song.beat_unit || Math.abs(Number(row.quarter_bpm)-bpm*song.beat_factor)>0.001 || !Number.isFinite(Number(row.quarter_bpm)) || ["straight","swing"].indexOf(row.feel)<0) throw new Error("Invalid shared playback settings.");
    if([row.grace_notes_missing,row.score_has_issues].some(function(value) {return value!=="yes" && value!=="no";})) throw new Error("Invalid shared review answers.");
    var holds=JSON.parse(row.fermatas_json), tempos=JSON.parse(row.tempos_json);
    if(!Array.isArray(holds) || !Array.isArray(tempos) || !tempos.length) throw new Error("Shared playback details are missing.");
    holds.forEach(function(h) {validNumber(h.percent,100,1000,"Shared hold");if(!Number.isInteger(h.tick_offset) || h.tick_offset<0 || !Array.isArray(h.tracks) || !h.tracks.length || h.tracks.some(function(t) {return !Number.isInteger(t) || t<0;})) throw new Error("Invalid shared fermata location.");});
    tempos.forEach(function(t) {validNumber(t.quarter_bpm,20,600,"Shared tempo marking");if(!Number.isInteger(t.tick_offset) || t.tick_offset<0 || !Number.isInteger(t.track) || t.track<0) throw new Error("Invalid shared tempo location.");});
    return {row:row,revision:revision,bpm:bpm,ratio:ratio,holds:holds,tempos:tempos};
}

function command(code, major) {
    if (major < 5) return code;
    var paths = {play:"playback/play", pause:"playback/pause", stop:"playback/stop",
                 "play-from-selection":"playback/play-selection", repeat:"playback/repeats-toggle", loop:"playback/loop-toggle", metronome:"playback/metronome-toggle", "file-save":"project/save"};
    if (!paths[code]) throw new Error("Unknown playback command: " + code);
    return "command://" + paths[code];
}

function playingIcon(items) {
    var icon = actionIcon(items, "play");
    return icon !== null ? icon : actionIcon(items, "play-toggle");
}

function playbackChecked(items, code, major) {
    return checkedAction(items, major < 5 ? code : command(code, major));
}

function pathFromUrl(url) {
    return decodeURIComponent(String(url)).replace(/^file:\/\/\//, "");
}

function reviewerFile(name) {
    var safe = name.trim().replace(/[^a-zA-Z0-9_-]+/g, "-").replace(/^-+|-+$/g, "");
    if (!safe) throw new Error("Enter a reviewer name containing letters or numbers.");
    return "Review-" + safe + ".csv";
}

function parseCsv(text) {
    if (!text) return [];
    var rows = [], row = [], value = "", quoted = false;
    text = text.replace(/^\uFEFF/, "");
    for (var i = 0; i < text.length; ++i) {
        var ch = text[i];
        if (ch === '"') {
            if (quoted && text[i + 1] === '"') { value += '"'; ++i; }
            else if (quoted || value === "") quoted = !quoted;
            else throw new Error("Malformed CSV quote.");
        } else if (!quoted && (ch === "," || ch === "\n" || ch === "\r")) {
            row.push(value); value = "";
            if (ch !== ",") {
                if (ch === "\r" && text[i + 1] === "\n") ++i;
                if (row.some(function(x) { return x !== ""; })) rows.push(row);
                row = [];
            }
        } else value += ch;
    }
    if (quoted) throw new Error("Unclosed CSV quote.");
    if (value !== "" || row.length) { row.push(value); rows.push(row); }
    return rows;
}

function records(text) {
    var rows = parseCsv(text);
    if (!rows.length) return [];
    var header = rows.shift();
    if (columns.some(function(c) { return header.indexOf(c) < 0; })) throw new Error("The existing CSV has an incompatible header.");
    return rows.map(function(row) {
        if (row.length !== header.length) throw new Error("The existing CSV contains a damaged row.");
        var obj = {};
        header.forEach(function(key, i) { obj[key] = row[i]; });
        return obj;
    });
}

function savedDecision(text, id, source) {
    return records(text).filter(function(row) { return row.id === id && row.book_source_sha256 === source; })[0] || {};
}

function seconds(time) {
    var parts = String(time).split(":");
    return Number(parts[0])*3600 + Number(parts[1])*60 + Number(parts[2]);
}

function csvCell(value) {
    return '"' + String(value == null ? "" : value).replace(/"/g, '""') + '"';
}

function csvText(existing, decision) {
    var rows = records(existing), header = existing ? parseCsv(existing)[0] : columns.slice();
    Object.keys(decision).forEach(function(k) { if (header.indexOf(k) < 0) header.push(k); });
    // Preserve unknown columns and other songs; replace one confirmed decision.
    var found = -1;
    rows.forEach(function(row, i) {
        if (row.id === decision.id) {
            if (found >= 0) throw new Error("Duplicate song IDs in the existing CSV.");
            if (row.book_source_sha256 !== decision.book_source_sha256 || row.reviewer !== decision.reviewer) throw new Error("The existing row belongs to a different book or reviewer.");
            found = i;
        }
    });
    if (found < 0) rows.push(decision);
    else Object.keys(decision).forEach(function(k) { rows[found][k] = decision[k]; });
    return header.map(csvCell).join(",") + "\r\n" + rows.map(function(row) {
        return header.map(function(k) { return csvCell(row[k]); }).join(",");
    }).join("\r\n") + "\r\n";
}

function checkedAction(items, code) {
    for (var i = 0; i < items.length; ++i) {
        if (items[i].id === code) return !!items[i].checked;
        var nested = checkedAction(items[i].subitems || [], code);
        if (nested !== null) return nested;
    }
    return null;
}

function actionIcon(items, code) {
    for (var i = 0; i < items.length; ++i) if (items[i].id === code) return items[i].icon;
    return null;
}

function validNumber(value, min, max, label) {
    var n = Number(value);
    if (!isFinite(n) || n < min || n > max) throw new Error(label + " must be between " + min + " and " + max + ".");
    return n;
}

// Mixer channels follow part order. Never attach both clef sliders to one channel.
function volumeGroups(parts, staffKinds, activeStaves) {
    var groups = [[], [], []], shared = false;
    parts.forEach(function(part, index) {
        var kinds = {};
        for (var staff = part.startTrack / 4; staff < part.endTrack / 4; staff++) {
            if (activeStaves[staff]) kinds[staffKinds[staff]] = true;
        }
        if (kinds.treble && kinds.bass) shared = true;
        else if (kinds.treble) groups[1].push(index);
        else if (kinds.bass) groups[2].push(index);
    });
    return {groups:groups, shared:shared};
}

function volumeDb(percent) {
    validNumber(percent, 0, 100, "Volume");
    return percent === 0 ? -120 : 20 * Math.log(percent / 100) / Math.LN10;
}

function listeningLayout(labels, saved) {
    var counts = {}, keys = labels.map(function(label, index) {
        if (index < 3) return ["main", "treble-group", "bass-group"][index];
        var name = String(label), count = counts[name] || 0;
        counts[name] = count + 1;
        return "channel:" + name + ":" + count;
    });
    var order = labels.map(function(_, index) { return index });
    function rank(index) {
        if (index === 0) return 0;
        if (index < 3) return 8;
        var name = labels[index].trim().toLowerCase();
        if (/^chords(?:\.|$)/.test(name)) return 1;
        var voice = ["soprano", "alto", "tenor", "bass"].indexOf(name);
        return voice >= 0 ? voice + 2 : 7;
    }
    order.sort(function(a, b) { return rank(a)-rank(b) || a-b });
    var preferred = [], hidden = [];
    if (saved && Array.isArray(saved.order)) saved.order.forEach(function(key) {
        var index = keys.indexOf(key);
        if (index >= 0 && preferred.indexOf(index) < 0) preferred.push(index);
    });
    order.forEach(function(index) { if (preferred.indexOf(index) < 0) preferred.push(index) });
    if (saved && Array.isArray(saved.hidden)) saved.hidden.forEach(function(key) {
        var index = keys.indexOf(key);
        if (index >= 0 && hidden.indexOf(index) < 0) hidden.push(index);
    });
    return {keys:keys, order:preferred, hidden:hidden};
}

function listeningSolos(groups, solos, count) {
    var selected = [];
    // Solo belongs to individual channels; Main and clef controls are aggregates.
    solos.forEach(function(solo, group) {
        if (!solo || group < 3) return;
        (groups[group] || []).forEach(function(index) {
            if (index >= 0 && index < count && selected.indexOf(index) < 0) selected.push(index);
        });
    });
    return selected;
}

function soundResources(menu) {
    var choices = [], original = "", seen = {};
    function visit(items, path) {
        items.forEach(function(item) {
            var title = String(item.title || ""), id = String(item.id || "");
            if (item.subitems && item.subitems.length) { visit(item.subitems, path.concat([title])); return }
            if (!/^(SoundFonts|MuseSounds|VST3)\\/.test(id)) return;
            if (item.checked && !original) original = id;
            if (id.indexOf("SoundFonts\\MS Basic") !== 0) return;
            if (item.includeInFilteredLists === false || seen[id]) return;
            seen[id] = true;
            choices.push({id:id, title:title, label:path.concat([title]).join(" / ")});
        });
    }
    visit(menu, []);
    return {choices:choices, original:original};
}

function instrumentChannels(group, groups, count) {
    var indices = group === 0 ? Array.from({length:count}, function(_, i) { return i }) : (groups[group] || []);
    return indices.filter(function(index) { return index >= 0 && index < count });
}

function listeningDb(state, index, groups, levels, mutes) {
    var db = state.db, muted = state.muted;
    groups.forEach(function(indices, group) {
        if (indices.indexOf(index) < 0) return;
        if (mutes[group] || levels[group] === 0) muted = true;
        else db += volumeDb(levels[group]);
    });
    return muted ? -120 : Math.max(-120, db);
}

function reviewProgress(csv, songs, source, reviewer, current) {
    var confirmed = {}, done = 0, next = -1;
    records(csv).forEach(function(row) {
        if (row.book_source_sha256 === source && row.reviewer === reviewer.trim() && row.status === "confirmed") confirmed[row.id] = true;
    });
    songs.forEach(function(song) { if (confirmed[song.id]) done++; });
    for (var offset = 1; offset <= songs.length; offset++) {
        var index = (current + offset) % songs.length;
        if (!confirmed[songs[index].id]) { next = index; break; }
    }
    return {done:done, next:next, reviewed:!!(songs[current] && confirmed[songs[current].id])};
}
