using System;
using System.Collections.Generic;
using System.Globalization;
using System.Xml;

// Keep the large combined books out of a second in-memory DOM while MuseScore is open.
public static class PsalmistAudioCrop
{
    static string NewId()
    {
        byte[] bytes=Guid.NewGuid().ToByteArray();string result="";
        for(int half=0;half<2;half++) {
            ulong value=BitConverter.ToUInt64(bytes,half*8);string part="";
            do {part+="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"[(int)(value&63)];value>>=6;}while(value!=0);
            result+=(half==0?"":"_")+part;
        }
        return result;
    }
    static void Remap(XmlNode node,Dictionary<string,string> ids)
    {
        foreach(XmlNode field in node.SelectNodes(".//eid|.//startElement|.//endElement")) {
            string value;if(ids.TryGetValue(field.InnerText,out value))field.InnerText=value;
        }
    }
    static XmlElement Gap(XmlDocument doc,int numerator,int denominator,double tempo,bool resetTiming)
    {
        string duration=numerator+"/"+denominator;
        var measure=doc.CreateElement("Measure");measure.SetAttribute("len",duration);
        var voice=doc.CreateElement("voice");measure.AppendChild(voice);
        if(resetTiming) {
            var meter=doc.CreateElement("TimeSig");meter.InnerXml="<sigN>"+numerator+"</sigN><sigD>"+denominator+"</sigD>";voice.AppendChild(meter);
            var marking=doc.CreateElement("Tempo");marking.InnerXml="<tempo>"+tempo.ToString("R",CultureInfo.InvariantCulture)+"</tempo><followText>0</followText><text>Verse break</text>";
            voice.AppendChild(marking);
        }
        var rest=doc.CreateElement("Rest");rest.InnerXml="<durationType>measure</durationType><duration>"+duration+"</duration>";
        voice.AppendChild(rest);return measure;
    }
    public static void Repeat(XmlDocument doc,int count,int gapBars=0)
    {
        if(count<1 || count>32 || gapBars<0 || gapBars>16) throw new ArgumentException("Invalid verse count or break.");
        var score=doc.SelectSingleNode("/museScore/Score");var ids=new HashSet<string>();
        var firstStaff=score.SelectSingleNode("Staff");int numerator=4,denominator=4;double openingTempo=0;
        if(gapBars>0 && count>1) {
            var meter=firstStaff.SelectSingleNode("Measure[1]//TimeSig");
            if(meter!=null && (!Int32.TryParse(meter.SelectSingleNode("sigN").InnerText,out numerator) || !Int32.TryParse(meter.SelectSingleNode("sigD").InnerText,out denominator) || numerator<1 || numerator>128 || denominator<1 || denominator>128)) throw new ArgumentException("Invalid opening time signature.");
            var marking=firstStaff.SelectSingleNode("Measure[1]//Tempo/tempo");
            if(marking==null || !Double.TryParse(marking.InnerText,NumberStyles.Float,CultureInfo.InvariantCulture,out openingTempo) || Double.IsNaN(openingTempo) || Double.IsInfinity(openingTempo) || openingTempo<=0) throw new ArgumentException("Opening tempo is missing or invalid.");
        }
        foreach(XmlNode id in score.SelectNodes("Staff//eid"))ids.Add(id.InnerText);
        var map=score.SelectSingleNode("SpannerMap");var spanners=new List<XmlNode>();
        if(map!=null) {
            for(int i=map.ChildNodes.Count-1;i>=0;i--) {
                var s=map.ChildNodes[i];var a=s.SelectSingleNode("startElement");var b=s.SelectSingleNode("endElement");
                if(s.Name=="Volta" || a==null || b==null || !ids.Contains(a.InnerText) || !ids.Contains(b.InnerText))map.RemoveChild(s);
            }
            foreach(XmlNode s in map.ChildNodes){spanners.Add(s);foreach(XmlNode id in s.SelectNodes(".//eid"))ids.Add(id.InnerText);}
        }
        var measures=new List<XmlNode>();foreach(XmlNode m in score.SelectNodes("Staff/Measure"))measures.Add(m);
        for(int pass=1;pass<count;pass++) {
            var replacements=new Dictionary<string,string>();foreach(string id in ids)replacements[id]=NewId();
            XmlNode previousStaff=null;
            foreach(XmlNode m in measures){
                if(m.ParentNode!=previousStaff) for(int bar=0;bar<gapBars;bar++) m.ParentNode.AppendChild(Gap(doc,numerator,denominator,openingTempo,m.ParentNode==firstStaff && bar==0));
                previousStaff=m.ParentNode;
                var clone=m.CloneNode(true);Remap(clone,replacements);m.ParentNode.AppendChild(clone);
            }
            foreach(XmlNode s in spanners){var clone=s.CloneNode(true);Remap(clone,replacements);map.AppendChild(clone);}
        }
    }
    static XmlElement Element(XmlDocument doc, XmlReader reader)
    {
        var node=doc.CreateElement(reader.Name);
        if(reader.MoveToFirstAttribute()) {
            do {node.SetAttribute(reader.Name,reader.Value);} while(reader.MoveToNextAttribute());
            reader.MoveToElement();
        }
        return node;
    }
    public static XmlDocument Read(XmlReader reader,int start,int end)
    {
        var doc=new XmlDocument();reader.MoveToContent();
        var root=Element(doc,reader);doc.AppendChild(root);reader.Read();
        while(!reader.EOF) {
            if(reader.NodeType!=XmlNodeType.Element){reader.Read();continue;}
            if(reader.Depth!=1 || reader.Name!="Score") {
                var other=doc.ReadNode(reader);if(other!=null)root.AppendChild(other);continue;
            }
            var score=Element(doc,reader);root.AppendChild(score);reader.Read();
            while(!reader.EOF && !(reader.NodeType==XmlNodeType.EndElement && reader.Depth==1)) {
                if(reader.NodeType!=XmlNodeType.Element){reader.Read();continue;}
                if(reader.Depth==2 && (reader.Name=="Score" || reader.Name=="Excerpt")){reader.Skip();continue;}
                if(reader.Depth!=2 || reader.Name!="Staff") {
                    var other=doc.ReadNode(reader);if(other!=null)score.AppendChild(other);continue;
                }
                bool firstStaff=score.SelectSingleNode("Staff")==null;
                var staff=Element(doc,reader);score.AppendChild(staff);
                var context=new Dictionary<string,string>();var frames=new List<XmlNode>();int bar=-1;
                reader.Read();
                while(!reader.EOF && !(reader.NodeType==XmlNodeType.EndElement && reader.Depth==2)) {
                    if(reader.NodeType!=XmlNodeType.Element){reader.Read();continue;}
                    if(reader.Depth!=3 || reader.Name!="Measure") {
                        var frame=doc.ReadNode(reader);if(frame!=null)frames.Add(frame);continue;
                    }
                    ++bar;
                    if(bar<start) {
                        using(var sub=reader.ReadSubtree()) {
                            sub.Read();
                            while(!sub.EOF) {
                                if(sub.NodeType==XmlNodeType.Element && (sub.Name=="KeySig" || sub.Name=="TimeSig" || sub.Name=="Clef")) {
                                    string name=sub.Name;context[name]=sub.ReadOuterXml();
                                }else{sub.Read();}
                            }
                        }
                        reader.Read();frames.Clear();continue;
                    }
                    if(bar>end){reader.Skip();frames.Clear();continue;}
                    if(bar==start)foreach(var frame in frames)staff.AppendChild(frame);
                    frames.Clear();
                    var measure=(XmlElement)doc.ReadNode(reader);
                    if(bar==start)foreach(var entry in context) {
                        if(entry.Key=="TimeSig" && !firstStaff)continue;
                        if(measure.SelectSingleNode(".//"+entry.Key)!=null)continue;
                        var fragment=doc.CreateDocumentFragment();fragment.InnerXml=entry.Value;
                        var voice=measure.SelectSingleNode("voice");
                        if(voice!=null)voice.PrependChild(fragment);
                    }
                    staff.AppendChild(measure);
                }
                reader.Read();
                if(bar<end)throw new InvalidOperationException("Song extends beyond the saved score.");
            }
            reader.Read();
        }
        return doc;
    }
}
