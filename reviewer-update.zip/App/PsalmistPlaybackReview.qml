import QtQuick
import QtQml.Models
import QtQuick.Window
import QtQuick.Controls
import QtQuick.Controls as Controls
import QtQuick.Layouts
import MuseScore 3.0
import FileIO 3.0
import MuseScore.Playback
import MuseScore.Project
import Muse.Ui
import "review.js" as Review

MuseScore {
    id: root
    title: "Psalmist Playback Review"
    description: "Review song tempo, Straight/Swing and fermata durations"
    version: "0.13.1"
    categoryCode: ""
    pluginType: ""
    requiresScore: true
    width: 450
    height: 560

    property var book: null
    property var ownedScore: null
    property string scorePath: ""
    property var measures: []
    property var tempoElement: null
    property var tempos: []
    property var feelElement: null
    property var templates: ({})
    property var fermatas: []
    property int songIndex: 0
    property real bpm: 120
    property real baseQuarterBpm: 120
    property string feel: "straight"
    property int swingRatio: 67
    property string appliedFeel: ""
    property int appliedSwingRatio: -1
    property real songStartSeconds: 0
    property var decisions: ({})
    property bool dirty: false
    property bool ready: false
    property bool initialized: false
    property bool saving: false
    property string afterStop: ""
    property double stopDeadline: 0
    property double stopReadyAt: 0
    property int playbackRetries: 0
    property bool startPositionPending: false
    property bool stopRequested: false
    readonly property bool busy: saving || afterStop !== "" || bookSwitch !== null
    property bool audition: false
    property bool loopSong: false
    property int loopPasses: 0
    property bool savedMetronome: false
    property bool paused: false
    property bool seenPlaying: false
    property var tempoChange: null
    property bool diagnosticsEnabled: false
    property var tempoChecks: []
    property var feelChecks: []
    property var playbackChecks: []
    property var pending: null
    property var exportPending:null
    property string exportMode:"part"
    property int exportVerses:1
    property int exportGapBars:0
    property string exportPromptSong:""
    property int exportHeartbeatRetry:0
    property string exportMessage:"Exports use your current listening instruments, volumes, mutes and solos."
    property var reviewBaseline: null
    property int pendingNavigation: -1
    property bool pendingClose: false
    property var bookCatalog: []
    property var pendingBook: null
    property var bookSwitch: null
    property bool bookSyncAfterLoad: false
    property string message: "Loading review book…"
    property string csvBefore: ""
    property string csvPath: ""
    property var syncPending: null
    property bool syncAutoPaused: false
    property bool sharedApplyPending: false
    readonly property bool syncing: syncPending !== null
    property string syncMessage: "Optional: connect to the organiser's Google Sheet."
    property var sharedReviews: []
    property string sharedAt: ""
    property bool syncConfigured:false
    property var sharedRevisions:({})
    property var syncConflicts:[]
    property var sharedUnsavedRows:[]
    readonly property var progress: ready ? (syncConfigured ? Review.sharedProgress(sharedReviews,book.songs,songIndex) : Review.reviewProgress(csvBefore, book.songs, book.source_sha256, reviewer.text, songIndex)) : ({done:0, next:-1})
    readonly property bool currentSongReviewed: ready && (progress.reviewed || Review.reviewProgress(csvBefore,book.songs,book.source_sha256,reviewer.text,songIndex).reviewed)
    property bool savedRepeat: false
    property bool savedLoop: false
    property real savedMultiplier: 1

    property var mixerSnapshot: []
    property var volumeChannels: [[], [], []]
    property var volumeLevels: [100, 100, 100]
    property var volumeMutes: [false, false, false]
    property var volumeSolos: [false, false, false]
    property var volumeOrder: []
    property var hiddenVolumeRows: []
    property var volumeKeys: []
    property var listeningLayouts: ({})
    readonly property var shownVolumeRows: volumeOrder.filter(function(group) { return hiddenVolumeRows.indexOf(group)<0 })
    property var volumeLabels: ["Main", "Treble clef", "Bass clef"]
    property string volumeNotice: "Loading mixer…"
    property bool mixerSuspended: false
    property double mixerStableSince:0
    property var soundOptions: []
    property int soundRevision: 0
    property int instrumentGroup: 0
    NavigationSection { id: volumeNavigation; name: "Review volume"; order: 1; enabled: false }
    MixerPanelModel { id:mixer; navigationSection:volumeNavigation }
    Timer {
        interval: 250; repeat: true; running: root.ready && root.mixerSnapshot.length === 0
        onTriggered: root.loadMixer()
    }
    Timer {
        interval:250; repeat:true; running:root.ready && !root.bookSwitch
        onTriggered: {
            if (curScore && root.ownedScore && curScore.is(root.ownedScore)) return;
            tempoUpdate.stop(); feelUpdate.stop(); volumeSaveDelay.stop();
            root.tempoChange = null; root.afterStop = ""; root.audition = false;
            root.cancelSync(); root.sharedApplyPending=false;
            root.ready = false; root.mixerSnapshot = []; root.pendingClose = false;
            root.pendingNavigation = -1; unsaved.close();
            root.message = "Active book changed. Close this panel and reopen it for that book.";
        }
    }
    Timer {
        id:soundRefresh
        interval:1000; repeat:true; running:root.ready && (root.mixerSuspended || (!root.busy && !root.soundsReady()))
        // Recover a missed native resource notification without resending sound changes.
        onTriggered: root.mixerSnapshot.slice(0,-1).forEach(function(state,index) {
            var expected = root.mixerSuspended ? state.originalSound : state.chosenSound;
            if (!state.originalSound || state.currentSound !== expected) root.requestSounds(index);
        })
    }
    PlaybackToolBarModel { id: transport }
    // Earlier development builds retain the 4.x commands; current 5.x uses command URIs.
    readonly property int transportApi: Review.actionIcon(transport.items, "play-toggle") !== null ? 5 : 4
    ProjectPropertiesModel { id: projectInfo }
    FileIO { id: io; onError: function(msg) { root.message = msg } }
    FileIO { id: diagnostics }
    FileIO { id: preferences; source: Review.pathFromUrl(Qt.resolvedUrl("reviewer.json")) }
    FileIO { id:layoutPreferences; source:Review.pathFromUrl(Qt.resolvedUrl("listening-layouts.json")) }
    FileIO { id:syncPreferences; source:Review.pathFromUrl(Qt.resolvedUrl("sheets-sync.json")) }
    FileIO { id:syncIo }
    FileIO { id:exportIo }
    FileIO { id:bookIo }
    // Resource acknowledgements must remain connected when rows are hidden/reordered.
    Instantiator {
        model:Math.max(0,root.mixerSnapshot.length-1)
        delegate: Item {
            required property int index
            Component.onCompleted: Qt.callLater(function() { root.requestSounds(index) })
            Connections {
                target:root.mixerSnapshot[index] ? root.mixerSnapshot[index].channel.inputResourceItem : null
                function onAvailableResourceListResolved(resources) { root.receiveSounds(index,resources) }
                function onInputParamsChanged() { root.requestSounds(index) }
            }
        }
    }
    ListModel { id: songs }
    ListModel { id: holds }

    function loadBookCatalog() {
        bookCatalog=[];
        try {
            bookIo.source=scorePath.replace(/[^/\\]+$/,"sections.json");
            if(!bookIo.exists()) return;
            bookCatalog=Review.bookCatalog(JSON.parse(bookIo.read()));
            showBookSelection();
        } catch(error) { fail("Book list could not be read: "+error) }
    }
    function showBookSelection() {
        var file=scorePath.replace(/^.*[/\\]/,"");
        bookBox.currentIndex=bookCatalog.findIndex(function(row){return row.file===file;});
    }
    function stageBookRequest(mode,row) {
        bookIo.source=Review.pathFromUrl(Qt.resolvedUrl("watcher-heartbeat.json"));
        var heartbeat=null;
        try {heartbeat=bookIo.exists() ? JSON.parse(bookIo.read()) : null;}catch(error){return null;}
        if(!heartbeat || Date.now()-Number(heartbeat.updated)>15000 || !isFinite(Number(heartbeat.updated))) throw new Error("Restart through START HERE to enable book switching. The current book stays open.");
        var token=Date.now()+"-"+Math.floor(Math.random()*1000000000);
        var path=Review.pathFromUrl(Qt.resolvedUrl("book-"+token+".json"));
        var request={token:token,mode:mode,score_path:scorePath,target_file:row.file,version:mscoreMajorVersion,
            source_sha256:book.source_sha256,decisions_json:curScore.metaTag("psalmist-review-decisions"),revisions_json:curScore.metaTag("psalmist-shared-revisions")};
        bookIo.source=path;
        if(!bookIo.write(JSON.stringify(request))) throw new Error("Could not stage the book switch. The current book stays open.");
        return {stage:mode,path:path,token:token,row:row,oldPath:scorePath,started:Date.now()};
    }
    function requestBookSwitch(index) {
        try {
            sameScore();
            if(busy || tempoChange || exportPending || unsaved.visible) return;
            if(!soundsReady()) throw new Error("Wait for the listening instruments to load before switching books.");
            if(sharedUnsavedRows.length) throw new Error("Retry Save score + CSV to verify the shared answers before switching books.");
            var row=bookCatalog[index];
            if(!row || scorePath.replace(/^.*[/\\]/,"")===row.file) return;
            if(mscoreMajorVersion<5 && Number(row.score_format)>=5) throw new Error("Choruses require MuseScore 5. Use the included MuseScore 5 app.");
            stop();cancelSync("Switching books. Saved reviews remain queued for sync.");
            bookSwitch=stageBookRequest("check",row) || {stage:"helper",row:row,oldPath:scorePath,started:Date.now()};
            message="Checking the selected book…";
        } catch(error) { fail(error);showBookSelection() }
    }
    function beginBookSwitch() {
        try {
            sameScore();
            if(!pendingBook || saving || sharedUnsavedRows.length) throw new Error("Finish saving the current reviews before switching.");
            var row=pendingBook;pendingBook=null;
            stop();feelUpdate.stop();cancelSync();
            bookSwitch={stage:"restore",row:row,oldPath:scorePath,started:Date.now()};
            mixerSuspended=true;mixerStableSince=0;restoreMixer();restoreInstruments();
            message="Saving the current book before switching…";
        } catch(error) { failBookSwitch(error) }
    }
    function cancelBookSwitch() {
        if(!bookSwitch) {pendingBook=null;return true;}
        if(["helper","check","restore"].indexOf(bookSwitch.stage)<0) return false;
        if(bookSwitch.path) {bookIo.source=bookSwitch.path+".cancel";bookIo.write("cancel");}
        bookSwitch=null;pendingBook=null;mixerSuspended=false;applyVolumes();applyInstruments();showBookSelection();
        message="Book switch cancelled. The current book stays open.";return true;
    }
    function failBookSwitch(error) {
        bookSwitch=null;pendingBook=null;mixerSuspended=false;
        if(ready) {applyVolumes();applyInstruments();showBookSelection();}
        fail("Book switch stopped: "+error+". Saved reviews remain on disk."+(ready ? "" : " Reopen the book through START HERE."));
    }
    function clearBookObjects() {
        // Detach delegates and native wrappers before the old score is destroyed.
        ownedScore=null;measures=[];tempos=[];tempoElement=null;feelElement=null;fermatas=[];templates={};reviewBaseline=null;
        holds.clear();songs.clear();mixerSnapshot=[];soundOptions=[];volumeChannels=[[],[],[]];volumeLabels=["Main","Treble clef","Bass clef"];
        decisions={};sharedRevisions={};sharedReviews=[];syncConflicts=[];sharedUnsavedRows=[];sharedApplyPending=false;sharedAt="";
        csvBefore="";csvPath="";pending=null;pendingNavigation=-1;pendingClose=false;syncAutoPaused=false;
    }
    function pollBookSwitch() {
        var state=bookSwitch;
        if(!state || state.nativeCall) return;
        try {
            if(state.stage==="restore" && Date.now()-state.started>30000) throw new Error("Listening settings did not finish restoring; the current book stays open");
            if(Date.now()-state.started>150000) throw new Error("Book preparation timed out; retry from the current book");
            if(state.stage==="helper") {
                if(Date.now()-state.started>3000)throw new Error("The review helper could not be read; retry switching");
                var request=stageBookRequest("check",state.row);
                if(request)bookSwitch=request;
            } else if(state.stage==="check" || state.stage==="checkpoint") {
                bookIo.source=state.path+".result.json";
                if(!bookIo.exists())return;
                var result;try {result=JSON.parse(bookIo.read());}catch(error){return;}
                if(!result.ok || result.token!==state.token) throw new Error(result.error || "Book verification did not match the request");
                bookIo.remove();bookIo.source=state.path;bookIo.remove();
                if(state.stage==="check") {
                    bookSwitch=null;pendingBook=state.row;
                    if(dirty) unsaved.open();else beginBookSwitch();
                } else {state.stage="close";state.started=Date.now();}
            } else if(state.stage==="restore") {
                if(Review.playingIcon(transport.items)===IconCode.PAUSE || Date.now()<stopReadyAt)return;
                if(!mixerRestored()) {mixerStableSince=0;restoreMixer();return;}
                if(!mixerSnapshot.slice(0,-1).every(function(s){return s.currentSound===s.originalSound;})) {mixerStableSince=0;return;}
                if(!mixerStableSince){mixerStableSince=Date.now();return;}
                if(Date.now()-mixerStableSince<250)return;
                restoreTransport();
                var checkpoint=stageBookRequest("checkpoint",state.row);
                if(!checkpoint)return;
                curScore.setMetaTag("psalmist-review-last-song",song().id);
                curScore.setMetaTag("psalmist-book-switch-token",checkpoint.token);
                bookSwitch=checkpoint;
                state=checkpoint;state.nativeCall=true;
                try {dispatch("file-save");} finally {state.nativeCall=false;}
            } else if(state.stage==="close") {
                stop();ready=false;clearBookObjects();state.stage="detach";
            } else if(state.stage==="detach") {
                state.stage="open";state.started=Date.now();state.nativeCall=true;
                try {closeScore(curScore);} finally {state.nativeCall=false;}
            } else if(state.stage==="open") {
                if(curScore) {if(Date.now()-state.started<2000)return;throw new Error("Closing the current book was cancelled");}
                state.stage="binding";state.started=Date.now();state.nativeCall=true;
                var target=state.oldPath.replace(/[^/\\]+$/,state.row.file);
                try {readScore(target);} finally {state.nativeCall=false;}
            } else if(state.stage==="binding") {
                if(!curScore || !transport.isPlayAllowed || mixer.count<curScore.parts.length+1) {
                    state.stable=0;
                    if(Date.now()-state.started>30000)throw new Error("The selected book did not finish loading");
                    return;
                }
                if(!state.stable){state.stable=Date.now();return;}
                if(Date.now()-state.stable<500)return;
                var target=state.oldPath.replace(/[^/\\]+$/,state.row.file);
                var actual=JSON.parse(curScore.metaTag("psalmist-playback-review"));
                if(actual.source_sha256!==state.row.source_sha256 || (state.row.first && actual.songs[0].id!==state.row.first) || (state.row.last && actual.songs[actual.songs.length-1].id!==state.row.last))throw new Error("MuseScore opened a different book");
                state.stage="loading";state.nativeCall=true;
                try {loadBook(target);} finally {state.nativeCall=false;}
                mixerSuspended=false;bookSwitch=null;
            }
        } catch(error) { failBookSwitch(error) }
    }
    Timer {interval:150;repeat:true;running:root.bookSwitch!==null;onTriggered:root.pollBookSwitch()}
    Timer {
        interval:500;repeat:true;running:root.ready && root.bookSyncAfterLoad && root.syncConfigured
        onTriggered: {if(root.busy || !root.soundsReady())return;root.bookSyncAfterLoad=false;root.syncReviews(true);}
    }
    function applyPreset(index) {
        try {
            sameScore();
            if(busy || !soundsReady()) throw new Error("Wait for instruments to load before choosing a preset.");
            var assignments=Review.presetAssignments(volumeLabels,soundOptions,index), targets=[];
            assignments.forEach(function(a) {
                Review.instrumentChannels(a.group,volumeChannels,mixerSnapshot.length-1).forEach(function(i) {
                    if(mixerSnapshot[i].originalSound.indexOf("SoundFonts\\MS Basic")!==0) throw new Error("Presets need MS Basic channels.");
                    targets.push({index:i,id:a.id});
                });
            });
            targets.forEach(function(t){mixerSnapshot[t.index].chosenSound=t.id;mixerSnapshot[t.index].channel.inputResourceItem.handleMenuItem(t.id);});
            soundRevision++;message="Applied "+Review.instrumentPresets[index].name+". Adjust individual instruments or levels as wanted.";
        } catch(error) {fail(error)}
    }
    function exportAudio(mode,stopped,verses) {
        try {
            sameScore();
            if(exportPending || saving) return;
            if(!soundsReady()) throw new Error("Wait for instruments to finish loading before exporting.");
            if(mode!=="part" && mode!=="full") throw new Error("Choose Part or Full.");
            if(!stopped) {
                exportVerses=1;
                if(mode==="full") {
                    var texts=[],frame=measures[song().start-1].prev;
                    while(frame && frame.type!==Element.MEASURE) {
                        for(var i=0;i<frame.elements.length;i++) if(typeof frame.elements[i].text==="string") texts.push(frame.elements[i].text);
                        frame=frame.prev;
                    }
                    var known=Review.verseCount(texts);
                    if(!known && verses===undefined) {exportPromptSong=song().id;verseCountBox.value=1;verseDialog.open();return;}
                    var count=known || Review.validNumber(verses,1,32,"Number of verses");
                    if(!Number.isInteger(count)) throw new Error("Enter a whole number of verses.");
                    exportVerses=count;
                }
                exportGapBars=mode==="full" ? verseGapBox.value : 0;
                exportMode=mode;exportHeartbeatRetry=0;stop();afterStop="export";stopDeadline=Date.now()+30000;message="Preparing MP3 export…";return;
            }
            applyFeel(feel==="swing" ? 1 : 0);applyTempo();
            exportIo.source=Review.pathFromUrl(Qt.resolvedUrl("watcher-heartbeat.json"));
            var beat=null;
            try {beat=exportIo.exists() ? JSON.parse(exportIo.read()) : null;}catch(error){}
            // A native file read can briefly miss an atomic heartbeat replacement; retry without blocking the panel.
            if(!beat && exportHeartbeatRetry++<3){afterStop="export";return;}
            if(!beat || !isFinite(Number(beat.updated)) || Date.now()-Number(beat.updated)>15000) throw new Error("Restart through START HERE to enable MP3 export.");
            var primary=0, secondary=0, chordParts=[];
            for(var p=0;p<curScore.parts.length;p++) if(curScore.parts[p].harmonyCount>0) chordParts.push(p);
            var channels=mixerSnapshot.slice(0,-1).map(function(state,index) {
                // The native enum is not stable through stored channel wrappers; use the established part/channel order.
                var extra=index>=curScore.parts.length;
                var part=extra ? chordParts[secondary++] : primary++;
                if(part===undefined) throw new Error("Chord channel routing is unavailable in this score.");
                return {part_index:part,secondary:extra,sound:state.chosenSound,db:state.channel.volumeLevel,mute:state.channel.muted,solo:state.channel.solo};
            });
            var token=Date.now()+"-"+Math.floor(Math.random()*1000000000), path=Review.pathFromUrl(Qt.resolvedUrl("export-"+token+".json"));
            exportIo.source=path;
            var request={token:token,mode:mode,score_path:scorePath,book_source_sha256:book.source_sha256,song_id:song().id,feel:feel,swing_ratio:swingRatio,
                tempos:tempos.map(function(t){return {bar:t.bar,track:t.element.track,quarter_bpm:Number(t.element.tempo)*60};}),
                holds:fermatas.map(function(g){return {bar:g.bar,tracks:g.elements.map(function(e){return e.track;}),percent:g.percent};}),
                channels:channels,master_db:mixerSnapshot[mixerSnapshot.length-1].channel.volumeLevel,
                verse_count:exportVerses,verse_break_bars:exportGapBars};
            if(!exportIo.write(JSON.stringify(request))) throw new Error("Could not stage MP3 export.");
            exportPending={token:token,path:path,started:Date.now()};exportMessage="Rendering MP3 ("+mode+")… You can keep reviewing.";message=exportMessage;
        } catch(error) {exportMessage=String(error);message=exportMessage;}
    }
    function cancelExport() {
        if(!exportPending) return;
        exportIo.source=exportPending.path+".cancel";
        if(exportIo.write("cancel")) {exportPending=null;exportMessage="MP3 export cancelled. Your score and reviews are unchanged.";message=exportMessage;}
    }
    Timer {
        interval:250;repeat:true;running:root.exportPending!==null
        onTriggered: {
            exportIo.source=root.exportPending.path+".result.json";
            if(exportIo.exists()) {
                try {
                    var result=JSON.parse(exportIo.read());
                    if(result.token!==root.exportPending.token) throw new Error("Export result does not match this request.");
                    root.exportMessage=result.ok ? "Exported "+result.passes+" pass(es): "+result.mp3_path : result.error;
                    root.message=root.exportMessage;
                    exportIo.remove();exportIo.source=root.exportPending.path;exportIo.remove();root.exportPending=null;
                }catch(error){root.exportMessage=String(error);root.exportPending=null;}
            }else if(Date.now()-root.exportPending.started>1000000) {root.cancelExport();root.exportMessage="Export timed out. Restart through START HERE before retrying.";root.exportPending=null;}
        }
    }
    function loadMixer() {
        if (!curScore || !ownedScore || !curScore.is(ownedScore)) return;
        var primary = [], secondary = [], master = null;
        for (var i = 0; i < mixer.count; i++) {
            var channel = mixer.get(i).channelItem;
            if (channel.type === MixerChannelItem.PrimaryInstrument) primary.push(channel);
            if (channel.type === MixerChannelItem.SecondaryInstrument) secondary.push(channel);
            if (channel.type === MixerChannelItem.Master) master = channel;
        }
        if (!master || primary.length < curScore.parts.length) {
            volumeNotice = "Waiting for the score's mixer channels…"; return;
        }
        // Chord-symbol channels are appended after the instrument parts.
        mixerSnapshot = primary.concat(secondary, [master]).map(function(channel, index) {
            var label = String(channel.title).trim();
            if (!label && index < curScore.parts.length) label = curScore.parts[index].partName;
            if (label === "Chords.") label = "Chords";
            return {channel:channel, label:label || "Channel " + (index+1), db:channel.volumeLevel, muted:channel.muted, solo:channel.solo,
                    originalSound:"", currentSound:"", chosenSound:""};
        });
        var labels = ["Main", "Treble clefs (all)", "Bass clefs (all)"].concat(mixerSnapshot.slice(0,-1).map(function(state) { return state.label }));
        volumeLevels = labels.map(function() { return 100 });
        volumeMutes = labels.map(function() { return false });
        volumeSolos = labels.map(function() { return false });
        volumeLabels = labels;
        loadListeningLayout();
        updateVolumeGroups();
        console.log("PSALMIST_REVIEW mixer-ready " + primary.length);
    }
    function requestSounds(index) {
        if (!ready || !curScore || !curScore.is(ownedScore)) return;
        var state = mixerSnapshot[index];
        if (state && state.channel.inputResourceItem) state.channel.inputResourceItem.requestAvailableResources();
    }
    function receiveSounds(index, menu) {
        if (!ready || !curScore || !curScore.is(ownedScore)) return;
        var state = mixerSnapshot[index], resources = Review.soundResources(menu);
        if (!state || !resources.original) return;
        state.currentSound = resources.original;
        if (!state.originalSound) {
            state.originalSound = resources.original;
            var piano = resources.choices.filter(function(item) { return item.id.indexOf("MS Basic") >= 0 && item.title === "Grand Piano" });
            state.chosenSound = piano.length && state.originalSound.indexOf("SoundFonts\\MS Basic") === 0 ? piano[0].id : state.originalSound;
            if (!soundOptions.length) soundOptions = resources.choices;
            state.channel.inputResourceItem.handleMenuItem(state.chosenSound);
        }
        soundRevision++;
        if (!busy && (message === "Switching listening instrument…" || message.indexOf("Wait for the mixer before changing instruments.") >= 0) && soundsReady()) message = "Listening instrument ready — review settings are unchanged.";
    }
    function soundsReady() {
        var revision = soundRevision;
        return mixerSnapshot.length > 1 && mixerSnapshot.slice(0,-1).every(function(state) { return state.originalSound !== "" && (mixerSuspended || state.currentSound === state.chosenSound) });
    }
    function soundLabel(group) {
        var revision = soundRevision, indices = Review.instrumentChannels(group, volumeChannels, mixerSnapshot.length-1);
        if (!indices.length) return "No separate channel";
        var id = mixerSnapshot[indices[0]].chosenSound;
        if (!id) return "Loading instruments…";
        if (indices.some(function(index) { return mixerSnapshot[index].chosenSound !== id })) return "Mixed instruments";
        var matches = soundOptions.filter(function(option) { return option.id === id });
        return matches.length ? matches[0].title : "Original sound";
    }
    function setInstrument(group, id) {
        try {
            sameScore();
            if (busy || !soundsReady()) throw new Error("Wait for the mixer before changing instruments.");
            if (!soundOptions.some(function(option) { return option.id === id })) throw new Error("Choose an available instrument.");
            var indices = Review.instrumentChannels(group, volumeChannels, mixerSnapshot.length-1);
            if (indices.some(function(index) { return mixerSnapshot[index].originalSound.indexOf("SoundFonts\\MS Basic") !== 0 })) throw new Error("Instrument audition needs the prepared MS Basic playback channels.");
            indices.forEach(function(index) {
                mixerSnapshot[index].chosenSound = id;
                mixerSnapshot[index].channel.inputResourceItem.handleMenuItem(id);
            });
            soundRevision++;
            message = soundsReady() ? "Listening instrument ready — review settings are unchanged." : "Switching listening instrument…";
        } catch(error) { fail(error) }
    }
    function restoreInstruments() {
        mixerSnapshot.slice(0,-1).forEach(function(state) {
            if (state.originalSound) state.channel.inputResourceItem.handleMenuItem(state.originalSound);
        });
    }
    function applyInstruments() {
        if (!ready || mixerSuspended || !curScore || !curScore.is(ownedScore)) return;
        mixerSnapshot.slice(0,-1).forEach(function(state) {
            if (state.chosenSound) state.channel.inputResourceItem.handleMenuItem(state.chosenSound);
        });
    }
    function updateVolumeGroups() {
        if (!mixerSnapshot.length) return;
        restoreMixer();
        var active = [], kinds = [], end = songIndex + 1 < book.songs.length ? measures[song().end].tick.ticks : Infinity;
        var segment = measures[song().start-1].firstSegment;
        while (segment && segment.tick < end) {
            for (var track = 0; track < curScore.nstaves * 4; track++) {
                var element = segment.elementAt(track);
                if (element && element.type === Element.CHORD) active[Math.floor(track / 4)] = true;
            }
            segment = segment.next;
        }
        for (var staff = 0; staff < curScore.nstaves; staff++) {
            kinds[staff] = curScore.staves[staff].clefType(measures[song().start-1].tick) === ClefType.F ? "bass" : "treble";
        }
        var parts = [];
        for (var part = 0; part < curScore.parts.length; part++) parts.push(curScore.parts[part]);
        var routing = Review.volumeGroups(parts, kinds, active);
        volumeChannels = [[mixerSnapshot.length-1], routing.groups[1], routing.groups[2]];
        for (var channel = 0; channel < mixerSnapshot.length-1; channel++) volumeChannels.push([channel]);
        volumeChannels = volumeChannels.slice();
        volumeNotice = "Listening only — scroll for all mixer channels. Clef and channel levels combine." +
            (routing.shared ? " Shared two-clef parts use their own channel slider." : "");
        applyVolumes();
    }
    function restoreMixer() {
        // Solo updates can reload output parameters, so write all levels last.
        mixerSnapshot.slice(0,-1).forEach(function(state) {
            state.channel.solo=state.solo; state.channel.muted=state.muted;
        });
        mixerSnapshot.forEach(function(state) { state.channel.volumeLevel=state.db });
    }
    function mixerRestored() {
        return mixerSnapshot.every(function(state,index) {
            return Math.abs(state.channel.volumeLevel-state.db)<0.001 &&
                (index===mixerSnapshot.length-1 || (state.channel.solo===state.solo && state.channel.muted===state.muted));
        });
    }
    function applyVolumes() {
        if (mixerSuspended) return;
        var solos=Review.listeningSolos(volumeChannels,volumeSolos,mixerSnapshot.length-1);
        mixerSnapshot.slice(0,-1).forEach(function(state,index) {
            var selected=solos.length && solos.indexOf(index)>=0;
            state.channel.solo=solos.length ? !!selected : state.solo;
            state.channel.muted=selected ? false : state.muted;
        });
        mixerSnapshot.forEach(function(state,index) {
            state.channel.volumeLevel=Review.listeningDb(state,index,volumeChannels,volumeLevels,volumeMutes);
        });
        if (diagnosticsEnabled) {
            diagnostics.source=Review.pathFromUrl(Qt.resolvedUrl("mixer-checks.json"));
            diagnostics.write(JSON.stringify(mixerSnapshot.map(function(state) {
                return {label:state.label,before:state.db,current:state.channel.volumeLevel,muted:state.muted};
            })));
        }
    }
    function setVolume(group, percent, muted) {
        try {
            sameScore(); Review.validNumber(percent, 0, 100, "Volume");
            var levels = volumeLevels.slice(), mutes = volumeMutes.slice();
            levels[group] = percent; mutes[group] = muted;
            volumeLevels = levels; volumeMutes = mutes; applyVolumes();
            console.log("PSALMIST_REVIEW volume " + group + " " + percent + " mute=" + muted);
        } catch(error) { fail(error) }
    }
    function resetListeningMix() {
        sameScore();
        volumeLevels = volumeLabels.map(function() { return 100 });
        volumeMutes = volumeLabels.map(function() { return false });
        volumeSolos = volumeLabels.map(function() { return false }); applyVolumes();
        var piano = soundOptions.filter(function(item) { return item.id.indexOf("MS Basic") >= 0 && item.title === "Grand Piano" });
        if (piano.length) setInstrument(0, piano[0].id);
    }
    function setSolo(group, solo) {
        try {
            sameScore();
            if (busy) throw new Error("Wait for the current operation before changing Solo.");
            if (!Number.isInteger(group) || group<3 || group>=volumeSolos.length) throw new Error("Solo needs an individual channel.");
            var values=volumeSolos.slice(); values[group]=!!solo; volumeSolos=values; applyVolumes();
        } catch(error) { fail(error) }
    }
    function loadListeningLayout() {
        try {
            listeningLayouts=layoutPreferences.exists() ? JSON.parse(layoutPreferences.read()) : {};
            if (!listeningLayouts || typeof listeningLayouts!=="object" || Array.isArray(listeningLayouts)) listeningLayouts={};
        } catch(error) { listeningLayouts={}; console.log("PSALMIST_REVIEW damaged listening layout; using defaults.") }
        var layout=Review.listeningLayout(volumeLabels,listeningLayouts[book.source_sha256]);
        volumeKeys=layout.keys; volumeOrder=layout.order; hiddenVolumeRows=layout.hidden;
    }
    function saveListeningLayout() {
        listeningLayouts[book.source_sha256]={order:volumeOrder.map(function(group) { return volumeKeys[group] }),
            hidden:hiddenVolumeRows.map(function(group) { return volumeKeys[group] })};
        if (!layoutPreferences.write(JSON.stringify(listeningLayouts))) throw new Error("Could not save the listening layout on this computer.");
    }
    function moveListeningRow(group, direction) {
        try {
            sameScore();
            if (busy) return;
            var order=volumeOrder.slice(), from=order.indexOf(group), to=from+direction;
            if (from<0 || (direction!==1 && direction!==-1) || to<0 || to>=order.length) return;
            order.splice(from,1); order.splice(to,0,group); volumeOrder=order; saveListeningLayout();
        } catch(error) { fail(error) }
    }
    function showListeningRow(group, shown) {
        try {
            sameScore();
            if (busy || volumeOrder.indexOf(group)<0) return;
            var hidden=hiddenVolumeRows.filter(function(index) { return index!==group });
            if (!shown) hidden.push(group);
            hiddenVolumeRows=hidden; saveListeningLayout();
        } catch(error) { fail(error) }
    }
    function resetListeningLayout() {
        try {
            sameScore();
            if (busy) return;
            var layout=Review.listeningLayout(volumeLabels,null);
            volumeOrder=layout.order; hiddenVolumeRows=[]; saveListeningLayout();
        } catch(error) { fail(error) }
    }
    function dispatch(code) { cmd(Review.command(code, transportApi)) }
    function openSyncSettings() {
        try {
            var config=syncPreferences.exists() ? JSON.parse(syncPreferences.read()) : {};
            syncUrl.text=config.url || ""; syncKey.text=config.key || ""; syncDialog.open();
        } catch(error) { syncMessage="Sync settings could not be read. Re-enter the URL and key."; syncDialog.open() }
    }
    function saveSyncSettings() {
        try {
            var url=syncUrl.text.trim(), key=syncKey.text.trim();
            if (!/^https:\/\/script\.google\.com\/macros\/s\/[A-Za-z0-9_-]+\/exec$/.test(url)) throw new Error("Use the organiser's Apps Script URL ending in /exec.");
            if (!/^[a-zA-Z0-9-]{32,200}$/.test(key)) throw new Error("Enter the organiser's sync key.");
            var config={};
            try { config=syncPreferences.exists() ? JSON.parse(syncPreferences.read()) : {} } catch(error) {}
            if (!syncPreferences.write(JSON.stringify({url:url,key:key,device_id:config.device_id || ""}))) throw new Error("Could not save sync settings on this computer.");
            syncConfigured=true; syncMessage="Connected. Saved answers sync automatically when idle."; syncDialog.close();
        } catch(error) { syncMessage=String(error) }
    }
    function syncReviews(automatic,resolutions) {
        try {
            sameScore();
            if (busy || syncing) return;
            if (automatic && (syncAutoPaused || sharedApplyPending)) return;
            if (!automatic) syncAutoPaused=false;
            if (dirty || audition || tempoChange) { if(!automatic) syncMessage="Save your changes and stop playback before syncing.";return }
            if (!reviewer.text.trim()) throw new Error("Enter your reviewer name before syncing.");
            if (!syncPreferences.exists()) { if(!automatic) openSyncSettings(); return }
            syncIo.source=Review.pathFromUrl(Qt.resolvedUrl("watcher-heartbeat.json"));
            var heartbeat=syncIo.exists() ? JSON.parse(syncIo.read()) : null;
            if (!heartbeat || !isFinite(Number(heartbeat.updated)) || Date.now()-Number(heartbeat.updated)>15000) throw new Error("The review helper is not running. Close MuseScore and open START HERE from the updated kit, then retry. Local reviews are safe.");
            loadCsv();
            // Upload saved answers only; unsaved edits remain local.
            Review.records(csvBefore);
            var token=Date.now()+"-"+Math.floor(Math.random()*1000000000);
            var path=Review.pathFromUrl(Qt.resolvedUrl("sync-"+token+".json"));
            syncIo.source=path;
            if (!syncIo.write(JSON.stringify({token:token,csv_text:csvBefore,reviewer:reviewer.text.trim(),book_source_sha256:book.source_sha256,resolutions:resolutions || []}))) throw new Error("Could not stage sync. Local reviews are unchanged.");
            syncPending={path:path,token:token,started:Date.now()};
            syncMessage="Syncing saved answers with Google Sheets…";
        } catch(error) { syncMessage=String(error) }
    }
    function cancelSync(reason) {
        if (!syncPending) return;
        syncIo.source=syncPending.path+".cancel";
        if (!syncIo.write("cancel")) { syncMessage="Could not cancel sync. Retry Cancel sync."; return; }
        syncPending=null; syncAutoPaused=true;
        syncMessage=reason || "Sync cancelled. Local reviews are safe. An upload already received by Google may still complete; Sync now checks its result safely.";
    }
    function loadSharedReviews() {
        try {
            syncIo.source=Review.pathFromUrl(Qt.resolvedUrl("shared-v2-"+book.source_sha256+".json"));
            if (!syncIo.exists()) { sharedReviews=[]; sharedAt=""; return }
            var cache=JSON.parse(syncIo.read());
            if (cache.version!==2 || cache.book_source_sha256!==book.source_sha256 || !Array.isArray(cache.rows) || !Array.isArray(cache.conflicts)) throw new Error("Shared results do not match this book.");
            sharedReviews=cache.rows; sharedAt=cache.synced_at || ""; syncConflicts=cache.conflicts.filter(function(conflict) {return !book.section || book.songs.some(function(song) {return song.id===conflict.id;});});
            sharedApplyPending=true;
            if (!dirty && !audition && !tempoChange && !busy && !syncing) {sharedApplyPending=false;applySharedReviews();}
            else syncMessage="Shared answers downloaded. They will apply after you save your edits and stop playback.";
        } catch(error) { syncMessage=String(error) }
    }
    function resolveSyncConflict(conflict,choice) {
        syncReviews(false,[{id:conflict.id,mutation_id:conflict.mutation_id,revision:conflict.revision,choice:choice}]);
        sharedDialog.close();
    }
    function applySharedReviews() {
        sameScore();
        if(dirty || audition || tempoChange || saving || syncing) throw new Error("Shared changes are waiting. Save local edits and stop playback, then sync again.");
        var plans=[],nextDecisions=Object.assign({},decisions),nextRevisions=Object.assign({},sharedRevisions),seen={};
        sharedReviews.forEach(function(row) {
            if(seen[row.id]) throw new Error("Duplicate shared song answer.");seen[row.id]=true;
            var index=book.songs.findIndex(function(song) {return song.id===row.id;});
            if(index<0) {
                if(book.section) return; // Other sections share the original book identity.
                throw new Error("Shared song is not in this book: "+row.id);
            }
            var plan=Review.validateSharedDecision(row,book.songs[index],book.source_sha256);
            if(syncConflicts.some(function(conflict) {return conflict.id===row.id;}) || Number(sharedRevisions[row.id] || 0)===plan.revision) return;
            if(Number(sharedRevisions[row.id] || 0)>plan.revision) throw new Error("Shared server revision went backwards. Ask the organiser to check the Sheet.");
            var selected=book.songs[index],start=measures[selected.start-1].tick.ticks,tempoTargets=[],holdTargets=[],feelTargets=[];
            scanAnnotations(selected.start,selected.end,function(element,segment,mi) {
                var offset=segment.tick-start;
                if(element.type===Element.TEMPO_TEXT) {
                    var matches=plan.tempos.filter(function(t) {return t.tick_offset===offset && t.track===element.track;});
                    if(matches.length!==1) throw new Error("Shared tempo map differs at "+row.id);
                    tempoTargets.push({element:element,value:Number(matches[0].quarter_bpm)});
                }
                if(element.type===Element.FERMATA) {
                    var matches=plan.holds.filter(function(h) {return h.tick_offset===offset && h.tracks.indexOf(element.track)>=0;});
                    if(matches.length!==1) throw new Error("Shared fermata map differs at "+row.id);
                    holdTargets.push({element:element,value:Number(matches[0].percent)/100});
                }
                if(mi===selected.start-1 && element.type===Element.SYSTEM_TEXT && /^(Straight|Swing)$/.test(element.text)) feelTargets.push(element);
            });
            if(tempoTargets.length!==plan.tempos.length || holdTargets.length!==plan.holds.reduce(function(total,h) {return total+h.tracks.length;},0) || feelTargets.length!==1) throw new Error("Shared notation map differs at "+row.id);
            if(!tempoTargets.length || Math.abs(tempoTargets[0].value-Number(row.quarter_bpm))>0.001) throw new Error("Shared opening tempo differs at "+row.id);
            var template=templates[row.feel==="swing" ? "swing"+plan.ratio : "straight"];
            if(!template) throw new Error("Shared feel template missing.");
            plan.song=selected;plan.index=index;plan.tempos=tempoTargets;plan.holds=holdTargets;plan.feel=feelTargets[0];plan.replacement=template.clone();plan.headers=headerTexts(index);
            plans.push(plan);nextDecisions[row.id]=row;nextRevisions[row.id]=plan.revision;
        });
        if(!plans.length) {if(sharedUnsavedRows.length) persistSharedReviews();return;}
        stop();curScore.startCmd("Apply shared reviews");
        try {
            plans.forEach(function(plan) {
                plan.tempos.forEach(function(t) {
                    var text=t.element.text,unit=text.indexOf("metAugmentationDot")>=0 ? 1.5 : text.indexOf("metNoteHalfUp")>=0 ? 2 : 1;
                    t.element.tempoFollowText=false;t.element.tempo=t.value/60;t.element.text=text.replace(/(=\s*)[0-9.]+/,"$1"+(Math.round(t.value/unit*100)/100));
                });
                plan.holds.forEach(function(h) {h.element.timeStretch=h.value;});
                var replacement=plan.replacement;replacement.text=plan.row.feel==="swing" ? "Swing" : "Straight";
                replacement.visible=plan.feel.visible;replacement.autoplace=plan.feel.autoplace;replacement.offset=plan.feel.offset;replacement.z=plan.feel.z;
                var cursor=curScore.newCursor();cursor.track=plan.feel.track;cursor.rewindToTick(measures[plan.song.start-1].tick.ticks);
                removeElement(plan.feel);cursor.add(replacement);
                plan.headers.forEach(function(h) {h.element.text=h.element.text.replace(/(Tempo:[\s\S]*?=\s*)[0-9.]+(\s*BPM)/,"$1"+plan.bpm+"$2").replace(/(Straight|Swing)(?=(?:<\/[^>]+>)*\s*$)/,replacement.text);});
            });
            curScore.setMetaTag("psalmist-review-decisions",JSON.stringify(nextDecisions));
            curScore.setMetaTag("psalmist-shared-revisions",JSON.stringify(nextRevisions));
            curScore.endCmd();
        } catch(error) {curScore.endCmd(true);throw error;}
        decisions=nextDecisions;sharedRevisions=nextRevisions;
        loadSong(songIndex);
        sharedUnsavedRows=plans.map(function(plan) {return plan.row;});
        persistSharedReviews();
    }
    function persistSharedReviews() {
        var token=Date.now()+"-"+Math.floor(Math.random()*1000000000),path=Review.pathFromUrl(Qt.resolvedUrl("save-"+token+".json"));
        pending={token:token,path:path,started:Date.now(),shared:true,csvAfter:csvBefore};
        io.source=path;
        if(!io.write(JSON.stringify({mode:"shared",token:token,score_path:scorePath,decisions:sharedUnsavedRows}))) throw new Error("Shared answers applied in memory, but could not stage score save. Retry Save score + CSV before closing.");
        curScore.setMetaTag("psalmist-playback-save-token",token);
        saving=true;mixerSuspended=true;mixerStableSince=0;restoreMixer();restoreInstruments();volumeSaveDelay.start();
        message="Saving shared answers to your local score…";
    }
    Timer {
        interval:500;repeat:true;running:root.ready && root.sharedApplyPending
        onTriggered:if(!root.dirty && !root.audition && !root.tempoChange && !root.busy && !root.syncing) {
            root.sharedApplyPending=false;
            try {root.applySharedReviews();} catch(error) {root.syncMessage=String(error);}
        }
    }
    Timer {
        interval:60000;repeat:true;triggeredOnStart:true;running:root.ready && root.syncConfigured
        onTriggered:if(!root.syncConflicts.length && reviewer.text.trim()) root.syncReviews(true)
    }
    Timer {
        interval:500; repeat:true; running:root.syncing
        onTriggered: {
            try {
                syncIo.source=root.syncPending.path+".result.json";
                if (!syncIo.exists()) {
                    if (Date.now()-root.syncPending.started>75000) {root.cancelSync("Sync timed out and was cancelled. Check your internet and deployment settings, then use Sync now to retry. Local reviews are safe.");return;}
                    return;
                }
                var result=JSON.parse(syncIo.read());
                if (result.token!==root.syncPending.token || !result.ok) throw new Error(result.error || "Sync response did not match this request.");
                root.syncMessage="Synced: "+result.uploaded+" updated; "+result.count+" shared songs."+(result.conflicts ? " Resolve "+result.conflicts+" overlapping edit(s). Your local answers are preserved in your CSV." : "");
                if(result.conflicts) {root.message=root.syncMessage;syncSection.expanded=true;}
                root.syncPending=null; root.loadSharedReviews();
            } catch(error) { root.syncPending=null; root.syncMessage=String(error) }
        }
    }
    function fail(error) { message = String(error); console.log("PSALMIST_REVIEW " + message) }
    function sameScore() {
        if (!curScore || !ownedScore || !curScore.is(ownedScore)) throw new Error("Reopen the panel for the active review book.");
    }
    function song() { return book.songs[songIndex] }
    function showSongSelection() {
        songBox.currentIndex=songIndex;
        songBox.editText=songs.get(songIndex).label;
    }
    function goToSong() {
        if(!ready || busy || tempoChange) return;
        var index=Review.songMatch(book.songs,songBox.editText);
        if(index>=0) navigate(index);
        else fail("Enter a song ID or a unique part of its title from this section.");
    }
    function headerTexts(index) {
        var selected=index===undefined ? song() : book.songs[index];
        var result = [], frame = measures[selected.start-1].prev;
        while (frame && frame.type !== Element.MEASURE) {
            for (var i = 0; i < frame.elements.length; ++i) {
                var e = frame.elements[i];
                if (typeof e.text === "string" && e.text.indexOf("Tempo:") >= 0) result.push({element:e, text:e.text});
            }
            frame = frame.prev;
        }
        return result;
    }
    function scanAnnotations(start, end, callback) {
        for (var mi = start - 1; mi < end; ++mi) {
            var segment = measures[mi].firstSegment;
            var limit = measures[mi].tick.ticks + measures[mi].ticks.ticks;
            while (segment && segment.tick < limit) {
                for (var ai = 0; ai < segment.annotations.length; ++ai) callback(segment.annotations[ai], segment, mi);
                segment = segment.next;
            }
        }
    }
    function loadSong(index) {
        feelUpdate.stop();
        stop(); sameScore(); songIndex = index; loopPasses = 0;
        tempoElement = null; tempos = []; feelElement = null; fermatas = []; holds.clear();
        var tempoCount = 0, feelCount = 0, groups = {};
        scanAnnotations(song().start, song().end, function(element, segment, mi) {
            if (element.type === Element.TEMPO_TEXT) {
                tempos.push({element:element, bar:mi-song().start+2, tick_offset:segment.tick-measures[song().start-1].tick.ticks});
                if (mi === song().start - 1) { if (!tempoElement) tempoElement = element; ++tempoCount }
            }
            if (mi === song().start - 1 && element.type === Element.SYSTEM_TEXT && /^(Straight|Swing)$/.test(element.text)) { feelElement = element; ++feelCount }
            if (element.type === Element.FERMATA) {
                var key = String(segment.tick);
                if (!groups[key]) groups[key] = { tick: segment.tick, bar: mi - song().start + 2, elements: [] };
                groups[key].elements.push(element);
            }
        });
        if (!tempoCount || feelCount !== 1) throw new Error("Expected tempo and unique feel controls at " + song().id + "'s start.");
        baseQuarterBpm = Number(tempoElement.tempo) * 60;
        captureBaseline();
        appliedFeel = feelElement.text === "Swing" ? "swing" : "straight";
        var stored = decisions[song().id] || {};
        appliedSwingRatio = stored.swing_ratio !== undefined ? Number(stored.swing_ratio) : (song().native_swing_ratio !== undefined ? song().native_swing_ratio : 60);
        swingRatio = stored.swing_ratio !== undefined ? Number(stored.swing_ratio) : 67;
        bpm = Math.round(baseQuarterBpm / song().beat_factor * 100) / 100;
        feel = feelElement.text === "Swing" ? "swing" : "straight";
        Object.keys(groups).sort(function(a,b) { return Number(a)-Number(b) }).forEach(function(key) {
            var g = groups[key], percent = Math.round(g.elements[0].timeStretch * 100);
            g.percent = percent; g.original = g.elements.map(function(e) { return Number(e.timeStretch) });
            fermatas.push(g); holds.append({ bar: g.bar, percent: percent });
        });
        tempoBox.text = String(bpm); tempoSlider.value = bpm; feelBox.currentIndex = feel === "swing" ? 1 : 0;
        showSongSelection(); dirty = false;
        updateVolumeGroups();
        loadCsv();
        var csvDecision = Review.savedDecision(csvBefore, song().id, book.source_sha256);
        var confirmed = !!csvDecision.id;
        loadAnswers(stored.grace_notes_missing !== undefined ? stored : csvDecision);
        message = sharedRevisions[song().id] ? "Shared review by "+stored.reviewer+" · revision "+sharedRevisions[song().id]+". Edit and Save to update it." : confirmed ? "Previously saved — values loaded from this score." : "Ready — this song has not been confirmed.";
        curScore.showElementInScore(tempoElement);
        console.log("PSALMIST_REVIEW loaded " + song().id + " bpm=" + bpm + " feel=" + feel + " fermatas=" + fermatas.length);
    }
    function captureBaseline() {
        var swing=curScore.staves[Math.floor(feelElement.track/4)].swing(measures[song().start-1].tick);
        // Keep plain values: plugin-owned clones can outlive a closed score in 4.7.5.
        reviewBaseline = {tempo:Number(tempoElement.tempo),feel:{template:feelElement.text==="Swing" ? "swing"+Math.round(swing.swingRatio) : "straight",
            text:feelElement.text,visible:feelElement.visible,autoplace:feelElement.autoplace,x:feelElement.offsetX,y:feelElement.offsetY,z:feelElement.z},headers:headerTexts()};
        tempos.forEach(function(t) { t.original = Number(t.element.tempo); t.text = t.element.text; t.follow = t.element.tempoFollowText });
    }
    function loadCsv() {
        if (!reviewer.text.trim()) { csvBefore = ""; csvPath = ""; return }
        csvPath = scorePath.replace(/[^/\\]+$/, "") + Review.reviewerFile(reviewer.text);
        io.source = csvPath; csvBefore = io.exists() ? io.read() : "";
        Review.records(csvBefore);
    }
    function loadAnswers(answer) {
        graceBox.currentIndex = answer.grace_notes_missing === "yes" ? 1 : 0;
        issuesBox.currentIndex = answer.score_has_issues === "yes" ? 1 : 0;
        issueNotes.text = answer.issue_notes || "";
    }
    function reviewEdited() { dirty = true; message = "Unconfirmed changes — press Save to confirm." }
    function setSwing(value) {
        try {
            sameScore(); swingRatio = Review.validNumber(value, 0, 100, "Swing ratio");
            dirty = true; message = "Auditioning — press Save to confirm.";
            // Coalesce queued percentage edits before the native whole-book rebuild.
            if (feel === "swing") feelUpdate.restart();
        } catch(error) { fail(error) }
    }
    Timer {
        id: feelUpdate; interval: 40
        onTriggered: { try { root.applyFeel(root.feel === "swing" ? 1 : 0) } catch(error) { root.fail(error) } }
    }
    function setTempo(value) {
        try {
            sameScore(); bpm = Review.validNumber(value, 20, 300, "Tempo");
            tempoBox.text = String(bpm); tempoSlider.value = bpm;
            tempoUpdate.restart();
            dirty = true; message = "Auditioning — press Save to confirm.";
            console.log("PSALMIST_REVIEW tempo " + bpm + " liveMultiplier=" + transport.tempoMultiplier);
        } catch(error) { fail(error) }
    }
    function changeLiveTempo() {
        sameScore();
        if (tempoChange) return;
        if (Math.abs(bpm * song().beat_factor - baseQuarterBpm) < 0.000001) return;
        if (!audition) { applyTempo(); return }
        tempoChange = { ratio:baseQuarterBpm/(bpm*song().beat_factor), bpm:bpm, applied:false, resume:!paused,
                        beforeBar:transport.measureNumber, beforeBeat:transport.beatNumber,
                        ready:false, started:Date.now(), seeked:false,
                        beforeDuration:Review.seconds(Qt.formatTime(transport.maxPlayTime,"hh:mm:ss.zzz")) };
        // Only this setting's native markings change. Earlier songs keep their timing.
        // Rescale elapsed time within this setting, preserving the current position.
        if (Review.playingIcon(transport.items) === IconCode.PAUSE) dispatch("pause");
    }
    Timer {
        id: tempoUpdate; interval: 25
        onTriggered: { try { root.changeLiveTempo() } catch(error) { root.fail(error) } }
    }
    Connections {
        target: transport
        function onMaxPlayTimeChanged() { if (root.tempoChange) root.tempoChange.ready = true }
        function onPlayPositionChanged() {
            if (root.startPositionPending && root.afterStop === "starting") {
                root.songStartSeconds = Review.seconds(Qt.formatTime(transport.playTime,"hh:mm:ss.zzz"));
                root.startPositionPending = false;
            }
        }
    }
    Timer {
        interval: 10; repeat: true; running: root.tempoChange !== null
        onTriggered: {
            var change = root.tempoChange;
            if (!change.applied && Review.playingIcon(transport.items) !== IconCode.PAUSE) {
                change.beforeBar = transport.measureNumber; change.beforeBeat = transport.beatNumber;
                change.beforeTime = Qt.formatTime(transport.playTime,"hh:mm:ss.zzz");
                change.targetSeconds = root.songStartSeconds + (Review.seconds(change.beforeTime)-root.songStartSeconds)*change.ratio;
                change.applied = true;
                root.applyTempo(change.bpm);
            } else if (!change.seeked && (change.ready || (transport.isPlayAllowed && Review.seconds(Qt.formatTime(transport.maxPlayTime,"hh:mm:ss.zzz")) !== change.beforeDuration))) {
                change.targetPosition = change.targetSeconds / Review.seconds(Qt.formatTime(transport.maxPlayTime,"hh:mm:ss.zzz"));
                transport.playPosition = change.targetPosition;
                change.seeked = true;
            } else if (change.seeked && transport.isPlayAllowed && Math.abs(transport.playPosition-change.targetPosition) * Review.seconds(Qt.formatTime(transport.maxPlayTime,"hh:mm:ss.zzz")) < 0.02) {
                if (root.diagnosticsEnabled) {
                    root.tempoChecks.push({beforeBar:change.beforeBar,beforeBeat:change.beforeBeat,
                        afterBar:transport.measureNumber,afterBeat:transport.beatNumber,
                        beforeTime:change.beforeTime,afterTime:Qt.formatTime(transport.playTime,"hh:mm:ss.zzz"),
                        ratio:change.ratio,bpm:change.bpm,native:true,songStartSeconds:root.songStartSeconds,wait_ms:Date.now()-change.started});
                    diagnostics.source = Review.pathFromUrl(Qt.resolvedUrl("tempo-checks.json"));
                    diagnostics.write(JSON.stringify(root.tempoChecks.slice(-30)));
                }
                console.log("PSALMIST_REVIEW tempo-position " + change.beforeBar + "." + change.beforeBeat + " -> " + transport.measureNumber + "." + transport.beatNumber);
                if (change.resume && root.audition && !root.paused) {
                    root.seenPlaying = false;
                    afterStop="resume"; stopDeadline=Date.now()+30000; playbackRetries=0;
                }
                root.tempoChange = null;
                if (root.audition) tempoUpdate.restart();
            } else if (Date.now()-change.started > 8000) {
                var resume=change.resume && root.audition && !root.paused;
                root.stop();
                if (resume) { root.play(); root.message="Recovering tempo timing from the song start… Stop cancels." }
                else root.message="Tempo updated. Press Play to start the song with the new timing.";
            }
        }
    }
    function applyTempo(value) {
        sameScore();
        var selectedBpm = value === undefined ? bpm : value;
        if (Math.abs(selectedBpm * song().beat_factor - baseQuarterBpm) < 0.000001) return;
        curScore.startCmd("Review tempo");
        var ratio = selectedBpm * song().beat_factor / (reviewBaseline.tempo * 60);
        tempos.forEach(function(t) {
            t.element.tempoFollowText = false;
            t.element.tempo = t.original * ratio;
            var unit = t.text.indexOf("metAugmentationDot") >= 0 ? 1.5 : t.text.indexOf("metNoteHalfUp") >= 0 ? 2 : 1;
            t.element.text = t.text.replace(/(=\s*)[0-9.]+/, "$1" + (Math.round(t.element.tempo*60/unit*100)/100));
        });
        tempoElement.text = "<sym>" + song().beat_symbol + "</sym>" + (song().beat_unit === "dotted_quarter" ? "<sym>metAugmentationDot</sym>" : "") + " = " + selectedBpm;
        // Keep the existing display-only metadata header consistent with playback.
        reviewBaseline.headers.forEach(function(h) { h.element.text = h.element.text.replace(/(Tempo:[\s\S]*?=\s*)[0-9.]+(\s*BPM)/, "$1" + selectedBpm + "$2") });
        curScore.endCmd(); baseQuarterBpm = selectedBpm * song().beat_factor;
    }
    function setFeel(index) {
        try {
            // Feel changes shift offbeats, not the score's tempo timeline. Let
            // MuseScore update its events while audio continues instead of pausing.
            sameScore();
            applyFeel(index);
            dirty = true; message = "Auditioning — press Save to confirm.";
        } catch(error) { fail(error) }
    }
    function applyFeel(index) {
            sameScore();
            feelUpdate.stop();
            var desiredFeel = index === 1 ? "swing" : "straight";
            if (appliedFeel === desiredFeel && (index !== 1 || appliedSwingRatio === swingRatio)) { feel = desiredFeel; return }
            var template = templates[index === 1 ? "swing" + swingRatio : "straight"];
            if (!template) throw new Error("Native feel template missing; prepare a fresh review copy.");
            var started = Date.now(), beforeBar = transport.measureNumber, beforeBeat = transport.beatNumber;
            var replacement = template.clone(); replacement.text = index === 1 ? "Swing" : "Straight";
            replacement.visible = feelElement.visible; replacement.autoplace = feelElement.autoplace;
            replacement.offset = feelElement.offset; replacement.z = feelElement.z;
            var cursor = curScore.newCursor(); cursor.track = feelElement.track; cursor.rewindToTick(measures[song().start-1].tick.ticks);
            curScore.startCmd("Review playback feel");
            removeElement(feelElement); cursor.add(replacement); feelElement = replacement;
            reviewBaseline.headers.forEach(function(h) { h.element.text = h.element.text.replace(/(Straight|Swing)(?=(?:<\/[^>]+>)*\s*$)/, index === 1 ? "Swing" : "Straight") });
            var prepared = Date.now();
            curScore.endCmd(); feel = desiredFeel; appliedFeel = desiredFeel; appliedSwingRatio = swingRatio;
            if (diagnosticsEnabled) {
                feelChecks.push({song:song().id,feel:desiredFeel,ratio:swingRatio,beforeBar:beforeBar,beforeBeat:beforeBeat,
                    afterBar:transport.measureNumber,afterBeat:transport.beatNumber,playing:audition && !paused,
                    prepare_ms:prepared-started,commit_ms:Date.now()-prepared,total_ms:Date.now()-started});
                diagnostics.source = Review.pathFromUrl(Qt.resolvedUrl("feel-checks.json"));
                diagnostics.write(JSON.stringify(feelChecks.slice(-30)));
            }
    }
    function setHold(index, value) {
        try {
            if (!ready || busy || tempoChange) return;
            sameScore(); var percent = Review.validNumber(value, 100, 1000, "Fermata percent");
            if (index !== -1 && (!Number.isInteger(index) || !fermatas[index])) throw new Error("Select a fermata in this song.");
            var targets = index === -1 ? fermatas : [fermatas[index]];
            if (!targets.length) { message="No fermatas in this song."; return; }
            var resume = audition && !paused; pause(); curScore.startCmd("Review fermata");
            try { targets.forEach(function(g) { g.elements.forEach(function(e) { e.timeStretch = percent / 100 }); }); }
            finally { curScore.endCmd(); }
            targets.forEach(function(g,i) { g.percent=percent; holds.setProperty(index === -1 ? i : index,"percent",percent); });
            dirty = true; message = "Auditioning — press Save to confirm.";
            if (resume) play();
        } catch(error) { fail(error) }
    }
    function finishAudition() {
        if (loopSong && ready && !saving) {
            loopPasses++; console.log("PSALMIST_REVIEW loop " + song().id + " pass=" + loopPasses);
            stop(); play();
        } else { stop(); message = "Song finished." }
    }
    function seekBar(delta) {
        try {
            sameScore();
            transport.measureNumber = Math.max(song().start, Math.min(song().end, transport.measureNumber + delta));
        } catch(error) { fail(error) }
    }
    function pause() {
        if (audition && !paused) { dispatch("pause"); paused = true }
    }
    function stop() {
        afterStop = ""; startPositionPending = false; stopRequested=true; stopReadyAt = Date.now()+80;
        tempoUpdate.stop(); tempoChange = null;
        audition = false; paused = false;
        if (curScore && ownedScore && curScore.is(ownedScore)) dispatch("stop");
    }
    function play(stopped) {
        try {
            sameScore();
            if (audition && !paused) { pause(); return }
            if (paused) {
                playbackRetries=0;
                if (tempoChange) { paused = false; tempoChange.resume = true }
                else { afterStop = "resume"; stopDeadline = Date.now()+30000 }
                return;
            }
            if (!stopped) { stop(); playbackRetries=0; afterStop = "play"; stopDeadline = Date.now()+30000; message = "Preparing playback… Stop cancels."; return }
            applyFeel(feel === "swing" ? 1 : 0); applyTempo();
            if (Math.abs(transport.tempoMultiplier - 1) > 0.000001) transport.tempoMultiplier = 1;
            if (Review.playbackChecked(transport.items, "repeat", transportApi) === true) dispatch("repeat");
            if (Review.playbackChecked(transport.items, "loop", transportApi) === true) dispatch("loop");
            afterStop = "start"; stopDeadline = Date.now()+30000;
            message = "Preparing song audio… Stop cancels.";
        } catch(error) { fail(error) }
    }
    function navigate(index) {
        if (!ready || busy || tempoChange || !Number.isInteger(index) || index < 0 || index >= songs.count || unsaved.visible) return;
        if (index === songIndex) { showSongSelection(); return }
        if (dirty) { pendingNavigation = index; unsaved.open() }
        else { try { loadSong(index) } catch(error) { fail(error) } }
    }
    function discard() {
        feelUpdate.stop();
        stop(); sameScore(); curScore.startCmd("Discard playback audition");
        tempos.forEach(function(t) { t.element.tempoFollowText = false; t.element.text = t.text; t.element.tempo = t.original; t.element.tempoFollowText = t.follow });
        reviewBaseline.headers.forEach(function(h) { h.element.text = h.text });
        var cursor = curScore.newCursor(); cursor.track = feelElement.track; cursor.rewindToTick(measures[song().start-1].tick.ticks);
        var savedFeel=reviewBaseline.feel,replacement=templates[savedFeel.template].clone();
        replacement.text=savedFeel.text;replacement.visible=savedFeel.visible;replacement.autoplace=savedFeel.autoplace;
        replacement.offsetX=savedFeel.x;replacement.offsetY=savedFeel.y;replacement.z=savedFeel.z;
        removeElement(feelElement);cursor.add(replacement);
        fermatas.forEach(function(g) { g.elements.forEach(function(e,i) { e.timeStretch = g.original[i] }) });
        curScore.endCmd(); dirty = false;
        var next = pendingNavigation; pendingNavigation = -1;
        if (pendingClose) { pendingClose = false; reviewWindow.close() }
        else if (pendingBook) beginBookSwitch();
        else loadSong(next);
    }
    function save(stopped) {
        try {
            sameScore(); if (saving) return;
            // A newer local save must sync before an older downloaded answer can be applied.
            if(syncing) {cancelSync("Saving locally. Shared answers will be checked again after saving.");if(syncing) return;syncAutoPaused=false;}
            sharedApplyPending=false;
            if(sharedUnsavedRows.length) {persistSharedReviews();return;}
            if (!soundsReady()) throw new Error("Wait for instruments to finish loading before saving.");
            if (!reviewer.text.trim() || /^[=+@-]/.test(reviewer.text.trim())) throw new Error("Enter your reviewer name using a letter or number first.");
            if (Number(tempoBox.text) !== bpm) setTempo(tempoBox.text);
            if (!stopped) { stop(); afterStop = "save"; stopDeadline = Date.now()+30000; message = "Preparing score save…"; return }
            stop(); applyFeel(feel === "swing" ? 1 : 0); applyTempo(); loadCsv(); preferences.write(JSON.stringify({reviewer:reviewer.text.trim()}));
            var values = fermatas.map(function(g) {
                var percent = g.percent;
                g.elements.forEach(function(e) { if (Math.abs(e.timeStretch * 100 - percent) > 0.01) throw new Error("Fermatas at bar " + g.bar + " have different values. Set that hold before saving.") });
                return { bar:g.bar, tick_offset:g.tick-measures[song().start-1].tick.ticks, tracks:g.elements.map(function(e) { return e.track }), percent:percent };
            });
            var decision = { id:song().id, title:song().title, reviewer:reviewer.text.trim(), bpm:bpm, beat_unit:song().beat_unit, quarter_bpm:bpm*song().beat_factor, feel:feel, swing_ratio:swingRatio, grace_notes_missing:graceBox.currentIndex === 1 ? "yes" : "no", score_has_issues:issuesBox.currentIndex === 1 ? "yes" : "no", issue_notes:issueNotes.text, fermatas_json:JSON.stringify(values), status:"confirmed", reviewed_at:new Date().toISOString(), book_source_sha256:book.source_sha256 };
            decision.tempos_json = JSON.stringify(tempos.map(function(t) { return {bar:t.bar, tick_offset:t.tick_offset, track:t.element.track, quarter_bpm:Number(t.element.tempo)*60} }));
            decision.sync_base_revision=Number(sharedRevisions[song().id] || 0);
            var token = Date.now() + "-" + Math.floor(Math.random()*1000000000);
            var path = Review.pathFromUrl(Qt.resolvedUrl("save-" + token + ".json"));
            pending = { token:token, path:path, csvAfter:Review.csvText(csvBefore, decision), started:Date.now() };
            io.source = path;
            if (!io.write(JSON.stringify({ token:token, score_path:scorePath, csv_name:Review.reviewerFile(reviewer.text), decision:decision, csv_before:csvBefore, csv_after:pending.csvAfter }))) throw new Error("Cannot stage the review decision.");
            decisions[song().id] = decision;
            curScore.setMetaTag("psalmist-review-decisions", JSON.stringify(decisions));
            curScore.setMetaTag("psalmist-playback-save-token", token);
            saving = true; message = "Saving score, then verifying and saving CSV…";
            mixerSuspended = true; mixerStableSince=0; restoreMixer(); restoreInstruments();
            volumeSaveDelay.start();
        } catch(error) {
            saving = false; pendingBook=null;
            if (mixerSuspended) { mixerSuspended = false; applyVolumes(); applyInstruments() }
            fail(error);
        }
    }
    Timer {
        id: volumeSaveDelay; interval: 250; repeat:true
        // Audio output settings are acknowledged asynchronously by the native mixer.
        onTriggered: {
            if (!root.ready || !curScore || !curScore.is(root.ownedScore)) { stop(); return }
            if (Date.now()-root.pending.started>30000) {
                stop();root.pendingBook=null;root.saving=false;root.mixerSuspended=false;root.applyVolumes();root.applyInstruments();
                root.fail("Listening mix restoration timed out. The score was not saved; retry Save.");return;
            }
            if (!root.mixerRestored()) { root.mixerStableSince=0;root.restoreMixer();return }
            if (!root.mixerSnapshot.slice(0,-1).every(function(state) { return state.currentSound===state.originalSound })) { root.mixerStableSince=0;return }
            if (!root.mixerStableSince) { root.mixerStableSince=Date.now();return }
            if (Date.now()-root.mixerStableSince<250) return;
            stop(); root.dispatch("file-save");
        }
    }
    function pollTransport() {
        if (!afterStop) return;
        try {
            sameScore();
            var action=afterStop, playing=Review.playingIcon(transport.items) === IconCode.PAUSE;
            if ((action === "starting" || action === "resuming") && playing) {
                afterStop=""; startPositionPending=false;
                audition=true; paused=false; seenPlaying=true;
                message="Playing once — tempo slider is live.";
                return;
            }
            if (Date.now() > stopDeadline) {
                if ((action === "starting" || action === "resuming") && playbackRetries<1) {
                    playbackRetries++;
                    if (action === "starting") { stop(); afterStop="play" }
                    else afterStop="resume";
                    stopDeadline=Date.now()+30000;
                    message="Retrying playback… Stop cancels.";
                } else {
                    stop();
                    fail("Audio did not become ready. Press Play to retry; the panel can stay open.");
                }
                return;
            }
            if (action === "starting" || action === "resuming" || playing || !transport.isPlayAllowed || Date.now()<stopReadyAt) return;
            if ((action === "play" || action === "start" || action === "resume") && !soundsReady()) return;
            afterStop="";
            if (action === "start") {
                // Native selection uses the exact score tick, avoiding rounded bar/beat seeks.
                curScore.selection.clear(); curScore.selection.select(tempoElement);
                songStartSeconds=0; startPositionPending=song().start!==1;
                afterStop="starting"; stopDeadline=Date.now()+8000;
                stopRequested=false; dispatch("play-from-selection");
            } else if (action === "play") play(true);
            else if (action === "resume") {
                afterStop="resuming"; stopDeadline=Date.now()+8000; stopRequested=false; dispatch("play");
            } else if (action === "export") exportAudio(exportMode,true);
            else if (action === "save") save(true);
        } catch(error) { stop(); fail(error) }
    }
    Timer {
        interval:100; repeat:true; running:root.ready && root.stopRequested
        // Native prepareToPlay can resolve after Stop; drain that late start too.
        onTriggered: {
            if (curScore && root.ownedScore && curScore.is(root.ownedScore) && Review.playingIcon(transport.items) === IconCode.PAUSE) root.dispatch("stop");
        }
    }
    Timer {
        interval:25; repeat:true; running:root.afterStop !== ""
        onTriggered: root.pollTransport()
    }
    Timer {
        interval: 200; repeat: true; running: root.saving
        onTriggered: {
            io.source = root.pending.path + ".result.json";
            if (io.exists()) {
                try {
                    var result = JSON.parse(io.read()); root.saving = false;
                    root.mixerSuspended = false; root.applyVolumes(); root.applyInstruments();
                    if (!result.ok || result.token !== root.pending.token) throw new Error(result.error || "Save result did not match this request.");
                    root.dirty = false; if(!root.pending.shared) root.csvBefore = root.pending.csvAfter;
                    if(root.pending.shared) root.sharedUnsavedRows=[];
                    if (root.ready) {
                        root.captureBaseline();
                        root.fermatas.forEach(function(g) { g.original = g.elements.map(function(e) { return Number(e.timeStretch) }) });
                    }
                    root.message = root.pending.shared ? "Shared answers saved to this score."+(root.syncConflicts.length ? " Resolve "+root.syncConflicts.length+" overlapping edit(s) under Google Sheets sync." : "") : "Saved score + " + result.csv_path;
                    console.log("PSALMIST_REVIEW saved " + root.song().id + " " + result.csv_path);
                    // Completed requests may be removed; failed requests remain for retry/recovery.
                    io.source=root.pending.path; io.remove(); io.source=root.pending.path+".result.json"; io.remove();
                    if (root.pendingClose) { root.pendingClose = false; reviewWindow.close() }
                    else if (root.pendingBook) root.beginBookSwitch();
                    else if (root.ready && root.pendingNavigation >= 0) { var next = root.pendingNavigation; root.pendingNavigation = -1; root.loadSong(next) }
                    else if(!root.pending.shared && root.syncConfigured) Qt.callLater(function() {root.syncReviews(true)});
                } catch(error) { root.pendingBook=null; root.fail(error) }
            } else if (Date.now() - root.pending.started > 180000) { root.pendingBook=null; root.saving = false; root.mixerSuspended = false; root.applyVolumes(); root.applyInstruments(); root.fail("Save verification timed out. The score may be saved; the pending request is retained. Retry Save.") }
        }
    }
    Timer {
        interval: 50; repeat: true; running: root.audition && !root.paused && !root.tempoChange
        onTriggered: {
            // shortcut: bar polling may enter the next song for up to 50 ms;
            // a dedicated playback range API is needed for sample-exact cuts.
            if (root.audition && !root.paused && transport.measureNumber > root.song().end) root.finishAudition();
            else if (Review.playingIcon(transport.items) === IconCode.PAUSE) root.seenPlaying = true;
            else if (root.seenPlaying) root.finishAudition();
        }
    }
    Timer {
        interval: 2000; repeat: true; running: root.diagnosticsEnabled && root.audition
        onTriggered: {
            root.playbackChecks.push({song:root.song().id,at:Date.now(),bar:transport.measureNumber,beat:transport.beatNumber,time:Qt.formatTime(transport.playTime,"hh:mm:ss.zzz"),paused:root.paused,loop:root.loopSong,passes:root.loopPasses});
            diagnostics.source = Review.pathFromUrl(Qt.resolvedUrl("playback-checks.json"));
            diagnostics.write(JSON.stringify(root.playbackChecks.slice(-40)));
        }
    }
    // Some 5.x extension hosts create the form without emitting the legacy run signal.
    // Defer until the host has supplied the API context; both entry points run once.
    Component.onCompleted: Qt.callLater(root.initialize)
    onRun: initialize()
    function initialize() {
        if (initialized) return;
        initialized = true;
        try {
            if (!(mscoreMajorVersion === 4 && mscoreMinorVersion === 7) && mscoreMajorVersion !== 5) throw new Error("Use MuseScore Studio 4.7.x or 5.x on Windows.");
            transport.load();
            try { reviewer.text=preferences.exists() ? JSON.parse(preferences.read()).reviewer || "" : "" }
            catch(error) { reviewer.text="" }
            loadBook();
        } catch(error) { ready=false; fail(error) }
    }
    function loadBook(path) {
            if (!curScore || !curScore.metaTag("psalmist-playback-review")) throw new Error("Open a prepared review book from the package's books folder first.");
            ownedScore = curScore; book = JSON.parse(curScore.metaTag("psalmist-playback-review"));
            var answers = curScore.metaTag("psalmist-review-decisions"); decisions = answers ? JSON.parse(answers) : {};
            var revisions=curScore.metaTag("psalmist-shared-revisions");sharedRevisions=revisions ? JSON.parse(revisions) : {};
            syncConfigured=syncPreferences.exists();
            sharedReviews=Object.keys(sharedRevisions).filter(function(id){return decisions[id] && decisions[id].status==="confirmed";}).map(function(id){return decisions[id];});
            if(syncConfigured) {
                syncMessage="Connected to shared reviews. Sync runs automatically when idle; local shared answers remain available offline.";
                try {
                    syncIo.source=Review.pathFromUrl(Qt.resolvedUrl("shared-v2-"+book.source_sha256+".json"));
                    var cache=syncIo.exists() ? JSON.parse(syncIo.read()) : null;
                    if(cache && cache.version===2 && cache.book_source_sha256===book.source_sha256 && Array.isArray(cache.conflicts)) {syncConflicts=cache.conflicts.filter(function(conflict) {return !book.section || book.songs.some(function(song) {return song.id===conflict.id;});});sharedAt=cache.synced_at || "";}
                } catch(error) {syncMessage="Shared cache could not be read. Local score answers are intact; retry Sync now.";}
            }
            if (mscoreMajorVersion < 5 && book.score_format === "5.00") throw new Error("This book uses MuseScore 5 notation. Open it with MuseScore 5; do not force-convert it in 4.7.5.");
            if (book.version !== 1 || book.measures !== curScore.nmeasures) throw new Error("Review map no longer matches this score. Prepare a new copy.");
            if (!path) projectInfo.load(); scorePath = path || projectInfo.filePath;
            if (!/\.mscz$/i.test(scorePath)) throw new Error("Open the prepared .mscz review book.");
            savedMultiplier = transport.tempoMultiplier;
            diagnostics.source = Review.pathFromUrl(Qt.resolvedUrl("enable-checks.txt")); diagnosticsEnabled = diagnostics.exists();
            savedRepeat = Review.playbackChecked(transport.items, "repeat", transportApi) === true;
            savedLoop = Review.playbackChecked(transport.items, "loop", transportApi) === true;
            savedMetronome = Review.playbackChecked(transport.items, "metronome", transportApi) === true;
            var m = curScore.firstMeasure; while(m) { measures.push(m); m = m.nextMeasure }
            scanAnnotations(1, 1, function(e) {
                if (e.type === Element.SYSTEM_TEXT && e.text === "" && e.z === 9001) templates.straight = e;
                if (e.type === Element.SYSTEM_TEXT && e.text === "" && e.z >= 9100 && e.z <= 9200) templates["swing" + (e.z-9100)] = e;
            });
            if (book.swing_ratio !== 100) throw new Error("Upgrade this review book with UpgradeReviewBooks.cmd, or open a prepared book from the package.");
            if (!templates.straight || !templates.swing0 || !templates.swing100) throw new Error("Adjustable swing templates missing. Open a v0.4 prepared review copy.");
            book.songs.forEach(function(s) { songs.append({ label:s.id + " — " + s.title }) });
            var last=curScore.metaTag("psalmist-review-last-song"), index=book.songs.findIndex(function(s){return s.id===last;});
            ready = true; loadSong(index>=0 ? index : 0); loadBookCatalog(); bookSyncAfterLoad=true;
    }
    function restoreTransport() {
            if ((Review.playbackChecked(transport.items, "metronome", transportApi) === true) !== savedMetronome) dispatch("metronome");
            if ((Review.playbackChecked(transport.items, "repeat", transportApi) === true) !== savedRepeat) dispatch("repeat");
            if ((Review.playbackChecked(transport.items, "loop", transportApi) === true) !== savedLoop) dispatch("loop");
            // Never reset speed while a stop is still pending: the native setter can resume audio.
            if (Review.playingIcon(transport.items) !== IconCode.PAUSE) transport.tempoMultiplier = savedMultiplier;
    }
    function closeReview() {
        cancelExport();
        feelUpdate.stop();
        cancelSync();
        if (ready && curScore && ownedScore && curScore.is(ownedScore)) {
            stop(); restoreMixer(); restoreInstruments();
            restoreTransport();
            ready = false;
        }
    }
    Component.onDestruction: closeReview()
    Window {
        id: reviewWindow
        transientParent: null
        width:400; height:600
        minimumWidth:360; minimumHeight:240
        property bool placed:false
        readonly property var displayBounds:({x:Screen.virtualX,y:Screen.virtualY,width:Screen.width,height:Screen.height,scale:Screen.devicePixelRatio})
        function fitToScreen(reset) {
            if(displayBounds.width<=0 || displayBounds.height<=0) return;
            var geometry=Review.compactWindowGeometry(displayBounds,{x:x,y:y,width:width,height:height},reset || !placed);
            minimumWidth=geometry.minimumWidth;minimumHeight=geometry.minimumHeight;
            width=geometry.width;height=geometry.height;x=geometry.x;y=geometry.y;placed=true;
        }
        onDisplayBoundsChanged:screenFit.restart()
        onVisibleChanged:if(visible)screenFit.restart()
        onVisibilityChanged:if(visibility===Window.Windowed)screenFit.restart()
        Timer {id:screenFit;interval:80;onTriggered:if(reviewWindow.visible && reviewWindow.visibility===Window.Windowed)reviewWindow.fitToScreen(false)}
        color:"#171c22"; title:root.title
        visible:root.initialized
        onClosing: function(close) {
            root.cancelExport();
            root.cancelSync();
            if (root.syncing) {close.accepted=false;return;}
            if (root.bookSwitch) {
                if(!root.cancelBookSwitch()) {close.accepted=false;root.message="Finishing the book save/open. Wait before closing.";return;}
            }
            if (root.saving || root.afterStop === "save") {
                close.accepted = false; root.message = "Wait for the local score save to finish before closing.";
            } else if(root.ready && root.sharedUnsavedRows.length) {
                close.accepted=false;root.message="Shared score save has not been verified. Retry Save score + CSV before closing.";
            } else if (root.ready && root.dirty) {
                close.accepted = false; root.pendingClose = true; unsaved.open();
            } else root.closeReview();
        }
    }
    Dialog {
        id:verseDialog; title:"How many verses?"; modal:true
        parent:reviewWindow.contentItem; width:Math.min(400,parent.width-24)
        x:(parent.width-width)/2; y:Math.max(12,(parent.height-height)/2)
        standardButtons:Dialog.Ok | Dialog.Cancel
        onAccepted: {
            if(root.song().id!==root.exportPromptSong) {root.fail("Song changed. Choose MP3 Full again.");return;}
            root.exportAudio("full",false,verseCountBox.value)
        }
        ColumnLayout {
            anchors.fill:parent
            Label {text:"The score does not specify a verse count. Enter the number of times to play the song for this Full export.";wrapMode:Text.Wrap;Layout.fillWidth:true}
            SpinBox {id:verseCountBox;from:1;to:32;value:1;editable:true;Layout.fillWidth:true;Accessible.name:"Number of verses"}
            Label {text:"This applies to this export only; it does not change the score or shared review.";wrapMode:Text.Wrap;Layout.fillWidth:true;color:"#aab5c1"}
        }
    }
    Dialog {
        id:syncDialog; title:"Connect Google Sheets"; modal:true
        parent:reviewWindow.contentItem; width:Math.min(520,parent.width-24)
        height:Math.min(600,parent.height-32)
        x:(parent.width-width)/2; y:Math.max(12,(parent.height-height)/2)
        standardButtons:Dialog.Cancel
        ScrollView {
            id:syncSettingsScroll; anchors.fill:parent; clip:true; contentWidth:availableWidth
            ScrollBar.vertical.policy:ScrollBar.AlwaysOn
        ColumnLayout {
            width:Math.max(0,syncSettingsScroll.availableWidth-18)
            Label { text:"The organiser sets up the shared Sheet once using App/GOOGLE SHEETS SETUP.txt. Enter the deployment URL and sync key they provide."; wrapMode:Text.Wrap; Layout.fillWidth:true }
            Label { text:"Google Apps Script deployment URL" }
            TextField { id:syncUrl; Layout.fillWidth:true; Layout.minimumWidth:0; placeholderText:"https://script.google.com/macros/s/…/exec"; Accessible.name:"Sync deployment URL" }
            Label { text:"Sync key" }
            TextField { id:syncKey; Layout.fillWidth:true; Layout.minimumWidth:0; echoMode:TextInput.Password; Accessible.name:"Sync key" }
            Label { text:"The organiser configures the kit once. Reviewers receive the connection automatically. Shared answers update everyone's local score; saved overlapping edits require a choice."; wrapMode:Text.Wrap; Layout.fillWidth:true }
            Label { text:root.syncMessage; textFormat:Text.PlainText; wrapMode:Text.Wrap; Layout.fillWidth:true }
            ReviewButton { text:"Save connection"; Layout.fillWidth:true; onClicked:root.saveSyncSettings() }
        }
        }
    }
    Dialog {
        id:sharedDialog; title:"Resolve overlapping reviews"; modal:true
        parent:reviewWindow.contentItem; width:Math.min(720,parent.width-24); height:Math.min(620,parent.height-32)
        x:(parent.width-width)/2; y:(parent.height-height)/2; standardButtons:Dialog.Close
        ColumnLayout {
            anchors.fill:parent
            Label { text:"Someone changed these songs after your copy was downloaded. Your saved answers remain in your reviewer CSV. Choose the shared answer or deliberately submit yours against the displayed revision."; wrapMode:Text.Wrap; Layout.fillWidth:true }
            Label { visible:root.syncConflicts.length===0; text:"No overlapping edits to resolve."; Layout.fillWidth:true }
            ListView {
                id:sharedList; Layout.fillWidth:true; Layout.fillHeight:true; clip:true; spacing:18
                model:root.syncConflicts
                ScrollBar.vertical:ScrollBar { policy:ScrollBar.AlwaysOn }
                delegate:ColumnLayout {
                    required property var modelData
                    width:ListView.view.width-22
                    Label {
                        Layout.fillWidth:true; wrapMode:Text.Wrap; textFormat:Text.PlainText
                        text:modelData.id+" — "+modelData.local.title+"\nYOUR SAVED ANSWER\n"+Review.sharedAnswerSummary(modelData.local)+"\n\nSHARED ANSWER (revision "+modelData.revision+")\n"+Review.sharedAnswerSummary(modelData.shared)
                    }
                    ReviewButton { text:"Use shared answer"; Layout.fillWidth:true; enabled:!root.busy; onClicked:root.resolveSyncConflict(modelData,"shared") }
                    ReviewButton { text:"Keep my answer"; Layout.fillWidth:true; enabled:!root.busy; onClicked:root.resolveSyncConflict(modelData,"mine") }
                }
            }
        }
    }    Dialog {
        id:unsaved; title:"Unconfirmed changes"; modal:true
        parent:reviewWindow.contentItem
        width:Math.min(360,parent.width-24)
        x:(parent.width-width)/2; y:(parent.height-height)/2
        standardButtons:Dialog.Save | Dialog.Discard | Dialog.Cancel
        Label { width:parent.width; wrapMode:Text.Wrap; text:root.pendingClose ? "Save this decision before closing?" : root.pendingBook ? "Save this decision before switching books?" : "Save this decision before changing songs?" }
        onAccepted:root.save()
        onDiscarded: { try { root.discard() } catch(error) { root.fail(error) } }
        onRejected: { root.pendingClose=false; root.pendingNavigation=-1; root.pendingBook=null; root.showSongSelection();root.showBookSelection() }
    }
    Dialog {
        id:instrumentDialog; title:"Listening instrument — " + (root.volumeLabels[root.instrumentGroup] || "")
        parent:reviewWindow.contentItem; modal:true
        width:Math.min(600,parent.width-32); height:Math.min(600,parent.height-48)
        x:(parent.width-width)/2; y:(parent.height-height)/2
        standardButtons:Dialog.Close
        onOpened: { instrumentSearch.text=""; instrumentSearch.forceActiveFocus() }
        function choose(id) { close(); root.setInstrument(root.instrumentGroup,id) }
        ColumnLayout {
            anchors.fill:parent
            Label { text:"Bundled MS Basic sounds. Listening only. Default: Grand Piano."; Layout.fillWidth:true; wrapMode:Text.Wrap }
            TextField { id:instrumentSearch; placeholderText:"Search instruments…"; Accessible.name:"Search listening instruments"; Layout.fillWidth:true }
            ListView {
                Layout.fillWidth:true; Layout.fillHeight:true; clip:true
                model:root.soundOptions.filter(function(item) { return item.label.toLowerCase().indexOf(instrumentSearch.text.toLowerCase()) >= 0 })
                ScrollBar.vertical:ScrollBar { }
                delegate:ItemDelegate {
                    required property var modelData
                    width:ListView.view.width; text:modelData.label
                    onClicked:instrumentDialog.choose(modelData.id)
                }
            }
        }
    }
    Dialog {
        id:trackDialog; title:"Listening tracks - show, hide & reorder"
        parent:reviewWindow.contentItem; modal:true
        width:Math.min(640,parent.width-24); height:Math.min(620,parent.height-32)
        x:(parent.width-width)/2; y:(parent.height-height)/2
        standardButtons:Dialog.Close
        function move(group,direction) { root.moveListeningRow(group,direction); Qt.callLater(function() { trackList.positionViewAtIndex(root.volumeOrder.indexOf(group),ListView.Contain) }) }
        function showRow(group,shown) { root.showListeningRow(group,shown) }
        ColumnLayout {
            anchors.fill:parent
            Label { text:"Show controls with the checkbox. Move them with Up / Down. Hidden controls keep their volume, mute and solo settings."; Layout.fillWidth:true; wrapMode:Text.Wrap }
            ListView {
                Layout.fillWidth:true; Layout.fillHeight:true; clip:true
                id:trackList; model:root.volumeOrder
                ScrollBar.vertical:ScrollBar { policy:ScrollBar.AlwaysOn }
                delegate:RowLayout {
                    required property int index
                    required property int modelData
                    width:ListView.view.width-18; height:52
                    Controls.CheckBox {
                        checked:root.hiddenVolumeRows.indexOf(modelData)<0; enabled:!root.busy
                        Accessible.name:"Show " + root.volumeLabels[modelData]
                        onClicked:trackDialog.showRow(modelData,checked)
                    }
                    Label { text:root.volumeLabels[modelData]+(root.volumeSolos[modelData] ? " (Solo)" : "")+(root.volumeMutes[modelData] ? " (Muted)" : ""); Layout.fillWidth:true; elide:Text.ElideRight }
                    ReviewButton { text:"Up"; enabled:!root.busy && index>0; Accessible.name:"Move " + root.volumeLabels[modelData]+" up"; onClicked:trackDialog.move(modelData,-1) }
                    ReviewButton { text:"Down"; enabled:!root.busy && index<root.volumeOrder.length-1; Accessible.name:"Move " + root.volumeLabels[modelData]+" down"; onClicked:trackDialog.move(modelData,1) }
                }
            }
            ReviewButton { text:"Restore default order & show all"; Layout.fillWidth:true; enabled:!root.busy; onClicked:root.resetListeningLayout() }
        }
    }
    Rectangle {
        parent:reviewWindow.contentItem; anchors.fill:parent; color:"#171c22"
        Flickable {
            id:panelScroll; anchors {left:parent.left;right:parent.right;top:parent.top;bottom:saveFooter.top;margins:10}
            clip:true; contentWidth:width; contentHeight:Math.max(height,panelColumn.implicitHeight)
            boundsBehavior:Flickable.StopAtBounds
            onWidthChanged:contentX=0
            onContentHeightChanged:contentY=Math.max(0,Math.min(contentY,contentHeight-height))
            ScrollBar.vertical:ScrollBar {
                parent:panelScroll; x:panelScroll.width-width; height:panelScroll.height
                policy:size<1 ? ScrollBar.AlwaysOn : ScrollBar.AlwaysOff; width:14
                contentItem:Rectangle {implicitWidth:12;radius:6;color:parent.pressed ? "#e5cfa7" : "#9faebb"}
                background:Rectangle {radius:6;color:"#303943"}
            }
        ColumnLayout {
            id:panelColumn; width:Math.max(0,panelScroll.width-18)
            spacing:5
            Label { text:"Playback review"; color:"#f2ede3"; font.pixelSize:18; font.bold:true }
            RowLayout {
                Layout.fillWidth:true
                Label { text:"Reviewer"; color:"#f2ede3" }
                TextField {
                    implicitHeight:28; font.pixelSize:12; topPadding:2; bottomPadding:2; Layout.minimumWidth:0;
                    id:reviewer; placeholderText:"Enter your name — saved with each review"
                    Accessible.name:"Reviewer name"; Layout.fillWidth:true; enabled:!root.busy
                    onEditingFinished: { try { root.loadCsv();if(root.syncConfigured) Qt.callLater(function(){root.syncReviews(true)}) } catch(error) { root.fail(error) } }
                }
            }
            RowLayout {
                Layout.fillWidth:true
                Label {text:root.syncMessage;textFormat:Text.PlainText;color:"#d8b878";Layout.fillWidth:true;elide:Text.ElideRight;ToolTip.visible:syncStatusHover.hovered;ToolTip.text:text;HoverHandler {id:syncStatusHover}}
                ReviewButton {text:root.syncing ? "Cancel sync" : "Sync now";enabled:root.syncing || (root.ready && !root.busy);onClicked:root.syncing ? root.cancelSync() : root.syncReviews()}
                ReviewButton {text:"Settings";Accessible.name:"Sync settings";onClicked:syncSection.expanded=!syncSection.expanded}
            }
                    ReviewSection {
                        id:syncSection; title:"Google Sheets sync"; expanded:false; headerVisible:false; Layout.fillWidth:true; maximumContentHeight:180
                        Label { text:"One shared answer per song. Saved changes sync automatically when idle and shared answers update your score. Offline work syncs when you reconnect."; color:"#aab5c1"; wrapMode:Text.Wrap; Layout.fillWidth:true }
                        RowLayout {
                            Layout.fillWidth:true
                            ReviewButton { text:"Connection…"; Layout.fillWidth:true; enabled:!root.syncing; onClicked:root.openSyncSettings() }
                            ReviewButton { text:"Resolve edits ("+root.syncConflicts.length+")"; Layout.fillWidth:true; enabled:root.ready && root.syncConflicts.length>0 && !root.busy; onClicked:sharedDialog.open() }
                        }
                        Label { text:root.syncMessage; textFormat:Text.PlainText; color:"#d8b878"; wrapMode:Text.Wrap; Layout.fillWidth:true; font.pixelSize:12 }
                    }
            RowLayout {
                Layout.fillWidth:true
                ComboBox {
                    implicitHeight:28; font.pixelSize:12; topPadding:2; bottomPadding:2; Layout.minimumWidth:0;
                    id:bookBox;model:root.bookCatalog;textRole:"label";Layout.fillWidth:true
                    enabled:root.ready && !root.busy && !root.tempoChange && !root.exportPending && root.soundsReady() && count>0
                    Accessible.name:"Review book and section"
                    delegate:Controls.ItemDelegate {
                        required property int index
                        width:bookList.width-14;height:36;highlighted:index===bookBox.highlightedIndex
                        contentItem:Text {text:root.bookCatalog[index].label;color:"#f2ede3";elide:Text.ElideRight;verticalAlignment:Text.AlignVCenter}
                        onClicked: {bookBox.currentIndex=index;bookBox.popup.close();}
                    }
                    popup:Popup {
                        width:bookBox.width;y:bookBox.height;implicitHeight:Math.min(contentItem.implicitHeight+12,300)
                        contentItem:ListView {
                            id:bookList
                            clip:true;implicitHeight:contentHeight;model:bookBox.popup.visible ? bookBox.delegateModel : null
                            currentIndex:bookBox.highlightedIndex
                            highlightMoveDuration:0;boundsBehavior:Flickable.StopAtBounds
                            onCurrentIndexChanged:if(currentIndex>=0)positionViewAtIndex(currentIndex,ListView.Contain)
                            ScrollBar.vertical:ScrollBar {
                                parent:bookList;x:bookList.width-width;y:0;height:bookList.height
                                orientation:Qt.Vertical;policy:ScrollBar.AlwaysOn;width:14
                                contentItem:Rectangle {implicitWidth:12;radius:6;color:parent.pressed ? "#e5cfa7" : "#9faebb"}
                                background:Rectangle {radius:6;color:"#303943"}
                            }
                        }
                        onOpened:bookList.positionViewAtIndex(bookBox.currentIndex,ListView.Contain)
                    }
                }
                ReviewButton {text:"Switch";enabled:bookBox.enabled && bookBox.currentIndex>=0;onClicked:root.requestBookSwitch(bookBox.currentIndex)}
            }
            Label {visible:root.bookCatalog.length===0;text:"Book switching needs sections.json beside the review books. Open the complete USB kit.";color:"#aab5c1";wrapMode:Text.Wrap;Layout.fillWidth:true}
            Label {visible:mscoreMajorVersion<5 && root.bookCatalog.length>0;text:"Chorus books require the included MuseScore 5 app.";color:"#aab5c1";wrapMode:Text.Wrap;Layout.fillWidth:true}
            ReviewButton {text:"Cancel book switch";visible:root.bookSwitch!==null;enabled:root.bookSwitch!==null && ["helper","check","restore"].indexOf(root.bookSwitch.stage)>=0;Layout.fillWidth:true;onClicked:root.cancelBookSwitch()}
            RowLayout {
            Layout.fillWidth: true
            ComboBox {
                    implicitHeight:28; font.pixelSize:12; topPadding:2; bottomPadding:2; Layout.minimumWidth:0;
                id: songBox; model: songs; textRole: "label"; editable: true; Layout.fillWidth: true
                enabled: root.ready && !root.busy && !root.tempoChange
                Keys.onShortcutOverride:function(event) {
                    if(event.key===Qt.Key_Return || event.key===Qt.Key_Enter || event.key===Qt.Key_Up || event.key===Qt.Key_Down) event.accepted=true
                }
                contentItem:TextField {
                    implicitHeight:28; font.pixelSize:12; topPadding:2; bottomPadding:2; Layout.minimumWidth:0;
                    text:songBox.editText;selectByMouse:true;autoScroll:true
                    color:"#f2ede3";verticalAlignment:Text.AlignVCenter
                    onTextEdited:songBox.editText=text
                    onActiveFocusChanged:if(activeFocus) selectAll()
                    // MuseScore shortcuts must not consume song-entry/navigation keys.
                    Keys.onShortcutOverride:function(event) {
                        if(event.key===Qt.Key_Return || event.key===Qt.Key_Enter || event.key===Qt.Key_Up || event.key===Qt.Key_Down) event.accepted=true
                    }
                    Keys.onReturnPressed:songBox.acceptSong()
                    Keys.onEnterPressed:songBox.acceptSong()
                    onAccepted:songBox.acceptSong()
                }
                onActivated: root.navigate(currentIndex)
                // Closing the popup destroys its delegates; navigate from this stable context.
                function chooseSong(index) { popup.close(); root.navigate(index) }
                function acceptSong() {
                    if(popup.visible && highlightedIndex>=0) chooseSong(highlightedIndex)
                    else root.goToSong()
                }
                delegate: Controls.ItemDelegate {
                    required property int index
                    required property string label
                    width:songList.width-14; height:36
                    highlighted:index === songBox.highlightedIndex
                    contentItem: Text { text:label; color:"#f2ede3"; elide:Text.ElideRight; verticalAlignment:Text.AlignVCenter }
                    onClicked: songBox.chooseSong(index)
                }
                popup: Controls.Popup {
                    y: songBox.height; width: songBox.width
                    height: Math.min(360, songList.contentHeight + 8); padding:4
                    background: Rectangle { color:"#252d36"; border.color:"#657180"; radius:8 }
                    contentItem: ListView {
                        id:songList; clip:true; model:songBox.popup.visible ? songBox.delegateModel : null
                        currentIndex:songBox.highlightedIndex; boundsBehavior:Flickable.StopAtBounds
                        onCurrentIndexChanged:if(currentIndex>=0) positionViewAtIndex(currentIndex,ListView.Contain)
                        ScrollBar.vertical: ScrollBar {
                            orientation:Qt.Vertical; parent:songList; x:songList.width-width; y:0; height:songList.height
                            policy:ScrollBar.AlwaysOn; width:14
                            contentItem:Rectangle { implicitWidth:12; radius:6; color:parent.pressed ? "#e5cfa7" : "#9faebb" }
                            background:Rectangle { radius:6; color:"#303943" }
                        }
                        onCountChanged: if(count) positionViewAtIndex(root.songIndex,ListView.Contain)
                    }
                    onOpened: songList.positionViewAtIndex(root.songIndex,ListView.Contain)
                }
            }
            ReviewButton { text:"Go"; enabled:root.ready && !root.busy && !root.tempoChange; onClicked:root.goToSong() }
            }
            RowLayout {
                Layout.fillWidth: true
                Label { text: root.book ? root.progress.done + " / " + root.book.songs.length + " confirmed" : ""; color:"#aab5c1"; Layout.fillWidth:true }
                Label {
                    id:reviewStatus; visible:root.ready
                    text:(root.currentSongReviewed ? "Reviewed" : "Not reviewed") + (root.dirty ? " · unsaved edits" : "")
                    color:root.currentSongReviewed ? "#95d4ae" : "#d8b878"; font.bold:true
                    Layout.maximumWidth:150; wrapMode:Text.Wrap
                    ToolTip.visible:reviewStatusHover.hovered
                    ToolTip.text:"Saved review status for this song, including shared reviews and your locally saved answers. Unsaved edits need Save score + CSV."
                    HoverHandler {id:reviewStatusHover}
                }
            }
            RowLayout {
                Layout.fillWidth:true
                ReviewButton { text: "Previous"; Layout.fillWidth:true; enabled: root.ready && root.songIndex > 0 && !root.busy && !root.tempoChange; onClicked: root.navigate(root.songIndex-1) }
                ReviewButton { text: "Next"; Layout.fillWidth:true; enabled: root.ready && root.songIndex < songs.count-1 && !root.busy && !root.tempoChange; onClicked: root.navigate(root.songIndex+1) }
                ReviewButton { text:"Unreviewed"; Accessible.name:"Next unreviewed song"; Layout.fillWidth:true; enabled:root.ready && reviewer.text.trim() !== "" && !root.busy && !root.tempoChange && root.progress.next >= 0 && root.progress.next !== root.songIndex; onClicked:root.navigate(root.progress.next) }
            }
            RowLayout {
                Layout.fillWidth:true
                ReviewButton { text:"-1 bar"; Accessible.name:"Back one bar"; enabled:root.audition && !root.busy && !root.tempoChange; onClicked:root.seekBar(-1) }
                ReviewButton { text: root.audition && !root.paused ? "Pause" : (root.paused ? "Resume" : "Play"); Layout.fillWidth: true; enabled: root.ready && !root.busy; onClicked: root.play() }
                ReviewButton { text:"+1 bar"; Accessible.name:"Forward one bar"; enabled:root.audition && !root.busy && !root.tempoChange; onClicked:root.seekBar(1) }
            }
            GridLayout {
                Layout.fillWidth:true; columns:4; columnSpacing:4
                ReviewButton { text:"Stop"; enabled:root.ready && !root.saving; onClicked: { root.stop(); root.message="Stopped." } }
                ReviewButton { text:"Restart"; enabled:root.ready && !root.busy && !root.tempoChange; onClicked: { root.loopPasses=0; root.stop(); root.play() } }
                Controls.CheckBox { palette.windowText:"#f2ede3"; text:"Loop"; font.pixelSize:12; spacing:3; leftPadding:0; rightPadding:0; Accessible.name:"Loop song"; checked:root.loopSong; onToggled:root.loopSong=checked }
                Controls.CheckBox { palette.windowText:"#f2ede3"; text:"Click"; font.pixelSize:12; spacing:3; leftPadding:0; rightPadding:0; Accessible.name:"Metronome"; enabled:root.ready && !root.busy; checked:Review.playbackChecked(transport.items,"metronome",root.transportApi)===true; onClicked:root.dispatch("metronome") }
            }
            Label { text:root.tempoChange ? "Updating tempo…" : root.audition ? (root.paused ? "Paused" : "Playing") + " · bar " + Math.max(1,transport.measureNumber-root.song().start+1) + " / " + (root.song().end-root.song().start+1) + " · beat " + transport.beatNumber + (root.loopSong ? " · loop " + (root.loopPasses+1) : "") : "Ready to listen"; color:"#aab5c1"; font.pixelSize:12 }

            Rectangle { Layout.fillWidth:true; height:1; color:"#343d47" }
            Flickable {
                id:bodyScroll; Layout.fillWidth:true; Layout.preferredHeight:contentHeight; Layout.minimumWidth:0
                readonly property real availableWidth:width
                clip:true; contentWidth:width; contentHeight:bodyColumn.implicitHeight
                boundsBehavior:Flickable.StopAtBounds
                onWidthChanged:contentX=0
                onContentHeightChanged:contentY=Math.max(0,Math.min(contentY,contentHeight-height))
                ScrollBar.vertical:ScrollBar {
                    orientation:Qt.Vertical; parent:bodyScroll; x:bodyScroll.width-width; y:0; height:bodyScroll.height
                    policy:size<1 ? ScrollBar.AlwaysOn : ScrollBar.AlwaysOff; width:14
                    contentItem:Rectangle { implicitWidth:12; radius:6; color:parent.pressed ? "#e5cfa7" : "#9faebb" }
                    background:Rectangle { radius:6; color:"#303943" }
                }
                ColumnLayout {
                    id:bodyColumn; implicitWidth:0; width:bodyScroll.availableWidth; spacing:7
                    ReviewSection {
                        id:tempoSection; title:"Playback settings"; expanded:true; collapsible:false
                        Layout.fillWidth:true
            RowLayout {
                Label { text: "Tempo"; color: "white" }
                Label { text: root.book ? ({quarter:"♩",dotted_quarter:"♩.",half:"𝅗𝅥"})[root.song().beat_unit] : "♩"; color: "white"; font.pixelSize: 22 }
                TextField {
                    implicitHeight:28; font.pixelSize:12; topPadding:2; bottomPadding:2; Layout.minimumWidth:0; id: tempoBox; text: "120"; selectByMouse:true; onActiveFocusChanged:if(activeFocus) selectAll(); Layout.preferredWidth:64; enabled: root.ready && !root.busy; validator: DoubleValidator { bottom:20; top:300; decimals:2 } onAccepted:root.setTempo(text); onEditingFinished: root.setTempo(text) }
                ReviewSlider { id: tempoSlider; from:20; to:300; stepSize:1; value:120; Layout.fillWidth:true; Layout.minimumWidth:40; enabled:root.ready && !root.busy; onMoved:root.setTempo(value); Accessible.name:"Tempo BPM" }
            }
            RowLayout {
                Label { text: "Feel"; color: "white" }
                ComboBox {
                    implicitHeight:28; font.pixelSize:12; topPadding:2; bottomPadding:2; Layout.minimumWidth:0; id: feelBox; model:["Straight", "Swing"]; Layout.fillWidth:true; enabled: root.ready && !root.busy && !root.tempoChange; onActivated: root.setFeel(currentIndex) }
                SpinBox {
                    implicitHeight:28; font.pixelSize:12; topPadding:2; bottomPadding:2; Layout.minimumWidth:0; from:0; to:100; value:root.swingRatio; editable:true; Layout.preferredWidth:96; Accessible.name:"Swing ratio percent"; enabled:root.ready && !root.busy && !root.tempoChange; onValueModified:root.setSwing(value) }
                Label { text:"%"; color:"white" }
            }
            Label { text: "Swing: 50% even · 67% triplets"; color: "#aab5c1"; font.pixelSize: 11 }

                    }
                    ReviewSection {
                        id:holdsSection; title:"Fermata holds"; expanded:true; collapsible:false; headerVisible:false
                        Layout.fillWidth:true; maximumContentHeight:220
            RowLayout {
                Layout.fillWidth:true
                Label {text:"All fermatas";color:"white"}
                SpinBox {
                    implicitHeight:28; font.pixelSize:12; topPadding:2; bottomPadding:2; Layout.minimumWidth:0;id:allHoldsPercent;from:100;to:1000;stepSize:25;value:100;editable:true;Layout.preferredWidth:100;Accessible.name:"All fermatas duration percent";enabled:root.ready && !root.busy && !root.tempoChange && holds.count>0}
                Label {text:"%";color:"white"}
                ReviewButton {text:"Apply";Accessible.name:"Apply to all fermatas in song";Layout.fillWidth:true;enabled:allHoldsPercent.enabled;onClicked:root.setHold(-1,allHoldsPercent.value)}
            }
            ReviewButton {text:(holdScroll.visible ? "Hide individual fermatas" : "Individual fermatas…");Layout.fillWidth:true;onClicked:holdScroll.visible=!holdScroll.visible}
            ScrollView {
                id: holdScroll; visible:false
                ScrollBar.vertical.policy:ScrollBar.AsNeeded
                ScrollBar.horizontal.policy:ScrollBar.AlwaysOff
                Layout.fillWidth: true; Layout.preferredHeight: Math.min(180,holds.count ? holds.count * 36 : 24); clip: true
                contentWidth: availableWidth
                Column {
                    width: holdScroll.availableWidth; spacing: 8
                    Label { visible: holds.count === 0; text: "No fermatas in this song."; color: "#aab5c1" }
                    Repeater {
                        model: holds
                        RowLayout {
                            id: holdRow
                            required property int index
                            required property int bar
                            required property real percent
                            width: parent.width
                            ReviewButton { text: "Hold " + (holdRow.index+1) + " — bar " + holdRow.bar; Layout.fillWidth: true; enabled: root.ready && !root.busy && !root.tempoChange; onClicked: { try { root.sameScore(); root.pause(); curScore.selection.select(root.fermatas[holdRow.index].elements[0]); curScore.showElementInScore(root.fermatas[holdRow.index].elements[0]) } catch(error) { root.fail(error) } } }
                            SpinBox {
                    implicitHeight:28; font.pixelSize:12; topPadding:2; bottomPadding:2; Layout.minimumWidth:0; from:100; to:1000; stepSize:25; value:holdRow.percent; editable:true; enabled:root.ready && !root.busy && !root.tempoChange; onValueModified: root.setHold(holdRow.index, value) }
                            Label { text:"%"; color:"white" }
                        }
                    }
                }
            }

                    }
                    ReviewSection {
                        id:questionsSection; title:"Review answers"; expanded:true; collapsible:false
                        Layout.fillWidth:true; maximumContentHeight:360
            Label { text:"Are there any notes that should be grace notes in this score?"; color:"white"; wrapMode:Text.Wrap; Layout.fillWidth:true }
            ComboBox {
                    implicitHeight:28; font.pixelSize:12; topPadding:2; bottomPadding:2; Layout.minimumWidth:0; id:graceBox; model:["No", "Yes"]; Layout.fillWidth:true; enabled:root.ready && !root.busy; onActivated:root.reviewEdited() }
            RowLayout {
                Label { text:"Are there any issues with this score?"; color:"white"; Layout.fillWidth:true; wrapMode:Text.Wrap }
                ComboBox {
                    implicitHeight:28; font.pixelSize:12; topPadding:2; bottomPadding:2; Layout.minimumWidth:0; id:issuesBox; model:["No", "Yes"]; enabled:root.ready && !root.busy; onActivated:root.reviewEdited() }
            }
            Label { text:"(Include any additional tempo or feel changes within the score here.)"; color:"#aab5c1"; wrapMode:Text.Wrap; Layout.fillWidth:true; font.pixelSize:12 }
            ScrollView {
                Layout.fillWidth:true; Layout.preferredHeight:72; clip:true
                TextArea { id:issueNotes; placeholderText:"Notes about this score…"; font.pixelSize:12; wrapMode:TextEdit.Wrap; enabled:root.ready && !root.busy; onTextChanged:if(activeFocus) root.reviewEdited() }
            }

                    }
                    ReviewSection {
                        title:"MP3 export";expanded:true;collapsible:false;Layout.fillWidth:true
                        RowLayout {
                            Layout.fillWidth:true
                            Label {text:"Full: verse break";Layout.fillWidth:true;wrapMode:Text.Wrap}
                            SpinBox {
                    implicitHeight:28; font.pixelSize:12; topPadding:2; bottomPadding:2; Layout.minimumWidth:0;
                                id:verseGapBox;from:0;to:16;value:1;editable:true
                                enabled:!root.exportPending;Accessible.name:"Break between verses in bars"
                            }
                            Label {text:"bars"}
                        }
                        Label {text:"Part: once · Full: all verses · current listening mix";color:"#aab5c1";font.pixelSize:11;wrapMode:Text.Wrap;Layout.fillWidth:true
                            ToolTip.visible:exportHelpHover.hovered;ToolTip.text:"Exports go to Books/Exports. Full asks for the verse count when unknown. Breaks use the opening tempo and time signature; 0 adds no bars.";HoverHandler{id:exportHelpHover}}
                        RowLayout {
                            Layout.fillWidth:true
                            ReviewButton {text:"MP3 (Part)";Layout.fillWidth:true;enabled:root.ready && !root.busy && !root.exportPending && !root.tempoChange;onClicked:root.exportAudio("part")}
                            ReviewButton {text:"MP3 (Full)";Layout.fillWidth:true;enabled:root.ready && !root.busy && !root.exportPending && !root.tempoChange;onClicked:root.exportAudio("full")}
                        }
                        ReviewButton {text:"Cancel MP3 export";visible:root.exportPending!==null;Layout.fillWidth:true;onClicked:root.cancelExport()}
                        Label {text:root.exportMessage;textFormat:Text.PlainText;color:"#d8b878";wrapMode:Text.Wrap;Layout.fillWidth:true;font.pixelSize:12}
                    }
                    ReviewSection {
                        id:listeningSection; title:"Listening & instruments"; expanded:false
                        Layout.fillWidth:true; maximumContentHeight:360
            RowLayout {
            Layout.fillWidth:true
            ComboBox {
                    implicitHeight:28; font.pixelSize:12; topPadding:2; bottomPadding:2; Layout.minimumWidth:0;id:presetBox;model:Review.instrumentPresets.map(function(p){return p.name;});Layout.fillWidth:true;enabled:root.ready && !root.busy && root.soundsReady()}
            ReviewButton {text:"Apply";Accessible.name:"Apply instrument preset";enabled:presetBox.enabled;onClicked:root.applyPreset(presetBox.currentIndex)}
            }
            RowLayout {
                Layout.fillWidth:true
                ReviewButton {text:"Manage tracks";Accessible.name:"Show, hide and reorder listening tracks";enabled:root.ready && !root.busy;onClicked:trackDialog.open()}
                Label {text:root.volumeSolos.filter(function(value){return value}).length+" solo · "+root.hiddenVolumeRows.length+" hidden";color:"#aab5c1";font.pixelSize:11;Layout.fillWidth:true;elide:Text.ElideRight}
            }
            Repeater {
                model: root.shownVolumeRows
                Column {
                    id: volumeRow
                    required property int index
                    required property int modelData
                    readonly property int group:modelData
                    Layout.fillWidth:true; Layout.preferredWidth:0; height:62
                    enabled: root.ready && !root.busy && root.volumeChannels[group] !== undefined && root.volumeChannels[group].length > 0
                    RowLayout {
                        width:parent.width; height:28; spacing:5
                    Label { text: root.volumeLabels[volumeRow.group]; color: "white"; Layout.preferredWidth: Math.min(120,volumeRow.width*0.3); Layout.minimumWidth:0; elide:Text.ElideRight
                        ToolTip.visible: channelNameHover.hovered; ToolTip.text:text
                        HoverHandler { id:channelNameHover }
                    }
                    ReviewSlider {
                        id: volumeSlider; from: 0; to: 100; stepSize: 1; value: root.volumeLevels[volumeRow.group]
                        Layout.fillWidth: true
                        Layout.minimumWidth: 40
                        onMoved: root.setVolume(volumeRow.group, value, root.volumeMutes[volumeRow.group])
                    }
                    Label { text: Math.round(volumeSlider.value) + "%"; color: "white"; Layout.preferredWidth: 35 }
                    }
                    RowLayout {
                        width:parent.width; height:28; spacing:4
                        ReviewButton {
                            text:"M";implicitWidth:30;checkable:true;checked:root.volumeMutes[volumeRow.group];primary:checked
                            Accessible.name:"Mute " + root.volumeLabels[volumeRow.group]
                            ToolTip.visible:hovered;ToolTip.text:Accessible.name
                            onClicked:root.setVolume(volumeRow.group,root.volumeLevels[volumeRow.group],checked)
                        }
                        ReviewButton {
                            visible:volumeRow.group>=3;text:"S";implicitWidth:30;checkable:true;checked:root.volumeSolos[volumeRow.group];primary:checked
                            Accessible.name:"Solo " + root.volumeLabels[volumeRow.group]
                            ToolTip.visible:hovered;ToolTip.text:Accessible.name
                            onClicked:root.setSolo(volumeRow.group,checked)
                        }
                        ReviewButton {
                        Layout.fillWidth:true;Layout.preferredWidth:0
                        text:root.soundLabel(volumeRow.group)
                        Accessible.name:"Listening instrument for " + root.volumeLabels[volumeRow.group] + ": " + text
                        enabled:root.soundsReady()
                        onClicked: { root.instrumentGroup=volumeRow.group; instrumentDialog.open() }
                        }
                    }
                }
            }
            Label { text: root.volumeNotice; visible:text!==""; color: "#aab5c1"; wrapMode: Text.Wrap; Layout.fillWidth: true; font.pixelSize: 11 }
            ReviewButton { text:"Reset listening mix"; Layout.fillWidth:true; enabled:root.ready && !root.busy && root.mixerSnapshot.length > 0; onClicked:root.resetListeningMix() }

                    }
                }
            }
        }
        }
        ColumnLayout {
            id:saveFooter;anchors {left:parent.left;right:parent.right;bottom:parent.bottom;margins:10}
            spacing:4
            Rectangle { Layout.fillWidth:true; height:1; color:"#343d47" }
            ReviewButton { text:"Cancel sync"; visible:root.syncing; Layout.fillWidth:true; onClicked:root.cancelSync() }
            Label { text:root.message; color:"#d8b878"; wrapMode:Text.Wrap; Layout.fillWidth:true; font.pixelSize:12 }
            ReviewButton { text:root.saving ? "Saving…" : "Save score + CSV"; primary:true; Layout.fillWidth:true; enabled:root.ready && !root.busy && !root.tempoChange; onClicked:root.save() }
        }
    }
}
