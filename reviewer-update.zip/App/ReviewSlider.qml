import QtQuick
import QtQuick.Controls as Controls

Controls.Slider {
    id: control
    implicitHeight: 28
    background: Rectangle {
        x: control.leftPadding; y: control.topPadding + control.availableHeight / 2 - height / 2
        width: control.availableWidth; height: 5; radius: 3; color: "#39434e"
        Rectangle { width: control.visualPosition * parent.width; height: parent.height; radius: 3; color: "#d8bd8e" }
    }
    handle: Rectangle {
        x: control.leftPadding + control.visualPosition * (control.availableWidth - width)
        y: control.topPadding + control.availableHeight / 2 - height / 2
        width: 16; height: 16; radius: 8
        color: control.pressed ? "#d8bd8e" : "#f2ede3"
        border.color: control.activeFocus ? "#d8bd8e" : "#788592"
        Behavior on color { ColorAnimation { duration: 90 } }
    }
}
